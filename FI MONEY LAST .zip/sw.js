// FI Money service worker: makes the app shell work offline. It caches app files only — never business data.
const VERSION = "b3197f2720";
const FILES = ["./","config.js","icons/apple-touch-icon.png","icons/icon-192.png","icons/icon-512.png","icons/icon.svg","index.html","js/app/account.js","js/app/cloud.js","js/app/components.js","js/app/main.js","js/app/modals.js","js/app/state.js","js/app/types.js","js/app/ui.js","js/app/views-reminders.js","js/app/views.js","js/engine/auth.js","js/engine/entitlements.js","js/engine/ledger.js","js/engine/money.js","js/engine/profit.js","js/engine/reminders.js","js/engine/reports.js","manifest.webmanifest","privacy.html","styles.css","terms.html"];
const CACHE = "fi-money-" + VERSION;

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith("fi-money-") && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).catch(() => caches.match("./"))));
});
