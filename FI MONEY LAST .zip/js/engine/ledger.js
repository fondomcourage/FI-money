// FI Money — ledger: sales, payments, debts, expenses, inventory, summaries.
// Transaction records are the source of truth. Balances and stock are always
// CALCULATED from records, never overwritten. Every operation returns a new Db.
//
// Documented simplifications (MVP):
//  * Inventory cost method: each sale line snapshots the product's unit cost at
//    the time of sale ("last known cost"). No FIFO/weighted-average layers yet.
//  * Stock purchases are inventory movements, NOT operating expenses, so a cost
//    is never counted twice (purchase now, COGS when sold).
//  * Sale "fee" = seller-side cost (marketplace/payment fee). It does not change
//    what the customer owes.
//  * Voiding a sale reverses the sale, its stock movements and its payments.
//    Any cash already collected must be refunded by the owner outside the app.

                                        
import { mulQty } from "./money.js";

                        
                              // YYYY-MM-DD in the business time zone

                           
                                                     
                                                                       
                                                  
                                   
 
                          
                                                                 
                                                                          
 
                            
                                               
                                                       
                                                                     
 
                                                                                                                       
                       
                                                                               
                                                                                      
 
                          
                                                                          
                                                                                                    
 
                          
                                                                              
                                                                   
 
                     
                                                                      
                                                                                       
 
export const DEFAULT_EXPENSE_CATEGORIES = [
  "Rent", "Transport", "Delivery", "Packaging", "Marketing", "Utilities", "Wages", "Supplies", "Other expenses",
];
export const emptyDb = ()     => ({
  customers: [], products: [], stockMoves: [], sales: [], payments: [], expenses: [],
  expenseCategories: [...DEFAULT_EXPENSE_CATEGORIES],
});

export class LedgerError extends Error {}
const fail = (m        )        => { throw new LedgerError(m); };
export const newId = ()     => {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  // Fallback for non-secure contexts (e.g. plain http on a LAN during testing).
  return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
};
const clone = (db    )     => structuredClone(db);

// ---------- dates ----------
export function daysBetween(from         , to         )         {
  const a = Date.UTC(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10));
  const b = Date.UTC(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10));
  return Math.round((b - a) / 86400000);
}
export function addDays(d         , n        )          {
  const t = new Date(Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)) + n * 86400000);
  return t.toISOString().slice(0, 10);
}
const validDate = (d        )          => /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(Date.parse(d));

// ---------- sale maths ----------
export const saleSubtotal = (s      )        => s.lines.reduce((t, l) => t + mulQty(l.unitPrice, l.qty), 0);
/** Net sales revenue = subtotal - discount. */
export const saleTotal = (s      )        => saleSubtotal(s) - s.discount;
/** Cost of goods sold, or null when any line's cost is unknown. */
export function saleCogs(s      )               {
  let t = 0;
  for (const l of s.lines) {
    if (l.unitCost === null) return null;
    t += mulQty(l.unitCost, l.qty);
  }
  return t;
}

// ---------- debts ----------
                                                                   
                       
                                                                                               
                                                                                          
 
/** Money counted against a sale: payments + credit adjustments (not voided). */
export function creditsOnSale(db    , saleId    )        {
  return db.payments.filter((p) => p.saleId === saleId && !p.voided).reduce((t, p) => t + p.amount, 0);
}
export function cashOnSale(db    , saleId    )        {
  return db.payments.filter((p) => p.saleId === saleId && !p.voided && p.kind === "payment").reduce((t, p) => t + p.amount, 0);
}
export function debtOf(db    , sale      , today         )       {
  const original = saleTotal(sale);
  const paid = creditsOnSale(db, sale.id);
  const balance = original - paid;
  const partiallyPaid = paid > 0 && balance > 0;
  let status             = "unpaid";
  if (balance <= 0) status = "paid";
  else if (sale.dueDate && sale.dueDate < today) status = "overdue"; // only with a balance left
  else if (partiallyPaid) status = "partial";
  return { saleId: sale.id, ref: sale.ref, customerId: sale.customerId, original, paid, balance: Math.max(balance, 0),
    createdOn: sale.date, dueDate: sale.dueDate, status, partiallyPaid };
}
/** All sales with money still owed (balance > 0), excluding voided sales and walk-in sales without a customer. */
export function openDebts(db    , today         )         {
  return db.sales.filter((s) => !s.voided && s.customerId)
    .map((s) => debtOf(db, s, today)).filter((d) => d.balance > 0);
}

// ---------- stock ----------
export function stockOf(db    , productId    )         {
  const voided = new Set(db.sales.filter((s) => s.voided).map((s) => s.id));
  return db.stockMoves.filter((m) => m.productId === productId && !(m.saleId && voided.has(m.saleId)))
    .reduce((t, m) => t + m.qty, 0);
}

// ---------- operations ----------
export function addCustomer(db    , c                                      )     {
  if (!c.name.trim()) fail("Customer name is required.");
  const next = clone(db);
  next.customers.push({ id: newId(), phone: "", email: "", telegramChatId: null, channel: "manual",
    optOut: false, paused: false, ...c, name: c.name.trim() });
  return next;
}
export function addProduct(db    , p                                     , openingStock = 0, today         )     {
  if (!p.name.trim()) fail("Product name is required.");
  if (p.price !== undefined && p.price < 0) fail("Price cannot be negative.");
  const next = clone(db);
  const prod          = { id: newId(), sku: "", kind: "product", price: 0, cost: null, lowStockAt: 0, archived: false, ...p, name: p.name.trim() };
  next.products.push(prod);
  if (prod.kind === "product" && openingStock > 0)
    next.stockMoves.push({ id: newId(), productId: prod.id, qty: openingStock, kind: "opening", date: today, unitCost: prod.cost });
  return next;
}
export function updateProduct(db    , id    , patch                                                                                       )     {
  const next = clone(db);
  const p = next.products.find((x) => x.id === id) ?? fail("Unknown product.");
  if (patch.name !== undefined && !patch.name.trim()) fail("Product name is required.");
  if (patch.price !== undefined && (!Number.isInteger(patch.price) || patch.price < 0)) fail("Price cannot be negative.");
  if (patch.cost !== undefined && patch.cost !== null && (!Number.isInteger(patch.cost) || patch.cost < 0)) fail("Cost cannot be negative.");
  Object.assign(p, patch); // past sales keep the cost they were sold at (snapshot)
  return next;
}
export function updateCustomer(db    , id    , patch                               )     {
  const next = clone(db);
  const c = next.customers.find((x) => x.id === id) ?? fail("Unknown customer.");
  if (patch.name !== undefined && !patch.name.trim()) fail("Customer name is required.");
  Object.assign(c, patch);
  return next;
}
export function recordStock(db    , productId    , qty        , kind                           , date         , unitCost               = null, note = "")     {
  const p = db.products.find((x) => x.id === productId) ?? fail("Unknown product.");
  if (p.kind === "service") fail("Services do not use physical stock.");
  if (!Number.isFinite(qty) || qty === 0) fail("Quantity must not be zero.");
  if (kind === "purchase" && qty < 0) fail("A purchase quantity must be positive.");
  const next = clone(db);
  next.stockMoves.push({ id: newId(), productId, qty, kind, date, unitCost, note });
  if (kind === "purchase" && unitCost !== null) next.products.find((x) => x.id === productId) .cost = unitCost;
  return next;
}

                            
                                                
                                                                                  
                                                                         
                                                              
                                   
 
/** Create or edit a sale. Idempotent per sale id: stock movements are rebuilt, never doubled. */
export function saveSale(db    , input           )     {
  if (!validDate(input.date)) fail("Sale date is invalid.");
  if (input.dueDate && !validDate(input.dueDate)) fail("Due date is invalid.");
  if (!input.lines.length) fail("Add at least one product or service.");
  const next = clone(db);
  const existing = input.id ? next.sales.find((s) => s.id === input.id) : undefined;
  if (existing?.voided) fail("A voided sale cannot be edited.");
  const customer = input.customerId ? next.customers.find((c) => c.id === input.customerId) ?? fail("Unknown customer.") : null;

  const lines             = input.lines.map((l) => {
    if (!(l.qty > 0)) fail("Quantity must be greater than zero.");
    if (!Number.isInteger(l.unitPrice) || l.unitPrice < 0) fail("Price must be zero or more.");
    const prod = l.productId ? next.products.find((p) => p.id === l.productId) ?? fail("Unknown product.") : null;
    return { productId: prod?.id ?? null, name: l.name ?? prod?.name ?? "Item", qty: l.qty, unitPrice: l.unitPrice,
      unitCost: prod ? (prod.kind === "service" ? prod.cost ?? 0 : prod.cost) : null };
  });
  const sale       = {
    id: existing?.id ?? newId(), ref: existing?.ref ?? `S-${String(next.sales.length + 1).padStart(4, "0")}`,
    date: input.date, customerId: customer?.id ?? null, lines, discount: input.discount ?? 0, fee: input.fee ?? 0,
    dueDate: input.dueDate ?? null, voided: false, note: input.note ?? "",
  };
  if (sale.discount < 0 || sale.fee < 0) fail("Discount and fee cannot be negative.");
  const total = saleTotal(sale);
  if (total < 0) fail("Discount is larger than the sale.");
  const paidSoFar = existing ? creditsOnSale(next, existing.id) : 0;
  if (total < paidSoFar) fail("This edit would make the total lower than money already received. Record a refund adjustment first.");
  if (!customer && total > paidSoFar && (input.paidNow ?? 0) < total - paidSoFar)
    fail("Choose a customer for sales that are not fully paid.");

  if (existing) next.sales[next.sales.indexOf(existing)] = sale; else next.sales.push(sale);
  // Rebuild stock movements for this sale (prevents duplicates on edit/retry).
  next.stockMoves = next.stockMoves.filter((m) => m.saleId !== sale.id);
  for (const l of lines) {
    const p = l.productId ? next.products.find((x) => x.id === l.productId)  : null;
    if (p && p.kind === "product")
      next.stockMoves.push({ id: newId(), productId: p.id, qty: -l.qty, kind: "sale", date: sale.date, saleId: sale.id, unitCost: l.unitCost });
  }
  if (input.paidNow && input.paidNow > 0) {
    return recordPayment(next, { saleId: sale.id, amount: input.paidNow, date: sale.date, method: input.method ?? "Cash" });
  }
  return next;
}

export function voidSale(db    , saleId    )     {
  const next = clone(db);
  const s = next.sales.find((x) => x.id === saleId) ?? fail("Unknown sale.");
  if (s.voided) return next; // idempotent
  s.voided = true;
  for (const p of next.payments) if (p.saleId === saleId) p.voided = true;
  return next;
}

                                                                                                                               
export function recordPayment(db    , i              )     {
  if (!Number.isInteger(i.amount) || i.amount <= 0) fail("Payment must be greater than zero.");
  if (!validDate(i.date)) fail("Payment date is invalid.");
  const sale = db.sales.find((s) => s.id === i.saleId) ?? fail("Unknown sale.");
  if (sale.voided) fail("This sale was voided.");
  if (i.key && db.payments.some((p) => p.key === i.key)) return db; // duplicate submit: ignore
  const balance = saleTotal(sale) - creditsOnSale(db, sale.id);
  if (i.amount > balance) fail("That is more than the remaining balance.");
  const next = clone(db);
  next.payments.push({ id: newId(), customerId: sale.customerId, saleId: sale.id, date: i.date, amount: i.amount,
    method: i.method ?? "Cash", kind: "payment", note: i.note ?? "", voided: false, key: i.key ?? null });
  return next;
}
/** Pay a customer's oldest open debts first. Returns the new Db. */
export function recordCustomerPayment(db    , customerId    , amount       , date         , method = "Cash", today          = date)     {
  const debts = openDebts(db, today).filter((d) => d.customerId === customerId)
    .sort((a, b) => a.createdOn.localeCompare(b.createdOn));
  const owed = debts.reduce((t, d) => t + d.balance, 0);
  if (amount > owed) fail("That is more than this customer owes.");
  let left = amount; let next = db;
  for (const d of debts) {
    if (left <= 0) break;
    const part = Math.min(left, d.balance);
    next = recordPayment(next, { saleId: d.saleId, amount: part, date, method });
    left -= part;
  }
  return next;
}
/** Signed adjustment with a required reason. Positive = credit/write-off, negative = reopens the debt. */
export function recordAdjustment(db    , saleId    , amount       , date         , reason        )     {
  if (!reason.trim()) fail("A reason is required for an adjustment.");
  if (!Number.isInteger(amount) || amount === 0) fail("Adjustment must not be zero.");
  const sale = db.sales.find((s) => s.id === saleId) ?? fail("Unknown sale.");
  if (sale.voided) fail("This sale was voided.");
  const credits = creditsOnSale(db, saleId);
  if (amount > 0 && amount > saleTotal(sale) - credits) fail("Adjustment is larger than the remaining balance.");
  if (amount < 0 && credits + amount < 0) fail("Adjustment would make total credits negative.");
  const next = clone(db);
  next.payments.push({ id: newId(), customerId: sale.customerId, saleId, date, amount, method: "Adjustment",
    kind: "adjustment", note: reason.trim(), voided: false, key: null });
  return next;
}
export function voidPayment(db    , paymentId    )     {
  const next = clone(db);
  const p = next.payments.find((x) => x.id === paymentId) ?? fail("Unknown payment.");
  p.voided = true;
  return next;
}

export function addExpense(db    , e                                                                                            )     {
  if (!e.description.trim()) fail("Expense description is required.");
  if (!Number.isInteger(e.amount) || e.amount <= 0) fail("Expense amount must be greater than zero.");
  if (!validDate(e.date)) fail("Expense date is invalid.");
  const next = clone(db);
  if (!next.expenseCategories.includes(e.category)) next.expenseCategories.push(e.category);
  next.expenses.push({ id: newId(), method: "Cash", supplier: "", notes: "", voided: false, ...e, description: e.description.trim() });
  return next;
}
export function updateExpense(db    , id    , patch                                                                                                          )     {
  const next = clone(db);
  const e = next.expenses.find((x) => x.id === id) ?? fail("Unknown expense.");
  if (e.voided) fail("A reversed expense cannot be edited.");
  const m = { ...e, ...patch };
  if (!m.description.trim()) fail("Expense description is required.");
  if (!Number.isInteger(m.amount) || m.amount <= 0) fail("Expense amount must be greater than zero.");
  if (!validDate(m.date)) fail("Expense date is invalid.");
  if (!next.expenseCategories.includes(m.category)) next.expenseCategories.push(m.category);
  Object.assign(e, m, { description: m.description.trim() });
  return next;
}
export function voidExpense(db    , id    )     {
  const next = clone(db);
  (next.expenses.find((x) => x.id === id) ?? fail("Unknown expense.")).voided = true;
  return next;
}

// ---------- summaries (used by dashboard AND reports) ----------
                          
                             
                                                                         
                                                                                                                    
                    
                                                                                                      
                                                             
 
export function summarize(db    , from         , to         , today         )          {
  const inRange = (d         ) => d >= from && d <= to;
  const sales = db.sales.filter((s) => !s.voided && inRange(s.date));
  const activeSale = new Set(db.sales.filter((s) => !s.voided).map((s) => s.id));
  const salesRevenue = sales.reduce((t, s) => t + saleTotal(s), 0);
  const fees = sales.reduce((t, s) => t + s.fee, 0);
  const cogsParts = sales.map(saleCogs);
  const cogs = cogsParts.some((c) => c === null) ? null : (cogsParts            ).reduce((t, c) => t + c, 0);
  const cashReceived = db.payments.filter((p) => !p.voided && p.kind === "payment" && inRange(p.date) && activeSale.has(p.saleId))
    .reduce((t, p) => t + p.amount, 0);
  const expenses = db.expenses.filter((e) => !e.voided && inRange(e.date)).reduce((t, e) => t + e.amount, 0);
  const missing           = [];
  if (cogs === null) missing.push("Some sold items have no unit cost, so profit cannot be calculated.");
  const grossProfit = cogs === null ? null : salesRevenue - cogs;
  const contributionProfit = grossProfit === null ? null : grossProfit - fees;
  const estimatedNetProfit = contributionProfit === null ? null : contributionProfit - expenses;
  const debts = openDebts(db, today);
  const overdue = debts.filter((d) => d.status === "overdue");
  const lowStock = db.products.filter((p) => p.kind === "product" && !p.archived && p.lowStockAt > 0)
    .map((p) => ({ productId: p.id, name: p.name, stock: stockOf(db, p.id), at: p.lowStockAt }))
    .filter((x) => x.stock <= x.at).map(({ productId, name, stock }) => ({ productId, name, stock }));
  return {
    from, to, salesRevenue, cashReceived, expenses, fees, cogs, grossProfit, contributionProfit, estimatedNetProfit, missing,
    outstanding: debts.reduce((t, d) => t + d.balance, 0),
    overdue: overdue.reduce((t, d) => t + d.balance, 0),
    partialCount: debts.filter((d) => d.partiallyPaid).length, overdueCount: overdue.length,
    debtorCount: new Set(debts.map((d) => d.customerId)).size, lowStock,
  };
}
