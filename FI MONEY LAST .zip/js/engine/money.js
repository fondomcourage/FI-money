// FI Money — precision-safe money helpers.
// All amounts are stored as integers in the currency's smallest unit
// (cents for USD/EUR, whole riel for KHR, whole francs for XAF).
// This avoids floating-point errors such as 0.1 + 0.2 !== 0.3.

                            // integer count of minor units

const MINOR_DIGITS                         = {
  USD: 2,
  EUR: 2,
  KHR: 0,
  XAF: 0,
  VND: 0,
  JPY: 0,
};

export function minorDigits(currency        )         {
  return MINOR_DIGITS[currency.toUpperCase()] ?? 2;
}

/** Parse a user-typed decimal string into minor units. Returns null if invalid. */
export function parseMoney(input        , currency        )               {
  const digits = minorDigits(currency);
  const cleaned = input.trim().replace(/,/g, "");
  if (!/^-?\d+(\.\d+)?$/.test(cleaned)) return null;
  const negative = cleaned.startsWith("-");
  const body = negative ? cleaned.slice(1) : cleaned;
  const [whole, frac = ""] = body.split(".");
  // Round half up on the digit after the last supported decimal place.
  const padded = (frac + "0".repeat(digits + 1)).slice(0, digits + 1);
  let value = Number(whole) * 10 ** digits + Number(padded.slice(0, digits) || "0");
  if (Number(padded.slice(digits)) >= 5) value += 1;
  if (!Number.isSafeInteger(value)) return null;
  return negative ? -value : value;
}

export function formatMoney(amount       , currency        )         {
  const digits = minorDigits(currency);
  const sign = amount < 0 ? "-" : "";
  const abs = Math.abs(amount);
  const whole = Math.trunc(abs / 10 ** digits);
  const frac = abs % 10 ** digits;
  const wholeStr = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return digits === 0
    ? `${sign}${currency} ${wholeStr}`
    : `${sign}${currency} ${wholeStr}.${frac.toString().padStart(digits, "0")}`;
}

/** Multiply minor units by a quantity (may be fractional, e.g. 2.5 kg), rounding half up. */
export function mulQty(unitPrice       , quantity        )        {
  return Math.round(unitPrice * quantity + Number.EPSILON * Math.sign(unitPrice));
}

/** Percentage of an amount, rounded half up. `percent` like 10 means 10%. */
export function percentOf(amount       , percent        )        {
  return Math.round((amount * percent) / 100);
}

/** Ratio as a percentage with one decimal place, or null when the base is not positive. */
export function marginPercent(part       , base       )                {
  if (base <= 0) return null;
  return Math.round((part / base) * 1000) / 10;
}

/** Amount without the currency code, e.g. 1,234.56 (for message templates that add {currency} separately). */
export function formatAmount(amount       , currency        )         {
  return formatMoney(amount, currency).replace(/^(-?)[A-Z]{3} /, "$1");
}
