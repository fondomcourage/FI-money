// FI Money — debtor reminders: templates, eligibility, planning, dispatch, status tracking.
//
// HONESTY RULES (enforced here, not just in the UI):
//  * "submitted" means a provider ACCEPTED the request. It is never shown as delivered.
//  * "delivered" is only set from a provider callback (applyProviderEvent), never from a send call.
//  * Mock providers are flagged (providerIsMock) and every label says so.
//  * Telegram's Bot API gives no delivery receipts, so Telegram reminders stay "submitted"
//    and later become "unknown" — never "delivered".

                                                                   
import { openDebts, debtOf, daysBetween, addDays, newId } from "./ledger.js";
import { formatAmount } from "./money.js";

                                         
                                                                 
                                                                                                                                

                           
                                                                                            
                                                                                                 
                                                                                                           
                                                                                              
 

                                   
                                         
                                                            
                     
                                                                
                                                                                   
                                                                  
                                                          
                                                                 
                                                                                         
                   
                            
 
export const DEFAULT_TEMPLATE =
  "Hello {customer_name}, this is a friendly reminder that your outstanding balance with {business_name} is {currency} {outstanding_balance}, due on {due_date}. If you have already paid, please let us know so we can update our records. Thank you.";
export const DEFAULT_REMINDER_SETTINGS                   = {
  paused: false, beforeDays: [3], onDueDate: true, afterDays: [1, 3, 7, 14],
  quietStart: "21:00", quietEnd: "08:00", minHoursBetween: 48, maxPerDebt: 6, maxRetries: 2,
  bothMode: "together", template: DEFAULT_TEMPLATE, unknownAfterHours: 24,
};
/** What the connected backend reports. In local-only mode both are false. */
                                                                                      

// ---------- phone numbers ----------
/** Normalise to E.164. A leading 0 is treated as a national number of `defaultCountryCode`. Returns null if invalid. */
export function normalizePhone(input        , defaultCountryCode = "855")                {
  let s = input.trim().replace(/[\s().-]/g, "");
  if (s.startsWith("00")) s = "+" + s.slice(2);
  if (s.startsWith("0")) s = "+" + defaultCountryCode + s.slice(1);
  else if (!s.startsWith("+")) return null;
  if (!/^\+[1-9]\d{7,14}$/.test(s)) return null;
  if (s.startsWith("+855") && !/^\+855\d{8,9}$/.test(s)) return null; // Cambodia: 8–9 digits after country code
  return s;
}

// ---------- time (business time zone) ----------
export function todayIn(tz        , now      )          {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}
export function minutesIn(tz        , now      )         {
  const p = new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false }).formatToParts(now);
  const h = Number(p.find((x) => x.type === "hour") .value) % 24;
  return h * 60 + Number(p.find((x) => x.type === "minute") .value);
}
const toMin = (hhmm        )         => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));
export function inQuietHours(minutes        , start        , end        )          {
  const a = toMin(start), b = toMin(end);
  if (a === b) return false;
  return a < b ? minutes >= a && minutes < b : minutes >= a || minutes < b;
}

// ---------- templates ----------
                                 
                                                                                              
                                                        
 
export const PLACEHOLDERS = ["customer_name", "business_name", "currency", "outstanding_balance", "due_date", "invoice_ref"]         ;
export function renderTemplate(tpl        , v                )                                       {
  const warnings           = [];
  let t = tpl;
  if (!v.due_date) {
    // Never invent a due date: drop the clause that mentions it.
    t = t.replace(/,?\s*due (?:on|by)\s*\{due_date\}/gi, "").replace(/\{due_date\}/g, "");
    warnings.push("This debt has no due date, so the due-date wording was left out.");
  }
  if (!v.invoice_ref) t = t.replace(/\s*\(?\{invoice_ref\}\)?/g, "");
  t = t.replace(/\{(\w+)\}/g, (m, k        ) => {
    if ((PLACEHOLDERS                     ).includes(k)) return String((v                                                        )[k] ?? "");
    warnings.push(`Unknown placeholder ${m} was left as written.`);
    return m;
  });
  if (!tpl.includes("{outstanding_balance}")) warnings.push("Your template does not include {outstanding_balance}.");
  return { text: t.replace(/ {2,}/g, " ").replace(/\s+([.,])/g, "$1").trim(), warnings };
}
/** Always uses the LATEST outstanding balance (never the original debt amount). */
export function buildMessage(tpl        , debt      , customer          , businessName        , currency        ) {
  return renderTemplate(tpl, {
    customer_name: customer.name, business_name: businessName, currency,
    outstanding_balance: formatAmount(debt.balance, currency), due_date: debt.dueDate, invoice_ref: debt.ref,
  });
}

// ---------- eligibility ----------
                                                                      
                              
                                                                                   
                                                                                                      
                                         
 
export function recipientFor(c          , ch         )                {
  return ch === "sms" ? (c.phone ? normalizePhone(c.phone) : null) : c.telegramChatId;
}
/** Why a reminder can't be sent. `permanent` blockers should cancel it; `transient` ones just delay it. */
export function blockersFor(r          , ctx             )           {
  const permanent           = [], transient           = [];
  const sale = ctx.db.sales.find((s) => s.id === r.saleId);
  const customer = ctx.db.customers.find((c) => c.id === r.customerId);
  const today = todayIn(ctx.tz, ctx.now);
  if (!sale || sale.voided) permanent.push("The sale no longer exists or was voided.");
  const debt = sale && !sale.voided ? debtOf(ctx.db, sale, today) : null;
  if (debt && debt.balance <= 0) permanent.push("The debt is fully paid.");
  if (!customer) permanent.push("The customer no longer exists.");
  else {
    if (customer.optOut) permanent.push("The customer opted out of reminders.");
    if (!recipientFor(customer, r.channel))
      permanent.push(r.channel === "sms" ? "No valid phone number (use international format)." : "Telegram is not connected for this customer.");
  }
  if (!ctx.automationAllowed && r.origin === "automatic") permanent.push("Automated reminders are not included in the current plan.");
  if ((r.channel === "sms" && !ctx.config.smsConfigured) || (r.channel === "telegram" && !ctx.config.telegramConfigured))
    transient.push(`${r.channel === "sms" ? "SMS" : "Telegram"} provider is not connected.`);
  if (customer?.paused) transient.push("Reminders are paused for this customer.");
  if (ctx.settings.paused) transient.push("Reminders are paused for the whole business.");
  if (inQuietHours(minutesIn(ctx.tz, ctx.now), ctx.settings.quietStart, ctx.settings.quietEnd))
    transient.push(`Quiet hours (${ctx.settings.quietStart}–${ctx.settings.quietEnd}).`);
  const sent = ctx.reminders.filter((x) => x.id !== r.id && x.saleId === r.saleId && x.channel === r.channel && x.sentAt);
  if (sent.length >= ctx.settings.maxPerDebt) permanent.push("Maximum reminders for this debt reached.");
  const last = sent.map((x) => Date.parse(x.sentAt )).sort((a, b) => b - a)[0];
  if (last !== undefined && ctx.now.getTime() - last < ctx.settings.minHoursBetween * 3600_000)
    transient.push(`Frequency limit: one reminder per ${ctx.settings.minHoursBetween} hours.`);
  return { permanent, transient };
}

// ---------- planning (creates scheduled reminders; never sends) ----------
const channelsFor = (p             )            => (p === "sms" ? ["sms"] : p === "telegram" ? ["telegram"] : p === "both" ? ["sms", "telegram"] : []);
export function triggerOffsets(s                  )           {
  const o = [...s.beforeDays.map((d) => -Math.abs(d)), ...(s.onDueDate ? [0] : []), ...s.afterDays.map((d) => Math.abs(d))];
  return [...new Set(o)].sort((a, b) => a - b);
}
                                                                                                                                                      
/**
 * For each open debt with a due date, finds the most recent schedule step that has
 * already been reached and creates ONE scheduled reminder for it (per channel) if none exists.
 * Using only the latest step avoids a flood after the app was closed for a while.
 */
export function planAutomatic(a          )             {
  const today = todayIn(a.tz, a.now);
  const offsets = triggerOffsets(a.settings);
  const created             = [];
  for (const debt of openDebts(a.db, today)) {
    const cust = a.db.customers.find((c) => c.id === debt.customerId);
    if (!cust || cust.channel === "manual" || cust.optOut || !debt.dueDate) continue;
    const reached = offsets.filter((o) => o <= daysBetween(debt.dueDate , today));
    if (!reached.length) continue;
    const step = reached[reached.length - 1];
    const chans = channelsFor(cust.channel);
    chans.forEach((ch, i) => {
      const key = `${debt.saleId}:${ch}:${step}`;
      if (a.reminders.some((r) => r.key === key) || created.some((r) => r.key === key)) return;
      if (i === 1 && a.settings.bothMode === "sequence") {
        // Second channel only when the first failed for the same step.
        const first = [...a.reminders, ...created].find((r) => r.key === `${debt.saleId}:${chans[0]}:${step}`);
        if (!first || first.status !== "failed") return;
      }
      const triggerDate = addDays(debt.dueDate , step);
      created.push(makeReminder(a, debt, cust, ch, key, triggerDate, "automatic", "scheduled"));
    });
  }
  return created;
}
export function makeReminder(a                                                                  , debt      , cust          , ch         ,
  key        , triggerDate         , origin                        , status                )           {
  const at = a.now.toISOString();
  return {
    id: newId(), key, saleId: debt.saleId, customerId: cust.id, channel: ch, status, triggerDate,
    body: buildMessage(a.settings.template, debt, cust, a.businessName, a.currency).text, createdAt: at, sentAt: null,
    attempts: 0, provider: null, providerIsMock: false, providerMessageId: null, error: null, origin,
    log: [{ at, status, note: origin === "automatic" ? "Scheduled by automation rule" : "Created by the business owner" }],
  };
}

/** Cancels unsent reminders that can never be sent (debt paid, opt-out, ...). Returns the full updated list. */
export function cancelStale(reminders            , ctx             )             {
  return reminders.map((r) => {
    if (!["draft", "scheduled", "pending"].includes(r.status)) return r;
    const { permanent } = blockersFor(r, ctx);
    return permanent.length ? setStatus(r, "cancelled", ctx.now, permanent[0]) : r;
  });
}
function setStatus(r          , status                , now      , note        , patch                    = {})           {
  return { ...r, ...patch, status, log: [...r.log, { at: now.toISOString(), status, note }] };
}

// ---------- dispatch ----------
                                                                                             
                                   
                                                               
                                                                              
 
/** A clearly-labelled fake provider for development. It never contacts anyone. */
export function mockProvider(channel         , opts                        = {})                   {
  let n = 0;
  const run = Date.now().toString(36) + Math.random().toString(36).slice(2, 6); // unique per page load
  return {
    id: `mock-${channel}`, label: `MOCK ${channel === "sms" ? "SMS" : "Telegram"} (no real message is sent)`, isMock: true, channel,
    async send() { return opts.failWith ? { accepted: false, error: opts.failWith } : { accepted: true, providerMessageId: `mock-${channel}-${run}-${++n}` }; },
  };
}
/**
 * Sends one reminder. Safe to call twice: a reminder that is no longer
 * draft/scheduled/pending is returned untouched, so retried jobs never double-send.
 */
export async function dispatchReminder(r          , provider                  , ctx             )                    {
  if (!["draft", "scheduled", "pending"].includes(r.status)) return r;
  if (provider.channel !== r.channel) return r;
  const b = blockersFor(r, ctx);
  if (b.permanent.length) return setStatus(r, "cancelled", ctx.now, b.permanent[0]);
  // Draft reminders are sent only by an explicit owner action; automatic ones still respect transient blockers.
  if (b.transient.length) return r;
  const sale = ctx.db.sales.find((s) => s.id === r.saleId) ;
  const cust = ctx.db.customers.find((c) => c.id === r.customerId) ;
  return sendNow(r, provider, ctx, sale.id, cust);
}
/** Owner-triggered send of a prepared reminder (still blocked by permanent blockers and missing provider). */
export async function sendNow(r          , provider                  , ctx             , _saleId    , cust          )                    {
  const sale = ctx.db.sales.find((s) => s.id === r.saleId) ;
  const debt = debtOf(ctx.db, sale, todayIn(ctx.tz, ctx.now));
  // Re-render with the latest balance right before sending.
  const body = buildMessage(ctx.settings.template, debt, cust, ctx.businessName, ctx.currency).text;
  const to = recipientFor(cust, r.channel) ;
  const res = await provider.send(to, body, r.key);
  const attempts = r.attempts + 1;
  r = { ...r, body }; // the message that was actually submitted
  if (res.accepted)
    return setStatus(r, "submitted", ctx.now, provider.isMock ? "Accepted by MOCK provider (nothing was actually sent)" : "Accepted by provider (delivery not yet confirmed)",
      { attempts, sentAt: ctx.now.toISOString(), provider: provider.id, providerIsMock: provider.isMock, providerMessageId: res.providerMessageId ?? null, error: null });
  const err = res.error ?? "Provider rejected the request";
  if (attempts > ctx.settings.maxRetries) return setStatus(r, "failed", ctx.now, `Failed after ${attempts} attempts: ${err}`, { attempts, error: err, provider: provider.id, providerIsMock: provider.isMock });
  return setStatus(r, "scheduled", ctx.now, `Attempt ${attempts} failed (will retry): ${err}`, { attempts, error: err });
}

// ---------- provider callbacks (idempotent) ----------
                                                                                                                       
export function applyProviderEvent(reminders            , processed          , ev               )                                                 {
  if (processed.includes(ev.eventId)) return { reminders, processed }; // duplicate webhook: ignore
  const out = reminders.map((r) => {
    if (r.providerMessageId !== ev.providerMessageId) return r;
    if (!["submitted", "unknown"].includes(r.status)) return r; // never downgrade delivered/failed/cancelled
    const now = new Date(ev.at);
    return ev.type === "delivered"
      ? setStatus(r, "delivered", now, r.providerIsMock ? "MOCK delivery confirmation (simulated)" : "Delivery confirmed by provider")
      : setStatus(r, "failed", now, "Provider reported the message was not delivered", { error: "Provider reported non-delivery" });
  });
  return { reminders: out, processed: [...processed, ev.eventId] };
}
/** Submitted messages with no confirmation after N hours become "delivery status unknown". */
export function markUnknown(reminders            , now      , afterHours        )             {
  return reminders.map((r) => r.status === "submitted" && r.sentAt && now.getTime() - Date.parse(r.sentAt) > afterHours * 3600_000
    ? setStatus(r, "unknown", now, "No delivery confirmation received") : r);
}
export function statusLabel(r          )         {
  const mock = r.providerIsMock ? " (MOCK)" : "";
  switch (r.status) {
    case "draft": return "Draft";
    case "scheduled": return "Scheduled";
    case "pending": return "Pending";
    case "submitted": return "Submitted to provider — not confirmed delivered" + mock;
    case "delivered": return "Delivered (confirmed by provider)" + mock;
    case "failed": return "Failed";
    case "cancelled": return "Cancelled";
    case "unknown": return "Delivery status unknown" + mock;
  }
}

// ---------- Telegram connection (backend does the bot side; this is the data logic) ----------
                                                                                                 
export function createConnectToken(customerId    , now      , ttlHours = 72)               {
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  const token = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  return { token, customerId, expiresAt: new Date(now.getTime() + ttlHours * 3600_000).toISOString(), used: false };
}
export const telegramLink = (botUsername        , token        )         =>
  `https://t.me/${encodeURIComponent(botUsername.replace(/^@/, ""))}?start=${token}`;
/** Called when the bot receives "/start <token>". Single-use, expiring. */
export function applyTelegramStart(db    , tokens                , token        , chatId        , now      ) 
                                                                   {
  const t = tokens.find((x) => x.token === token);
  if (!t) return { db, tokens, ok: false, reason: "Unknown link" };
  if (t.used) return { db, tokens, ok: false, reason: "Link already used" };
  if (Date.parse(t.expiresAt) < now.getTime()) return { db, tokens, ok: false, reason: "Link expired" };
  if (!db.customers.some((c) => c.id === t.customerId)) return { db, tokens, ok: false, reason: "Customer not found" };
  const next = structuredClone(db);
  next.customers.find((c) => c.id === t.customerId) .telegramChatId = chatId;
  return { db: next, tokens: tokens.map((x) => (x === t ? { ...x, used: true } : x)), ok: true };
}
