// FI Money — product profit calculator.
// Definitions (kept identical everywhere in the app):
//   Gross profit        = net sales revenue - cost of goods sold
//   Contribution profit = net sales revenue - COGS - included variable costs
//   Estimated net profit= net sales revenue - COGS - variable costs - operating overhead
// Gross and contribution profit are never labelled "net profit".

import { marginPercent, mulQty, percentOf } from "./money.js";
                                        

                              
                                                  
                                             
                   
                                                               
                                                                 
                                
                                 
                                                           
                                                       
                                     
                                                                                     
 

                               
              
                   
                                                          
                      
                         
                     
                            
                                
                       
                                   
                                       
                                                                        
                                       
                                                              
                                                                                   
 

export function calculateProfit(i             )               {
  const errors           = [];
  const missing           = [];

  if (!Number.isFinite(i.quantity) || i.quantity <= 0) errors.push("Quantity must be greater than zero.");
  if (!Number.isInteger(i.unitPrice) || i.unitPrice < 0) errors.push("Selling price must be zero or more.");
  for (const [label, v] of [
    ["Discount", i.discountTotal],
    ["Refunds", i.refundsTotal],
    ["Delivery cost", i.deliveryCost],
    ["Packaging cost", i.packagingCost],
    ["Other variable cost", i.otherVariableCost],
  ]         ) {
    if (v !== undefined && (!Number.isInteger(v) || v < 0)) errors.push(`${label} must be zero or more.`);
  }
  for (const [label, v] of [
    ["Marketplace fee %", i.marketplaceFeePercent],
    ["Payment fee %", i.paymentFeePercent],
  ]         ) {
    if (v !== undefined && (v < 0 || v > 100)) errors.push(`${label} must be between 0 and 100.`);
  }
  if (i.unitCost !== null && (!Number.isInteger(i.unitCost) || i.unitCost < 0))
    errors.push("Product cost must be zero or more.");

  const empty               = {
    ok: false,
    errors,
    missing,
    grossRevenue: 0,
    netSalesRevenue: 0,
    cogs: null,
    grossProfit: null,
    grossMarginPct: null,
    variableCosts: 0,
    contributionProfit: null,
    contributionMarginPct: null,
    estimatedNetProfit: null,
    estimatedNetMarginPct: null,
    profitPerUnit: null,
    breakEvenUnitPrice: null,
  };
  if (errors.length) return empty;

  const grossRevenue = mulQty(i.unitPrice, i.quantity);
  const netSalesRevenue = grossRevenue - (i.discountTotal ?? 0) - (i.refundsTotal ?? 0);

  // Without a product cost we must NOT show profit — it would be misleading.
  if (i.unitCost === null) missing.push("Product cost per unit");
  const cogs = i.unitCost === null ? null : mulQty(i.unitCost, i.quantity);

  const percentFees =
    percentOf(netSalesRevenue, i.marketplaceFeePercent ?? 0) + percentOf(netSalesRevenue, i.paymentFeePercent ?? 0);
  const variableCosts =
    (i.deliveryCost ?? 0) + (i.packagingCost ?? 0) + (i.otherVariableCost ?? 0) + percentFees;

  const grossProfit = cogs === null ? null : netSalesRevenue - cogs;
  const contributionProfit = cogs === null ? null : netSalesRevenue - cogs - variableCosts;
  const hasOverhead = i.overheadAllocation !== undefined && i.overheadAllocation !== null;
  const estimatedNetProfit =
    contributionProfit === null || !hasOverhead ? null : contributionProfit - (i.overheadAllocation         );
  if (cogs !== null && !hasOverhead) missing.push("Operating overhead (needed for estimated net profit)");

  // Break-even unit price: the price where contribution profit is exactly zero.
  // Percent fees scale with revenue, so: price*qty*(1 - f) = COGS + fixedVariable (+ discount/refund).
  let breakEvenUnitPrice               = null;
  if (cogs !== null) {
    const f = ((i.marketplaceFeePercent ?? 0) + (i.paymentFeePercent ?? 0)) / 100;
    const fixed = cogs + (i.deliveryCost ?? 0) + (i.packagingCost ?? 0) + (i.otherVariableCost ?? 0) +
      (i.discountTotal ?? 0) + (i.refundsTotal ?? 0);
    if (f < 1) {
      // Round UP so the break-even price never produces a loss.
      breakEvenUnitPrice = Math.ceil(fixed / (i.quantity * (1 - f)));
    }
  }

  return {
    ok: true,
    errors,
    missing,
    grossRevenue,
    netSalesRevenue,
    cogs,
    grossProfit,
    grossMarginPct: grossProfit === null ? null : marginPercent(grossProfit, netSalesRevenue),
    variableCosts,
    contributionProfit,
    contributionMarginPct: contributionProfit === null ? null : marginPercent(contributionProfit, netSalesRevenue),
    estimatedNetProfit,
    estimatedNetMarginPct: estimatedNetProfit === null ? null : marginPercent(estimatedNetProfit, netSalesRevenue),
    profitPerUnit: contributionProfit === null ? null : Math.round(contributionProfit / i.quantity),
    breakEvenUnitPrice,
  };
}
