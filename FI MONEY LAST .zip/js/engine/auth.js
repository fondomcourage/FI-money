// Account form rules (pure, no browser code). The server (Supabase Auth) is the real gatekeeper; these give instant, clear feedback.
export const MIN_PASSWORD = 10;
                                                                                                                                    

const COMMON = new Set(["password", "password1", "1234567890", "qwertyuiop", "iloveyou12", "0123456789", "1q2w3e4r5t", "abcdefghij", "0000000000", "1111111111"]);

export function checkPassword(pw        , email = "")                {
  const tips           = [];
  if (pw.length < MIN_PASSWORD) tips.push(`Use at least ${MIN_PASSWORD} characters.`);
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) tips.push("Mix letters and numbers.");
  if (COMMON.has(pw.toLowerCase()) || /^(.)\1+$/.test(pw)) tips.push("Avoid common or repeated passwords.");
  const local = email.split("@")[0]?.toLowerCase() ?? "";
  if (local.length >= 4 && pw.toLowerCase().includes(local)) tips.push("Do not include your email name.");
  const ok = tips.length === 0;
  let score = 0;
  if (pw.length >= MIN_PASSWORD) score++;
  if (pw.length >= 14) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score++;
  const level = (!ok ? Math.min(score, 1) : Math.max(2, Math.min(score, 3)))                 ;
  return { ok, level: pw.length === 0 ? 0 : level, label: !ok ? (pw.length < 6 ? "Too weak" : "Weak") : level >= 3 ? "Strong" : "Good", tips };
}
export function checkEmail(e        )          { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.trim()) && e.length <= 254; }
