// FI Money — central plan & feature entitlements. This is the ONLY place that
// defines prices and which plan unlocks which feature.

                                               
const RANK                       = { free: 0, pro: 1, advanced: 2 };

                                                                                                                
/** Prices are configurable here (or overridden from server config). Annual can be added to `intervals` later. */
export const PLANS                           = {
  free: { name: "FI Money Free", priceMonthlyMinor: 0, currency: "USD", intervals: ["month"] },
  pro: { name: "FI Money Pro", priceMonthlyMinor: 599, currency: "USD", intervals: ["month"] },
  advanced: { name: "FI Money Advanced", priceMonthlyMinor: 1499, currency: "USD", intervals: ["month"] },
};

/** Minimum plan required for each feature. Anything not listed is available on Free. */
export const FEATURE_MIN_TIER = {
  advancedReports: "pro", productProfitability: "pro", profitCalculator: "pro", productComparison: "pro",
  advancedExpenseAnalysis: "pro", advancedDebtReports: "pro", inventoryInsights: "pro", csvExport: "pro",
  periodComparison: "pro", performanceIndicators: "pro",
  automatedReminders: "advanced", smsReminders: "advanced", telegramReminders: "advanced",
  reminderSchedules: "advanced", reminderTemplates: "advanced", followUpQueue: "advanced",
  reminderHistory: "advanced", quietHours: "advanced", premiumInsights: "advanced",
}                                        ;
                                                    

                                                                               
                               
                                                                               
                                                                               
 
export const FREE_SUBSCRIPTION               = { tier: "free", status: "none", source: "none", currentPeriodEnd: null };

/**
 * The tier the user actually gets. Paid access requires a verified billing event
 * or an explicit admin grant. A "dev" selection only counts when devMode is on
 * and is never a real payment. Cancelled/expired/past-due fall back to Free
 * features — the user's own records are never locked or deleted.
 */
export function effectiveTier(sub              , opts                                                          )       {
  if (sub.tier === "free") return "free";
  if (sub.status !== "active") return "free";
  if (sub.currentPeriodEnd && new Date(sub.currentPeriodEnd) < opts.now) return "free";
  // Billing/admin grants only count when a server verified them. Data stored in the browser
  // can be edited by the user, so without a server it is never trusted.
  if ((sub.source === "verified_billing" || sub.source === "admin") && opts.serverVerified) return sub.tier;
  if (sub.source === "dev" && opts.devMode) return sub.tier;
  return "free";
}
export function hasFeature(tier      , feature         )          {
  return RANK[tier] >= RANK[FEATURE_MIN_TIER[feature]];
}
export function requiredTier(feature         )       { return FEATURE_MIN_TIER[feature]; }

// ---------- manual payment requests (KHQR / ABA bank transfer) ----------
/** A request is only a note that the customer says they will pay. It NEVER changes the plan. */
                                 
                                                                                                       
                                                                           
 
const REF_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I so it is easy to read out and type
/** Short code the customer writes in the payment note, e.g. FI-P-2610-K7QD4M. Pass random bytes (crypto.getRandomValues). */
export function makePaymentReference(tier                    , now      , randomBytes            )         {
  const yymm = String(now.getUTCFullYear()).slice(2) + String(now.getUTCMonth() + 1).padStart(2, "0");
  const code = Array.from(randomBytes.slice(0, 6), (b) => REF_ALPHABET[b % REF_ALPHABET.length]).join("");
  return `FI-${tier === "pro" ? "P" : "A"}-${yymm}-${code}`;
}
export function newPaymentRequest(tier                    , now      , randomBytes            )                 {
  return { reference: makePaymentReference(tier, now, randomBytes), tier, amountMinor: PLANS[tier].priceMonthlyMinor, currency: "USD",
    createdAt: now.toISOString(), status: "awaiting_confirmation" };
}
