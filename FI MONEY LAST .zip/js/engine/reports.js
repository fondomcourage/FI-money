// FI Money — reports. Built on the same ledger functions as the dashboard so numbers always agree.
                                                   
import { saleTotal, saleCogs, summarize, stockOf, openDebts, addDays, daysBetween } from "./ledger.js";
                                           
                                        
import { mulQty, marginPercent } from "./money.js";

                                                                                     
export function dailySales(db    , from         , to         )           {
  const rows           = [];
  const active = new Set(db.sales.filter((s) => !s.voided).map((s) => s.id));
  for (let d = from; d <= to; d = addDays(d, 1)) {
    const sales = db.sales.filter((s) => !s.voided && s.date === d);
    rows.push({
      date: d, count: sales.length, revenue: sales.reduce((t, s) => t + saleTotal(s), 0),
      cash: db.payments.filter((p) => !p.voided && p.kind === "payment" && p.date === d && active.has(p.saleId)).reduce((t, p) => t + p.amount, 0),
    });
    if (rows.length > 3700) break; // safety cap
  }
  return rows;
}
export function monthlySales(db    , from         , to         )                                                     {
  const m = new Map                                           ();
  for (const s of db.sales) {
    if (s.voided || s.date < from || s.date > to) continue;
    const k = s.date.slice(0, 7);
    const e = m.get(k) ?? { revenue: 0, count: 0 };
    e.revenue += saleTotal(s); e.count++; m.set(k, e);
  }
  return [...m.entries()].sort().map(([month, v]) => ({ month, ...v }));
}
export function expensesByCategory(db    , from         , to         )                                                             {
  const m = new Map               ();
  for (const e of db.expenses) if (!e.voided && e.date >= from && e.date <= to) m.set(e.category, (m.get(e.category) ?? 0) + e.amount);
  const total = [...m.values()].reduce((t, v) => t + v, 0);
  return [...m.entries()].map(([category, t]) => ({ category, total: t, share: marginPercent(t, total) })).sort((a, b) => b.total - a.total);
}

                             
                                                                                      
                                                                                 
 
/** Revenue is net of the sale discount, allocated to lines in proportion to line value. */
export function productProfitability(db    , from         , to         )               {
  const m = new Map                                               ();
  for (const s of db.sales) {
    if (s.voided || s.date < from || s.date > to) continue;
    const gross = s.lines.reduce((t, l) => t + mulQty(l.unitPrice, l.qty), 0);
    let allocated = 0;
    s.lines.forEach((l, i) => {
      const lineGross = mulQty(l.unitPrice, l.qty);
      const disc = i === s.lines.length - 1 ? s.discount - allocated : gross > 0 ? Math.round((s.discount * lineGross) / gross) : 0;
      allocated += disc;
      const k = l.productId ?? `name:${l.name}`;
      const e = m.get(k) ?? { productId: l.productId, name: l.name, qty: 0, revenue: 0, cogs: 0, grossProfit: null, grossMarginPct: null, stock: null, unknownCost: false };
      e.qty += l.qty; e.revenue += lineGross - disc;
      if (l.unitCost === null) e.unknownCost = true; else e.cogs = (e.cogs ?? 0) + mulQty(l.unitCost, l.qty);
      m.set(k, e);
    });
  }
  return [...m.values()].map(({ unknownCost, ...e }) => {
    const cogs = unknownCost ? null : e.cogs;
    const gp = cogs === null ? null : e.revenue - cogs;
    const prod = e.productId ? db.products.find((p) => p.id === e.productId) : null;
    return { ...e, cogs, grossProfit: gp, grossMarginPct: gp === null ? null : marginPercent(gp, e.revenue),
      stock: prod && prod.kind === "product" ? stockOf(db, prod.id) : null };
  }).sort((a, b) => (b.grossProfit ?? -Infinity) - (a.grossProfit ?? -Infinity));
}

                                                                                                                                                                                   
export function debtReport(db    , today         )                  {
  return openDebts(db, today).map((d) => ({
    customer: db.customers.find((c) => c.id === d.customerId)?.name ?? "Unknown", ref: d.ref, original: d.original, paid: d.paid,
    balance: d.balance, dueDate: d.dueDate, daysOverdue: d.status === "overdue" && d.dueDate ? daysBetween(d.dueDate, today) : null, status: d.status,
  })).sort((a, b) => b.balance - a.balance);
}

                                                                                                               
/** Compares a period with the immediately preceding period of equal length. */
export function comparePeriods(db    , from         , to         , today         )             {
  const len = daysBetween(from, to) + 1;
  const previousTo = addDays(from, -1), previousFrom = addDays(from, -len);
  return { current: summarize(db, from, to, today), previous: summarize(db, previousFrom, previousTo, today), previousFrom, previousTo };
}
/** Percent change, or null when the previous value is zero (no meaningful percentage). */
export function change(cur              , prev              )                {
  if (cur === null || prev === null || prev === 0) return null;
  return Math.round(((cur - prev) / Math.abs(prev)) * 1000) / 10;
}

// ---------- CSV ----------
/** Escapes quotes and neutralises spreadsheet formula injection (cells starting with = + - @). */
export function csvCell(v                                    )         {
  let s = v === null || v === undefined ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s) && typeof v !== "number") s = "'" + s;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
export function toCsv(header          , rows                              )         {
  return [header, ...rows].map((r) => r.map(csvCell).join(",")).join("\r\n") + "\r\n";
}
export const saleProfitKnown = (db    , id    )          => { const s = db.sales.find((x) => x.id === id); return !!s && saleCogs(s) !== null; };
