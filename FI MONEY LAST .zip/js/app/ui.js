// Small DOM/format helpers shared by views and actions.
export const esc = (v         )         =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]          );

export function fmtDate(d                           , format                             )         {
  if (!d) return "—";
  return format === "DD/MM/YYYY" ? `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}` : d;
}
export function fmtDateTime(iso        , tz        )         {
  try {
    return new Intl.DateTimeFormat("en-GB", { timeZone: tz, dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));
  } catch { return iso; }
}
let toastTimer                    ;
export function toast(msg        , kind                 = "ok")       {
  const t = document.getElementById("toast");
  if (!t) return;
  window.clearTimeout(toastTimer); // an older toast must never hide a newer one
  t.textContent = msg; t.className = `toast show ${kind}`;
  toastTimer = window.setTimeout(() => { t.className = "toast"; }, kind === "error" ? 6000 : 3500);
}
export async function copyText(text        )                   {
  try { await navigator.clipboard.writeText(text); return true; } catch { /* fall through */ }
  const ta = document.createElement("textarea");
  ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
  document.body.appendChild(ta); ta.select();
  let ok = false;
  try { ok = document.execCommand("copy"); } catch { ok = false; }
  ta.remove();
  return ok;
}
export function download(filename        , mime        , content        )       {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement("a");
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
}
export const val = (f          , k        )         => String(f.get(k) ?? "").trim();
