// FI Money — app state & local persistence.
// LOCAL-ONLY MODE: everything is stored in this browser (localStorage). It is NOT synced,
// NOT backed up, and NOT protected by an account. See docs/ARCHITECTURE.md for the production path.
import { emptyDb, addCustomer, addProduct, saveSale, recordPayment, addExpense, addDays, voidSale } from "../engine/ledger.js";
                                              
import { DEFAULT_REMINDER_SETTINGS, todayIn } from "../engine/reminders.js";
                                                                                       
import { FREE_SUBSCRIPTION } from "../engine/entitlements.js";
                                                                              
                                                

/** Where customers send subscription payments by hand. Public receiving details only — never secrets. Empty = not set up. */
                                
                                                                                      
                                                                              
 
export const NO_PAYMENT                = { methodName: null, accountName: null, accountNumber: null, qrImage: null, instructions: null, contact: null };
                                                                                                                
                                                                                                                                              
const rawConfig = (globalThis                                      ).FI_CONFIG ?? {};
export const CONFIG            = { devTools: true, version: "dev", backendUrl: null, ...rawConfig, payment: { ...NO_PAYMENT, ...rawConfig.payment },
  cloud: { url: null, anonKey: null, supportContact: null, ...rawConfig.cloud } };
export const cloudEnabled = ()          => !!(CONFIG.cloud.url && CONFIG.cloud.anonKey);
/** True only when the owner has filled in at least a QR image or an account number. */
export const paymentConfigured = ()          => !!(CONFIG.payment.qrImage || CONFIG.payment.accountNumber);

                           
                                                                                                          
                                                                                                
 
                           
                                                                                                                         
                                                                                                                                                          
 
                                   

export const CURRENCIES = ["USD", "KHR", "XAF", "EUR", "THB", "VND", "GBP", "SGD", "MYR", "AUD", "CAD", "JPY"];
export const COUNTRIES = ["Cambodia", "Thailand", "Vietnam", "Laos", "Myanmar", "Malaysia", "Singapore", "Indonesia", "Philippines", "Cameroon", "United States", "United Kingdom", "Australia", "Canada", "France", "Japan", "Other"];
export const BUSINESS_TYPES = ["Retail shop", "Wholesale / distribution", "Online seller", "Reseller / dropshipper", "Service provider", "Other"];

export function defaultState()           {
  const tz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Phnom_Penh"; } catch { return "Asia/Phnom_Penh"; } })();
  return {
    v: 1, db: emptyDb(), reminderSettings: structuredClone(DEFAULT_REMINDER_SETTINGS), reminders: [], processedEvents: [], tokens: [], paymentRequests: [],
    subscription: { ...FREE_SUBSCRIPTION }, botUsername: "", useMockProviders: false, devMode: CONFIG.devTools,
    business: { name: "", type: BUSINESS_TYPES[0], currency: "USD", timezone: tz, dateFormat: "DD/MM/YYYY", country: "", phone: "", email: "", startingCash: null, setupDone: false },
  };
}

// ---- storage (every access guarded: private mode / blocked storage must not break the app) ----
const memory                         = {};
export let storageOk = true;
let ns                = null;   // null = local-preview storage; otherwise the signed-in user id (each account has its own cache)
export function setNamespace(uid               )       { ns = uid; }
const KEY = (m      ) => (ns ? `fi-money:v1:u:${ns}:${m}` : `fi-money:v1:${m}`);
                                                                                                                     
const META = () => `fi-money:v1:u:${ns}:sync`;
export function loadSyncMeta()           {
  const d           = { version: 0, dirty: false, businessId: null, lastSyncedAt: null };
  try { const raw = localStorage.getItem(META()); return raw ? { ...d, ...(JSON.parse(raw)                     ) } : d; } catch { return d; }
}
export function saveSyncMeta(m          )       { try { localStorage.setItem(META(), JSON.stringify(m)); } catch { /* storage blocked */ } }
export function clearUserCache(uid        )       {
  try { for (const k of Object.keys(localStorage)) if (k.startsWith(`fi-money:v1:u:${uid}:`)) localStorage.removeItem(k); } catch { /* ignore */ }
}
export function getMode()       {
  try { return localStorage.getItem("fi-money:mode") === "demo" ? "demo" : "real"; } catch { return "real"; }
}
export function setMode(m      )       { try { localStorage.setItem("fi-money:mode", m); } catch { storageOk = false; } }
export function loadState(m      )           {
  let raw                = null;
  try { raw = localStorage.getItem(KEY(m)); } catch { storageOk = false; raw = memory[KEY(m)] ?? null; }
  const base = defaultState();
  if (!raw) return base;
  try {
    const p = JSON.parse(raw)                     ;
    return { ...base, ...p, business: { ...base.business, ...p.business }, reminderSettings: { ...base.reminderSettings, ...p.reminderSettings },
      db: { ...base.db, ...p.db }, devMode: CONFIG.devTools ? (p.devMode ?? true) : false };
  } catch { return base; }
}
export function saveState(m      , s          )       {
  const raw = JSON.stringify(s);
  memory[KEY(m)] = raw;
  try { localStorage.setItem(KEY(m), raw); storageOk = true; } catch { storageOk = false; }
}
export function eraseState(m      )       {
  delete memory[KEY(m)];
  try { localStorage.removeItem(KEY(m)); } catch { /* ignore */ }
}

/** Sample data for trying the app. Lives under a separate storage key and is shown with a permanent banner. */
export function demoState(now = new Date())           {
  let s = defaultState();
  s.business = { ...s.business, name: "Demo Shop (sample data)", currency: "USD", timezone: "Asia/Phnom_Penh", setupDone: true };
  const today = todayIn(s.business.timezone, now);
  const d = (n        ) => addDays(today, n);
  let db = emptyDb();
  db = addCustomer(db, { name: "Sophea (demo)", phone: "012 345 678", channel: "sms" });
  db = addCustomer(db, { name: "Dara Trading (demo)", phone: "+855 97 111 2222", channel: "both" });
  db = addCustomer(db, { name: "Mr. Lee (demo)", phone: "+1 202 555 0147", channel: "manual" });
  const [c1, c2, c3] = db.customers.map((c) => c.id);
  db = addProduct(db, { name: "Rice 25kg", sku: "RICE25", price: 2200, cost: 1700, lowStockAt: 10 }, 40, d(-20));
  db = addProduct(db, { name: "Cooking oil 5L", sku: "OIL5", price: 1100, cost: 800, lowStockAt: 8 }, 12, d(-20));
  db = addProduct(db, { name: "Sugar 1kg", sku: "SUG1", price: 150, cost: 110, lowStockAt: 20 }, 60, d(-20));
  db = addProduct(db, { name: "Delivery", kind: "service", price: 200, cost: 0 }, 0, d(-20));
  const [rice, oil, sugar, delivery] = db.products.map((p) => p.id);
  db = saveSale(db, { date: d(-12), customerId: c1, lines: [{ productId: rice, qty: 5, unitPrice: 2200 }, { productId: delivery, qty: 1, unitPrice: 200 }], dueDate: d(-5), paidNow: 4000 });
  db = saveSale(db, { date: d(-9), customerId: c2, lines: [{ productId: oil, qty: 6, unitPrice: 1100 }], dueDate: d(-2) });
  db = saveSale(db, { date: d(-6), customerId: null, lines: [{ productId: sugar, qty: 20, unitPrice: 150 }], paidNow: 3000 });
  db = saveSale(db, { date: d(-3), customerId: c3, lines: [{ productId: rice, qty: 4, unitPrice: 2200 }], dueDate: d(4), paidNow: 2000 });
  db = saveSale(db, { date: d(-1), customerId: c1, lines: [{ productId: oil, qty: 3, unitPrice: 1100 }, { productId: sugar, qty: 10, unitPrice: 150 }], discount: 100, dueDate: d(0) });
  db = saveSale(db, { date: today, customerId: null, lines: [{ productId: rice, qty: 2, unitPrice: 2200 }], paidNow: 4400, fee: 100 });
  const wrong = db.sales[db.sales.length - 1];
  void voidSale; void wrong; // (kept simple: no voided sale in demo)
  db = recordPayment(db, { saleId: db.sales[1].id, amount: 2000, date: d(-4) });
  db = addExpense(db, { date: d(-10), description: "Shop rent", amount: 15000, category: "Rent" });
  db = addExpense(db, { date: d(-7), description: "Tuk-tuk delivery", amount: 800, category: "Delivery" });
  db = addExpense(db, { date: d(-2), description: "Facebook ads", amount: 1200, category: "Marketing" });
  s.db = db;
  s.devMode = CONFIG.devTools;
  return s;
}
