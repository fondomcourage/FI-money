// FI Money — forms and detail sheets (modals).
import { esc } from "./ui.js";
                                    
import * as L from "../engine/ledger.js";
import * as R from "../engine/reports.js";
import { minorDigits } from "../engine/money.js";
import { PLANS, requiredTier } from "../engine/entitlements.js";
import { CONFIG } from "./state.js";
import { formatMoney } from "../engine/money.js";
import { buildMessage, blockersFor, normalizePhone, statusLabel } from "../engine/reminders.js";
                                                                
import { badge, stat, lockCard } from "./components.js";

const head = (title        ) => `<div class="sheet-head"><h2>${esc(title)}</h2><button data-a="close" aria-label="Close">✕</button></div>`;
const plain = (n               , cur        ) => n === null ? "" : (n / 10 ** minorDigits(cur)).toFixed(minorDigits(cur));
const METHODS = ["Cash", "ABA", "KHQR / Bakong", "Bank transfer", "Card", "Other"];
const methodSelect = (sel = "Cash") => `<select name="method">${METHODS.map((m) => `<option ${m === sel ? "selected" : ""}>${esc(m)}</option>`).join("")}</select>`;

export function modal(V   )         {
  const m = V.ui.modal ;
  switch (m.t) {
    case "sale": return saleForm(V, m.id);
    case "saleView": return saleView(V, m.id);
    case "expense": return expenseForm(V, m.id);
    case "expenseView": return expenseView(V, m.id);
    case "customer": return customerForm(V, m.id);
    case "customerView": return customerView(V, m.id);
    case "product": return productForm(V, m.id);
    case "productView": return productView(V, m.id);
    case "payment": return paymentForm(V, m.saleId, m.customerId);
    case "adjust": return adjustForm(V, m.saleId);
    case "stock": return stockForm(V, m.productId);
    case "reminder": return reminderPreview(V, m.saleId);
    case "pickCustomer": return pickCustomer(V);
    case "telegram": return telegramSheet(V, m.customerId);
    case "planRequest": return planRequestSheet(V, m.tier);
    case "confirm": return `${head("Please confirm")}<p>${esc(m.message)}</p><button class="btn ${m.danger === false ? "" : "danger"} block" data-a="confirm-yes" data-do="${esc(m.action)}" data-id="${esc(m.id)}">Yes, continue</button><button class="btn ghost block" style="margin-top:8px" data-a="close">Cancel</button>`;
  }
}

// ---------- sales ----------
function lineRow(V   , l                                                                             )         {
  const prods = V.s.db.products.filter((p) => !p.archived);
  return `<div class="line-row" data-line>
    <div><select name="pid" aria-label="Item"><option value="">Custom item…</option>${prods.map((p) => `<option value="${esc(p.id)}" data-price="${plain(p.price, V.currency)}" ${l?.productId === p.id ? "selected" : ""}>${esc(p.name)}${p.kind === "product" ? ` (${L.stockOf(V.s.db, p.id)})` : ""}</option>`).join("")}</select>
    <input name="pname" placeholder="Item name" aria-label="Custom item name" value="${l && !l.productId ? esc(l.name) : ""}" style="margin-top:4px;${l?.productId ? "display:none" : ""}"></div>
    <input name="qty" inputmode="decimal" aria-label="Quantity" placeholder="Qty" value="${l ? l.qty : 1}">
    <input name="price" inputmode="decimal" aria-label="Unit price" placeholder="Price" value="${l ? plain(l.unitPrice, V.currency) : ""}">
    <button type="button" class="btn ghost x" data-a="rm-line" aria-label="Remove line">✕</button></div>`;
}
function saleForm(V   , id         )         {
  const sale = id ? V.s.db.sales.find((s) => s.id === id) : undefined;
  const cs = V.s.db.customers;
  return `${head(sale ? `Edit sale ${sale.ref}` : "Record a sale")}
  <form data-form="sale" data-id="${esc(id ?? "")}" autocomplete="off">
    <div class="two"><div><label>Date</label><input type="date" name="date" required value="${esc(sale?.date ?? V.today)}"></div>
    <div><label>Customer</label><select name="customerId"><option value="">Walk-in (paid in full)</option>${cs.map((c) => `<option value="${esc(c.id)}" ${sale?.customerId === c.id ? "selected" : ""}>${esc(c.name)}</option>`).join("")}</select></div></div>
    ${cs.length === 0 ? `<p class="tiny muted">To sell on credit, add the customer first (Debtors → Add a customer).</p>` : ""}
    <label style="margin-bottom:0">Items</label><div id="lines">${(sale?.lines ?? [undefined]).map((l) => lineRow(V, l)).join("")}</div>
    <button type="button" class="btn secondary small" data-a="add-line" style="margin-top:6px">＋ Add another item</button>
    <div class="two"><div><label>Discount (${esc(V.currency)})</label><input name="discount" inputmode="decimal" value="${sale ? plain(sale.discount, V.currency) : ""}" placeholder="0"></div>
    <div><label>Fees (${esc(V.currency)})</label><input name="fee" inputmode="decimal" value="${sale ? plain(sale.fee, V.currency) : ""}" placeholder="0"><span class="tiny muted">Seller-side cost, e.g. marketplace fee</span></div></div>
    <div class="card" style="margin-top:12px"><div class="kv"><span>Total</span><b id="sale-total">—</b></div></div>
    <div class="two"><div><label>Due date (if not paid in full)</label><input type="date" name="dueDate" value="${esc(sale?.dueDate ?? "")}"></div>
    ${sale ? "" : `<div><label>Paid now (${esc(V.currency)})</label><input name="paidNow" inputmode="decimal" placeholder="0" id="paid-now"></div>`}</div>
    ${sale ? `<p class="tiny muted">Payments are managed from the sale's detail screen.</p>` : `<label>Payment method</label>${methodSelect()}`}
    <label>Note (optional)</label><input name="note" value="${esc(sale?.note ?? "")}">
    <p class="tiny muted" id="sale-hint">Anything not paid now becomes money the customer owes you.</p>
    <button class="btn block" style="margin-top:12px">${sale ? "Save changes" : "Save sale"}</button></form>`;
}
function saleView(V   , id        )         {
  const { s } = V;
  const sale = s.db.sales.find((x) => x.id === id);
  if (!sale) return head("Sale") + "<p>Not found.</p>";
  const d = L.debtOf(s.db, sale, V.today);
  const cust = s.db.customers.find((c) => c.id === sale.customerId);
  const pays = s.db.payments.filter((p) => p.saleId === id);
  const cogs = L.saleCogs(sale);
  return `${head(`Sale ${sale.ref}`)}${badge(sale.voided ? "voided" : d.status)}
  <p class="muted small">${esc(V.fd(sale.date))} · ${esc(cust?.name ?? "Walk-in")}${sale.note ? ` · ${esc(sale.note)}` : ""}</p>
  <div class="card"><div class="list">${sale.lines.map((l) => `<div class="item"><div class="l"><b>${esc(l.name)}</b><span class="small muted">${l.qty} × ${esc(V.fm(l.unitPrice))}</span></div><div class="r"><b>${esc(V.fm(Math.round(l.qty * l.unitPrice)))}</b></div></div>`).join("")}</div>
  <div class="kv" style="margin-top:8px"><span>Subtotal</span><b>${esc(V.fm(L.saleSubtotal(sale)))}</b>${sale.discount ? `<span>Discount</span><b>−${esc(V.fm(sale.discount))}</b>` : ""}<span>Total (revenue)</span><b>${esc(V.fm(L.saleTotal(sale)))}</b>
  ${sale.fee ? `<span>Seller fees</span><b>${esc(V.fm(sale.fee))}</b>` : ""}<span>Cost of goods</span><b>${cogs === null ? "unknown" : esc(V.fm(cogs))}</b>
  <span>Received</span><b>${esc(V.fm(L.cashOnSale(s.db, id)))}</b><span>Still owed</span><b class="${d.balance > 0 ? "warnc" : ""}">${esc(V.fm(sale.voided ? 0 : d.balance))}</b>${sale.dueDate ? `<span>Due</span><b>${esc(V.fd(sale.dueDate))}</b>` : ""}</div></div>
  ${pays.length ? `<div class="card"><h3>Payments</h3><div class="list">${pays.map((p) => `<div class="item"><div class="l"><b ${p.voided ? 'style="text-decoration:line-through"' : ""}>${p.kind === "adjustment" ? "Adjustment" : "Payment"} · ${esc(V.fm(p.amount))}</b><span class="small muted">${esc(V.fd(p.date))} · ${esc(p.method)}${p.note ? ` · ${esc(p.note)}` : ""}${p.voided ? " · reversed" : ""}</span></div>${!p.voided && !sale.voided ? `<div class="r"><button class="btn ghost small" data-a="confirm" data-id="${esc(p.id)}" data-do="void-payment" data-msg="Reverse this ${p.kind}? The balance will increase again.">Reverse</button></div>` : ""}</div>`).join("")}</div></div>` : ""}
  ${!sale.voided ? `<div class="actions" style="margin-bottom:8px">
    ${d.balance > 0 ? `<button class="btn" data-a="open" data-m="payment" data-sale="${esc(id)}">Record payment</button>` : ""}
    ${d.balance > 0 && cust ? `<button class="btn secondary" data-a="open" data-m="reminder" data-sale="${esc(id)}">Prepare reminder</button>` : ""}
    <button class="btn secondary" data-a="open" data-m="sale" data-id="${esc(id)}">Edit</button>
    ${cust ? `<button class="btn secondary" data-a="open" data-m="adjust" data-sale="${esc(id)}">Adjustment</button>` : ""}
    <button class="btn danger" data-a="confirm" data-id="${esc(id)}" data-do="void-sale" data-msg="Void this sale? Its stock is returned and its payments are reversed. Any cash you already collected must be refunded outside the app.">Void sale</button></div>` : ""}`;
}

// ---------- payments ----------
function paymentForm(V   , saleId         , customerId         )         {
  const key = L.newId();
  if (saleId) {
    const sale = V.s.db.sales.find((s) => s.id === saleId) ;
    const d = L.debtOf(V.s.db, sale, V.today);
    return `${head("Record a payment")}<p class="muted small">${esc(sale.ref)} · owed ${esc(V.fm(d.balance))}</p>
    <form data-form="payment" data-sale="${esc(saleId)}" autocomplete="off"><input type="hidden" name="key" value="${esc(key)}">
    <label>Amount received (${esc(V.currency)})</label><input name="amount" inputmode="decimal" required value="${plain(d.balance, V.currency)}">
    <div class="two"><div><label>Date</label><input type="date" name="date" value="${esc(V.today)}" required></div><div><label>Method</label>${methodSelect()}</div></div>
    <label>Note (optional)</label><input name="note"><p class="tiny muted">A partial amount is fine — the balance and reminder amount update immediately.</p>
    <button class="btn block" style="margin-top:12px">Save payment</button></form>`;
  }
  const c = V.s.db.customers.find((x) => x.id === customerId);
  const owed = L.openDebts(V.s.db, V.today).filter((d) => d.customerId === customerId).reduce((t, d) => t + d.balance, 0);
  return `${head("Record a payment")}<p class="muted small">${esc(c?.name ?? "")} owes ${esc(V.fm(owed))}. Payments go to the oldest debt first.</p>
  <form data-form="payment" data-customer="${esc(customerId ?? "")}" autocomplete="off"><input type="hidden" name="key" value="${esc(key)}">
  <label>Amount received (${esc(V.currency)})</label><input name="amount" inputmode="decimal" required value="${plain(owed, V.currency)}">
  <div class="two"><div><label>Date</label><input type="date" name="date" value="${esc(V.today)}" required></div><div><label>Method</label>${methodSelect()}</div></div>
  <button class="btn block" style="margin-top:12px">Save payment</button></form>`;
}
function pickCustomer(V   )         {
  const debts = L.openDebts(V.s.db, V.today);
  const ids = [...new Set(debts.map((d) => d.customerId ))];
  return `${head("Who paid you?")}${ids.length ? `<div class="card"><div class="list">${ids.map((id) => { const c = V.s.db.customers.find((x) => x.id === id) ; const owed = debts.filter((d) => d.customerId === id).reduce((t, d) => t + d.balance, 0);
    return `<button class="item" data-a="open" data-m="payment" data-customer="${esc(id)}"><div class="l"><b>${esc(c.name)}</b></div><div class="r"><b>${esc(V.fm(owed))}</b></div></button>`; }).join("")}</div></div>` : `<p class="muted">Nobody owes you money right now.</p>`}`;
}
function adjustForm(V   , saleId        )         {
  const sale = V.s.db.sales.find((s) => s.id === saleId) ;
  const d = L.debtOf(V.s.db, sale, V.today);
  return `${head("Debt adjustment")}<p class="muted small">${esc(sale.ref)} · currently owed ${esc(V.fm(d.balance))}</p>
  <p class="notice">Use this for a discount, write-off or correction — not for cash received (use “Record payment”). Enter a positive amount to reduce what is owed, or a negative amount to reopen part of a debt. A reason is required and kept in the history.</p>
  <form data-form="adjust" data-sale="${esc(saleId)}" autocomplete="off"><label>Amount (${esc(V.currency)})</label><input name="amount" inputmode="decimal" required placeholder="e.g. 5 or -5">
  <label>Date</label><input type="date" name="date" value="${esc(V.today)}" required><label>Reason</label><input name="reason" required placeholder="e.g. goodwill discount"><button class="btn block" style="margin-top:12px">Save adjustment</button></form>`;
}

// ---------- expenses ----------
function expenseForm(V   , id         )         {
  const e = id ? V.s.db.expenses.find((x) => x.id === id) : undefined;
  return `${head(e ? "Edit expense" : "Record an expense")}
  <form data-form="expense" data-id="${esc(id ?? "")}" autocomplete="off">
    <label>Description</label><input name="description" required value="${esc(e?.description ?? "")}" placeholder="e.g. Delivery to customer">
    <div class="two"><div><label>Amount (${esc(V.currency)})</label><input name="amount" inputmode="decimal" required value="${e ? plain(e.amount, V.currency) : ""}"></div><div><label>Date</label><input type="date" name="date" required value="${esc(e?.date ?? V.today)}"></div></div>
    <div class="two"><div><label>Category</label><select name="category">${V.s.db.expenseCategories.map((c) => `<option ${c === (e?.category ?? "Other expenses") ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></div><div><label>Or a new category</label><input name="newCategory" placeholder="Custom"></div></div>
    <div class="two"><div><label>Paid by</label>${methodSelect(e?.method)}</div><div><label>Supplier (optional)</label><input name="supplier" value="${esc(e?.supplier ?? "")}"></div></div>
    <label>Notes (optional)</label><input name="notes" value="${esc(e?.notes ?? "")}">
    <button class="btn block" style="margin-top:12px">${e ? "Save changes" : "Save expense"}</button></form>`;
}
function expenseView(V   , id        )         {
  const e = V.s.db.expenses.find((x) => x.id === id);
  if (!e) return head("Expense") + "<p>Not found.</p>";
  return `${head("Expense")}<div class="card"><h3>${esc(e.description)}</h3><div class="kv" style="margin-top:8px"><span>Amount</span><b>${esc(V.fm(e.amount))}</b><span>Category</span><b>${esc(e.category)}</b><span>Date</span><b>${esc(V.fd(e.date))}</b><span>Paid by</span><b>${esc(e.method)}</b>${e.supplier ? `<span>Supplier</span><b>${esc(e.supplier)}</b>` : ""}</div>${e.notes ? `<p class="small muted">${esc(e.notes)}</p>` : ""}${e.voided ? `<p class="badge overdue">Reversed</p>` : ""}</div>
  ${e.voided ? "" : `<div class="actions"><button class="btn secondary" data-a="open" data-m="expense" data-id="${esc(id)}">Edit</button><button class="btn danger" data-a="confirm" data-id="${esc(id)}" data-do="void-expense" data-msg="Reverse this expense? It will no longer count in your reports.">Reverse</button></div>`}`;
}

// ---------- customers ----------
function customerForm(V   , id         )         {
  const c = id ? V.s.db.customers.find((x) => x.id === id) : undefined;
  return `${head(c ? "Edit customer" : "Add a customer")}
  <form data-form="customer" data-id="${esc(id ?? "")}" autocomplete="off">
    <label>Name</label><input name="name" required value="${esc(c?.name ?? "")}">
    <label>Phone with country code</label><input name="phone" inputmode="tel" value="${esc(c?.phone ?? "")}" placeholder="+855 12 345 678 or 012 345 678"><span class="tiny muted">Numbers starting with 0 are treated as Cambodian (+855).</span>
    <label>Email (optional)</label><input name="email" type="email" value="${esc(c?.email ?? "")}">
    <button class="btn block" style="margin-top:12px">${c ? "Save changes" : "Save customer"}</button></form>`;
}
function customerView(V   , id        )         {
  const { s } = V;
  const c = s.db.customers.find((x) => x.id === id);
  if (!c) return head("Customer") + "<p>Not found.</p>";
  const debts = L.openDebts(s.db, V.today).filter((d) => d.customerId === id);
  const owed = debts.reduce((t, d) => t + d.balance, 0);
  const phone = c.phone ? normalizePhone(c.phone) : null;
  const rems = s.reminders.filter((r) => r.customerId === id).slice().reverse();
  const adv = V.can("smsReminders");
  const tgConnected = !!c.telegramChatId;
  const opt = (v        , label        , needsAdv         ) => `<option value="${v}" ${c.channel === v ? "selected" : ""} ${needsAdv && !adv ? "disabled" : ""}>${esc(label)}${needsAdv && !adv ? " (Advanced)" : ""}</option>`;
  // statement: chronological, excludes reversed items
                                                                           
  const rows        = [];
  for (const x of s.db.sales) if (!x.voided && x.customerId === id) rows.push({ date: x.date, text: `Sale ${x.ref}`, debit: L.saleTotal(x), credit: 0 });
  for (const p of s.db.payments) if (!p.voided && p.customerId === id) rows.push({ date: p.date, text: p.kind === "adjustment" ? `Adjustment: ${p.note}` : `Payment (${p.method})`, debit: p.amount < 0 ? -p.amount : 0, credit: p.amount > 0 ? p.amount : 0 });
  rows.sort((a, b) => a.date.localeCompare(b.date));
  let run = 0;
  return `${head(c.name)}
  <p class="muted small">${esc(c.phone || "No phone")}${c.phone && !phone ? ` <span class="neg">· not a valid international number</span>` : ""}${c.email ? ` · ${esc(c.email)}` : ""}</p>
  <div class="grid2" style="margin-bottom:12px">${stat("Owes you", esc(V.fm(owed)), `${debts.length} open debt${debts.length === 1 ? "" : "s"}`, owed ? "warnc" : "")}${stat("Status", debts.some((d) => d.status === "overdue") ? badge("overdue") : owed ? badge(debts.some((d) => d.partiallyPaid) ? "partial" : "unpaid") : badge("paid"))}</div>
  <div class="actions" style="margin-bottom:12px">${owed ? `<button class="btn" data-a="open" data-m="payment" data-customer="${esc(id)}">Record payment</button>` : ""}<button class="btn secondary" data-a="open" data-m="customer" data-id="${esc(id)}">Edit</button></div>
  ${debts.length ? `<div class="card"><h3>Open debts</h3><div class="list">${debts.map((d) => `<div class="item"><div class="l"><b>${esc(d.ref)} · ${esc(V.fm(d.balance))}</b><span class="small muted">of ${esc(V.fm(d.original))} · due ${esc(V.fd(d.dueDate))}</span></div><div class="r">${badge(d.status)}<br><button class="btn ghost small" style="margin-top:6px" data-a="open" data-m="reminder" data-sale="${esc(d.saleId)}">Reminder</button></div></div>`).join("")}</div></div>` : ""}
  <div class="card"><h3>Reminder preferences</h3>
    <label>Channel</label><select data-a-change="cust-channel" data-id="${esc(id)}">${opt("manual", "Manual follow-up (no automated messages)", false)}${opt("sms", "SMS only", true)}${opt("telegram", "Telegram only", true)}${opt("both", "SMS and Telegram", true)}</select>
    ${!adv ? `<p class="tiny muted">Automated SMS and Telegram reminders are part of FI Money Advanced. On every plan you can copy a reminder message and send it yourself.</p>` : ""}
    <label class="check"><input type="checkbox" data-a-toggle-cust="optOut" data-id="${esc(id)}" ${c.optOut ? "checked" : ""}> Customer opted out — never send reminders</label>
    <label class="check"><input type="checkbox" data-a-toggle-cust="paused" data-id="${esc(id)}" ${c.paused ? "checked" : ""}> Pause reminders for this customer</label>
    <div class="status-row"><div><b>Telegram</b><br><span class="small muted">${tgConnected ? (String(c.telegramChatId).startsWith("dev-mock-") ? "Connected (development mock)" : "Connected") : "Not connected"}</span></div>
    ${tgConnected ? `<button class="btn ghost small" data-a="tg-disconnect" data-id="${esc(id)}">Disconnect</button>` : `<button class="btn secondary small" data-a="tg-connect" data-id="${esc(id)}">Connect…</button>`}</div></div>
  <div class="card"><details><summary>Account statement</summary>${rows.length ? `<div class="scroll-x"><table><tr><th>Date</th><th>Entry</th><th>Charged</th><th>Paid</th><th>Balance</th></tr>${rows.map((r) => { run += r.debit - r.credit; return `<tr><td>${esc(V.fd(r.date))}</td><td>${esc(r.text)}</td><td>${r.debit ? esc(V.fm(r.debit)) : ""}</td><td>${r.credit ? esc(V.fm(r.credit)) : ""}</td><td>${esc(V.fm(run))}</td></tr>`; }).join("")}</table></div>` : `<p class="muted small">No activity yet.</p>`}</details></div>
  <div class="card"><details><summary>Reminders sent (${rems.length})</summary>${rems.length ? rems.map((r) => `<div class="item"><div class="l"><b>${r.channel === "sms" ? "SMS" : "Telegram"}</b><span class="small muted">${esc(r.triggerDate)}</span></div><div class="r small">${esc(statusLabel(r))}</div></div>`).join("") : `<p class="muted small">None yet.</p>`}</details></div>`;
}

// ---------- reminders (preview) ----------
function reminderPreview(V   , saleId        )         {
  const { s } = V;
  const sale = s.db.sales.find((x) => x.id === saleId);
  const debt = sale ? L.debtOf(s.db, sale, V.today) : null;
  const cust = sale ? s.db.customers.find((c) => c.id === sale.customerId) : null;
  if (!sale || !debt || !cust) return head("Reminder") + "<p>Not found.</p>";
  if (debt.balance <= 0) return head("Reminder") + `<p class="notice">This debt is fully paid — no reminder needed.</p>`;
  const msg = buildMessage(s.reminderSettings.template, debt, cust, s.business.name, V.currency);
  const adv = V.can("smsReminders");
  const chBtn = (ch         ) => {
    const fake           = { id: "preview", key: "", saleId, customerId: cust.id, channel: ch, status: "draft", triggerDate: V.today, body: msg.text, createdAt: "", sentAt: null, attempts: 0, provider: null, providerIsMock: false, providerMessageId: null, error: null, origin: "manual", log: [] };
    const b = blockersFor(fake, { db: s.db, settings: s.reminderSettings, config: V.channels, reminders: s.reminders, now: V.now, tz: s.business.timezone, automationAllowed: adv, businessName: s.business.name, currency: V.currency });
    const reasons = [...b.permanent, ...b.transient];
    const label = ch === "sms" ? "SMS" : "Telegram";
    return `<div class="status-row"><div><b>Send by ${label}</b>${reasons.length ? `<br><span class="small muted">${esc(reasons[0])}</span>` : `<br><span class="small muted">${V.s.useMockProviders ? "MOCK provider — nothing real is sent" : ""}</span>`}</div>
    <button class="btn small" data-a="send-rem" data-sale="${esc(saleId)}" data-ch="${ch}" ${reasons.length ? "disabled" : ""}>Send</button></div>`;
  };
  return `${head("Reminder preview")}<p class="muted small">To ${esc(cust.name)} · remaining ${esc(V.fm(debt.balance))}</p>
  <div class="msgbox" id="rem-msg">${esc(msg.text)}</div>${msg.warnings.map((w) => `<p class="tiny muted">⚠ ${esc(w)}</p>`).join("")}
  <p class="tiny muted">This message always uses the current balance. Keep reminders polite and private.</p>
  <button class="btn block" data-a="copy-msg" data-sale="${esc(saleId)}" style="margin:10px 0">Copy message</button>
  ${cust.optOut ? `<div class="notice warn">${esc(cust.name)} opted out of reminders. Do not contact them about this debt through reminders.</div>` : ""}
  <div class="card"><h3>Automated sending ${adv ? "" : `<span class="badge lock">Advanced</span>`}</h3>
    ${adv ? `${chBtn("sms")}${chBtn("telegram")}<p class="tiny muted">Sending is blocked until a provider is connected on a server${s.devMode ? "; enable MOCK providers in Settings to test the flow" : ""}.</p>` : `<p class="muted small">Copy the message above and send it yourself by SMS, Telegram or any chat app. Automated SMS & Telegram sending is part of ${esc(PLANS[requiredTier("smsReminders")].name)}.</p>`}</div>`;
}

// ---------- products ----------
function productForm(V   , id         )         {
  const p = id ? V.s.db.products.find((x) => x.id === id) : undefined;
  return `${head(p ? "Edit product" : "Add a product or service")}
  <form data-form="product" data-id="${esc(id ?? "")}" autocomplete="off">
    <label>Name</label><input name="name" required value="${esc(p?.name ?? "")}">
    <div class="two"><div><label>SKU (optional)</label><input name="sku" value="${esc(p?.sku ?? "")}"></div><div><label>Type</label><select name="kind" ${p ? "disabled" : ""}><option value="product" ${p?.kind === "product" ? "selected" : ""}>Product (tracks stock)</option><option value="service" ${p?.kind === "service" ? "selected" : ""}>Service (no stock)</option></select></div></div>
    <div class="two"><div><label>Selling price (${esc(V.currency)})</label><input name="price" inputmode="decimal" value="${p ? plain(p.price, V.currency) : ""}" required></div><div><label>Unit cost (${esc(V.currency)})</label><input name="cost" inputmode="decimal" value="${p ? plain(p.cost, V.currency) : ""}"><span class="tiny muted">Needed to calculate profit</span></div></div>
    <div class="two"><div><label>Low-stock alert at</label><input name="lowStockAt" inputmode="numeric" value="${p ? p.lowStockAt : 0}"></div>${p ? "" : `<div><label>Opening stock</label><input name="opening" inputmode="decimal" value="0"></div>`}</div>
    <button class="btn block" style="margin-top:12px">${p ? "Save changes" : "Save product"}</button></form>`;
}
function productView(V   , id        )         {
  const { s } = V;
  const p = s.db.products.find((x) => x.id === id);
  if (!p) return head("Product") + "<p>Not found.</p>";
  const voided = new Set(s.db.sales.filter((x) => x.voided).map((x) => x.id));
  const moves = s.db.stockMoves.filter((m) => m.productId === id && !(m.saleId && voided.has(m.saleId))).slice().reverse().slice(0, 30);
  const st = L.stockOf(s.db, id);
  const from = L.addDays(V.today, -29);
  const pr = V.can("productProfitability") ? R.productProfitability(s.db, from, V.today).find((r) => r.productId === id) : null;
  return `${head(p.name)}<p class="muted small">${esc(p.sku || "No SKU")} · ${p.kind === "service" ? "Service" : "Product"}</p>
  <div class="grid2" style="margin-bottom:12px">${stat("Selling price", esc(V.fm(p.price)))}${stat("Unit cost", p.cost === null ? `<span class="warnc">Not set</span>` : esc(V.fm(p.cost)))}${p.kind === "product" ? stat("In stock", String(st), p.lowStockAt ? `Alert at ${p.lowStockAt}` : "", p.lowStockAt && st <= p.lowStockAt ? "neg" : "") : ""}${p.cost !== null && p.price > 0 ? stat("Margin per unit", `${Math.round(((p.price - p.cost) / p.price) * 1000) / 10}%`, "Price − cost") : ""}</div>
  <div class="actions" style="margin-bottom:12px">${p.kind === "product" ? `<button class="btn" data-a="open" data-m="stock" data-id="${esc(id)}">Add / adjust stock</button>` : ""}<button class="btn secondary" data-a="open" data-m="product" data-id="${esc(id)}">Edit</button></div>
  ${V.can("productProfitability") ? `<div class="card"><h3>Last 30 days</h3>${pr ? `<div class="kv" style="margin-top:6px"><span>Sold</span><b>${pr.qty}</b><span>Revenue</span><b>${esc(V.fm(pr.revenue))}</b><span>Gross profit</span><b>${pr.grossProfit === null ? "needs cost" : esc(V.fm(pr.grossProfit))}</b><span>Gross margin</span><b>${pr.grossMarginPct === null ? "—" : pr.grossMarginPct + "%"}</b></div>` : `<p class="muted small">No sales in the last 30 days.</p>`}</div>` : lockCard(V, "productProfitability", "Product profitability")}
  ${p.kind === "product" ? `<div class="card"><h3>Stock history</h3>${moves.length ? `<div class="list">${moves.map((m) => `<div class="item"><div class="l"><b>${{ opening: "Opening stock", purchase: "Stock purchase", adjustment: "Adjustment", sale: "Sold" }[m.kind]}</b><span class="small muted">${esc(V.fd(m.date))}${m.note ? ` · ${esc(m.note)}` : ""}</span></div><div class="r"><b class="${m.qty < 0 ? "neg" : "pos"}">${m.qty > 0 ? "+" : ""}${m.qty}</b></div></div>`).join("")}</div>` : `<p class="muted small">No movements yet.</p>`}</div>` : ""}
  <button class="btn ghost block small" data-a="confirm" data-do="archive-product" data-id="${esc(id)}" data-msg="Hide this product from lists? Past sales and reports keep it.">Archive product</button>`;
}
function stockForm(V   , productId        )         {
  const p = V.s.db.products.find((x) => x.id === productId) ;
  return `${head(`Stock: ${p.name}`)}<p class="muted small">In stock now: ${L.stockOf(V.s.db, productId)}</p>
  <form data-form="stock" data-product="${esc(productId)}" autocomplete="off">
    <label>What happened?</label><select name="kind" id="stock-kind"><option value="purchase">I bought more stock</option><option value="adjustment">Correction (count, damage, loss)</option></select>
    <div class="two"><div><label>Quantity</label><input name="qty" inputmode="decimal" required placeholder="e.g. 10 (negative to remove)"></div><div><label>Date</label><input type="date" name="date" value="${esc(V.today)}"></div></div>
    <label>Unit cost paid (${esc(V.currency)}) — purchases only</label><input name="unitCost" inputmode="decimal" value="${plain(p.cost, V.currency)}">
    <label>Note (optional)</label><input name="note"><p class="tiny muted">Buying stock is not an expense. It becomes a cost only when the item is sold.</p>
    <button class="btn block" style="margin-top:12px">Save</button></form>`;
}

// ---------- Telegram connection ----------
function telegramSheet(V   , customerId        )         {
  const c = V.s.db.customers.find((x) => x.id === customerId);
  if (!c) return head("Telegram") + "<p>Not found.</p>";
  return `${head(`Connect ${c.name} on Telegram`)}
  <div class="notice warn"><b>Not available in local mode.</b> Telegram only lets a bot message someone who has opened the bot and pressed Start. Connecting needs your Telegram bot and a small server that receives that Start message.</div>
  <div class="card"><h3>How it will work</h3><ol class="small" style="padding-left:18px;margin:8px 0">
    <li>You create a bot with Telegram's @BotFather and keep its token on your server.</li>
    <li>FI Money shows ${esc(c.name)} a one-time link (and QR code) that opens your bot.</li>
    <li>${esc(c.name)} presses <b>Start</b>. Your server links their chat to this customer.</li>
    <li>You can then send reminders. The customer can stop them at any time.</li></ol>
    <p class="tiny muted">We never ask for anyone's Telegram password, and never message usernames that have not started the bot.</p></div>
  ${V.s.devMode ? `<div class="card"><h3>Development only</h3><p class="small muted">Pretend this customer pressed Start. This creates a clearly-labelled mock connection so you can test the screens. It does not contact Telegram.</p><button class="btn secondary block" data-a="tg-mock" data-id="${esc(customerId)}">Simulate “Start” (mock)</button></div>` : ""}`;
}

// ---------- manual subscription payment (KHQR / bank transfer) ----------
function planRequestSheet(V   , tier                    )         {
  const c = CONFIG.payment;
  const plan = PLANS[tier];
  const existing = V.s.paymentRequests.find((r) => r.tier === tier && r.status === "awaiting_confirmation");
  const ref = existing?.reference ?? "(created when you save)";
  return `${head(`Pay for ${plan.name.replace("FI Money ", "")}`)}
  <div class="notice warn"><b>Your plan does not switch on when you tap anything here.</b> It switches on only after your payment is confirmed on our side.</div>
  <div class="card"><div class="kv"><span>Amount</span><b>${esc(formatMoney(plan.priceMonthlyMinor, plan.currency))} / month</b>
    ${c.methodName ? `<span>Pay by</span><b>${esc(c.methodName)}</b>` : ""}${c.accountName ? `<span>Account name</span><b>${esc(c.accountName)}</b>` : ""}${c.accountNumber ? `<span>Account number</span><b>${esc(c.accountNumber)}</b>` : ""}
    <span>Payment note / reference</span><b>${esc(ref)}</b></div>
    ${c.qrImage ? `<img src="${esc(c.qrImage)}" alt="Payment QR code" style="width:100%;max-width:280px;display:block;margin:12px auto;border-radius:12px;background:#fff">` : ""}
    ${c.instructions ? `<p class="small">${esc(c.instructions)}</p>` : ""}
    <p class="tiny muted">Amounts are in US dollars. Write the reference in the payment note so we can match your payment.${c.contact ? ` Questions or proof of payment: ${esc(c.contact)}.` : ""}</p></div>
  ${existing ? `<button class="btn secondary block" data-a="copy-ref" data-ref="${esc(existing.reference)}">Copy reference</button><button class="btn ghost block" style="margin-top:8px" data-a="cancel-request" data-ref="${esc(existing.reference)}">Cancel this request</button>`
    : `<button class="btn block" data-a="save-request" data-tier="${tier}">Create my payment reference</button>`}`;
}
