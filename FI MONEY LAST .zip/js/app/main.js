// FI Money — controller: owns state, handles events, calls the engine, re-renders.
// All money rules live in ../engine; this file only translates taps and forms into engine calls.
import * as L from "../engine/ledger.js";
import * as R from "../engine/reports.js";
import { parseMoney, formatMoney, formatAmount, minorDigits, mulQty } from "../engine/money.js";
import { hasFeature, effectiveTier, FREE_SUBSCRIPTION, newPaymentRequest } from "../engine/entitlements.js";
                                                         
import * as M from "../engine/reminders.js";
import { CONFIG, paymentConfigured, cloudEnabled, defaultState, demoState, loadState, saveState, eraseState, getMode, setMode, setNamespace, loadSyncMeta, saveSyncMeta, clearUserCache, COUNTRIES } from "./state.js";
                                                           
import { createCloud, CloudError } from "./cloud.js";
import { checkPassword, checkEmail } from "../engine/auth.js";
import { authView, syncBanner, adminPage, emptyAdmin } from "./account.js";
                                                      
                                                              
                                                             
import { esc, fmtDate, toast, copyText, download, val } from "./ui.js";
import * as views from "./views.js";
import { reminders as remindersView, reports as reportsView } from "./views-reminders.js";

let mode       = getMode();
let s           = loadState(mode);
const root = document.getElementById("app") ;

function safeToday(tz        , now      )         {
  try { return M.todayIn(tz, now); } catch { return now.toISOString().slice(0, 10); }
}
const freshUi = ()          => {
  const t = safeToday(s.business.timezone, new Date());
  return { tab: "home", moneySeg: "sales", debtSeg: "debtors", morePage: null, range: "month", from: L.addDays(t, -29), to: t,
    salesQ: "", salesFilter: "all", expQ: "", expCat: "all", debtQ: "", debtFilter: "all", debtSort: "amount", stockQ: "",
    remTab: "follow", modal: null, calc: {} };
};
let ui          = freshUi();

// ---------- account & cloud state ----------
const kv = {
  get: (k        )                => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k        , v        )       => { try { localStorage.setItem(k, v); } catch { /* blocked */ } },
  remove: (k        )       => { try { localStorage.removeItem(k); } catch { /* blocked */ } },
};
const cloud = createCloud({ url: CONFIG.cloud.url, anonKey: CONFIG.cloud.anonKey }, { fetch: (...a) => fetch(...a), store: kv, now: () => Date.now() });
let auth         = { screen: "loading", email: "", error: "", info: "", busy: false };
let inApp = false;                        // true once signed in and loaded (or in local preview)
let cl          = { signedIn: false, email: "", fullName: "", status: "off", lastSyncedAt: null, isAdmin: false, note: "" };
let meta           = { version: 0, dirty: false, businessId: null, lastSyncedAt: null };
let remoteSub                      = null;   // plan as stored on the SERVER (never taken from browser storage)
let admin            = emptyAdmin();
let stashedRemote                                             = null;
const redirectUrl = ()         => location.origin + location.pathname;

// ---------- view model ----------
function buildV()    {
  const now = new Date();
  const today = safeToday(s.business.timezone, now);
  // serverVerified is false until a real backend verifies billing events (CONFIG.backendUrl is the hook for that).
  const tier = cl.signedIn
    ? effectiveTier(remoteSub ?? FREE_SUBSCRIPTION, { devMode: false, now, serverVerified: remoteSub !== null })   // signed in: ONLY the server's record counts
    : effectiveTier(s.subscription, { devMode: CONFIG.devTools && s.devMode, now, serverVerified: false });
  const cur = s.business.currency;
  let from = today, to = today, label = "Today";
  if (ui.range === "7d") { from = L.addDays(today, -6); label = "Last 7 days"; }
  else if (ui.range === "month") { from = today.slice(0, 8) + "01"; label = "This month"; }
  else if (ui.range === "custom") { from = ui.from <= ui.to ? ui.from : ui.to; to = ui.from <= ui.to ? ui.to : ui.from; label = "Custom"; }
  const mock = s.useMockProviders && CONFIG.devTools;
  return {
    s, ui, today, tier, mode, now, cloud: cl, currency: cur, range: { from, to, label },
    can: (f         ) => hasFeature(tier, f), fm: (n) => (n === null ? "—" : formatMoney(n, cur)), fd: (d) => fmtDate(d, s.business.dateFormat),
    channels: { smsConfigured: mock, telegramConfigured: mock },
  };
}
const providers = ()                                               =>
  s.useMockProviders && CONFIG.devTools ? { sms: smsMock, telegram: tgMock } : null;
const smsMock = M.mockProvider("sms");
const tgMock = M.mockProvider("telegram");

function sendCtx(V   )                {
  return { db: s.db, settings: s.reminderSettings, config: V.channels, reminders: s.reminders, now: V.now, tz: s.business.timezone,
    automationAllowed: V.can("automatedReminders"), businessName: s.business.name, currency: V.currency };
}

// ---------- render ----------
function render()       {
  const active = document.activeElement                      ;
  const focusKey = active?.getAttribute?.("data-a-input") ?? null;
  const pos = (active                           )?.selectionStart ?? null;
  const scrollY = window.scrollY;
  if (!inApp) { root.innerHTML = authView(auth, CONFIG.devTools); return; }
  const V = buildV();
  if (mode === "real" && !s.business.setupDone) { root.innerHTML = views.onboarding(V); return; }
  let body = "";
  switch (ui.tab) {
    case "home": body = views.home(V); break;
    case "money": body = views.money(V); break;
    case "debtors": body = views.debtors(V); break;
    case "stock": body = views.stock(V); break;
    case "more":
      body = ui.morePage === "calculator" ? views.calculator(V) : ui.morePage === "reports" ? reportsView(V) : ui.morePage === "reminders" ? remindersView(V)
        : ui.morePage === "plans" ? views.plans(V) : ui.morePage === "admin" ? adminPage(V, admin) : ui.morePage === "settings" ? views.settings(V) : ui.morePage === "status" ? views.status(V) : views.more(V);
  }
  root.innerHTML = views.shell(V, body);
  if (focusKey) {
    const el = root.querySelector                  (`[data-a-input="${focusKey}"]`);
    if (el) { el.focus(); if (pos !== null) try { el.setSelectionRange(pos, pos); } catch { /* ignore */ } }
  }
  window.scrollTo(0, scrollY);
  if (ui.modal) updateSaleTotal();
}

/** Save, run housekeeping (cancel reminders that are no longer needed), and redraw. */
function commit()       {
  const V = buildV();
  if (s.reminders.length) {
    s.reminders = M.markUnknown(M.cancelStale(s.reminders, sendCtx(V)), V.now, s.reminderSettings.unknownAfterHours);
  }
  saveState(mode, s);
  if (cl.signedIn && s.business.setupDone) { meta.dirty = true; saveSyncMeta(meta); localRev++; if (cl.status !== "conflict") { cl.status = "unsynced"; } schedulePush(); }
  render();
}
function fail(e         )       {
  toast(e instanceof L.LedgerError ? e.message : "Something went wrong. Nothing was saved.", "error");
  if (!(e instanceof L.LedgerError)) console.error(e);
}
const money = (f          , k        )                        => {
  const t = val(f, k);
  if (t === "") return null;
  const n = parseMoney(t, s.business.currency);
  return n === null ? "bad" : n;
};
const needMoney = (f          , k        , label        )         => {
  const n = money(f, k);
  if (n === null || n === "bad") throw new L.LedgerError(`${label} must be a valid amount.`);
  return n;
};
const optMoney = (f          , k        , label        )                => {
  const n = money(f, k);
  if (n === "bad") throw new L.LedgerError(`${label} must be a valid amount.`);
  return n;
};
const plain = (n        )         => (n / 10 ** minorDigits(s.business.currency)).toFixed(minorDigits(s.business.currency));
const validTz = (tz        )          => { try { new Intl.DateTimeFormat("en", { timeZone: tz }); return true; } catch { return false; } };

// ---------- forms ----------
function saleLines(form                 )                                                                                {
  const out                                                                                = [];
  form.querySelectorAll             ("[data-line]").forEach((row) => {
    const pid = (row.querySelector("[name=pid]")                     ).value;
    const name = (row.querySelector("[name=pname]")                    ).value.trim();
    const qtyT = (row.querySelector("[name=qty]")                    ).value.trim().replace(/,/g, "");
    const priceT = (row.querySelector("[name=price]")                    ).value.trim();
    if (!pid && !name && !priceT) return; // untouched empty row
    const qty = Number(qtyT || "1");
    let unitPrice                = priceT === "" ? null : parseMoney(priceT, s.business.currency);
    if (priceT !== "" && unitPrice === null) throw new L.LedgerError("A price is not a valid amount.");
    if (unitPrice === null && pid) unitPrice = s.db.products.find((p) => p.id === pid)?.price ?? 0;
    if (unitPrice === null) throw new L.LedgerError("Enter a price for each item.");
    if (!pid && !name) throw new L.LedgerError("Give each custom item a name.");
    if (!(qty > 0) || !Number.isFinite(qty)) throw new L.LedgerError("Quantity must be greater than zero.");
    out.push({ productId: pid || null, name: pid ? undefined : name, qty, unitPrice });
  });
  return out;
}
function updateSaleTotal()       {
  const form = root.querySelector                 ('form[data-form="sale"]');
  if (!form) return;
  try {
    const f = new FormData(form);
    const lines = saleLines(form);
    const discount = optMoney(f, "discount", "Discount") ?? 0;
    const total = lines.reduce((t, l) => t + mulQty(l.unitPrice, l.qty), 0) - discount;
    root.querySelector("#sale-total") .textContent = formatMoney(total, s.business.currency);
    const paid = optMoney(f, "paidNow", "Paid now");
    const hint = root.querySelector("#sale-hint");
    const cust = val(f, "customerId");
    if (hint && !form.dataset.id) {
      hint.textContent = !cust ? "Walk-in sales are recorded as paid in full."
        : paid !== null && paid < total ? `${formatMoney(total - paid, s.business.currency)} will be recorded as owed by this customer.`
        : paid === null || paid === 0 ? `The whole ${formatMoney(total, s.business.currency)} will be recorded as owed by this customer.` : "Paid in full.";
    }
  } catch { root.querySelector("#sale-total") .textContent = "—"; }
}

function onSubmit(form                 )       {
  const f = new FormData(form);
  const name = form.dataset.form ;
  if (["register", "signin", "forgot", "reset"].includes(name)) { void authForm(name, f); return; }
  if (["profile", "changepw", "support", "deleteacct", "adminplan"].includes(name)) { void accountForm(name, f, form); return; }
  if (name === "setup" && cl.signedIn) { void cloudSetup(f); return; }
  const V = buildV();
  try {
    switch (name) {
      case "setup": case "business": {
        const biz = s.business;
        const tz = val(f, "timezone");
        if (!validTz(tz)) throw new L.LedgerError("That time zone is not recognised. Example: Asia/Phnom_Penh");
        const bname = val(f, "name");
        if (!bname) throw new L.LedgerError("Business name is required.");
        const cur = f.get("currency") ? val(f, "currency") : biz.currency;
        const next = { ...biz, name: bname, type: val(f, "type") || biz.type, currency: cur, timezone: tz,
          dateFormat: (val(f, "dateFormat")                                      ) || biz.dateFormat, country: f.has("country") ? val(f, "country") : biz.country,
          phone: f.has("phone") ? val(f, "phone") : biz.phone, email: f.has("email") ? val(f, "email") : biz.email, setupDone: true };
        s.business = next;
        const sc = f.get("startingCash") !== null && val(f, "startingCash") !== "" ? parseMoney(val(f, "startingCash"), cur) : null;
        if (val(f, "startingCash") !== "" && sc === null) throw new L.LedgerError("Starting cash must be a valid amount.");
        s.business.startingCash = sc;
        ui = name === "setup" ? freshUi() : ui;
        toast(name === "setup" ? "Welcome to FI Money!" : "Saved");
        break;
      }
      case "range": ui.from = val(f, "from") || ui.from; ui.to = val(f, "to") || ui.to; break;
      case "sale": {
        const lines = saleLines(form);
        const discount = optMoney(f, "discount", "Discount") ?? 0;
        const fee = optMoney(f, "fee", "Fees") ?? 0;
        const id = form.dataset.id || undefined;
        const customerId = val(f, "customerId") || null;
        const total = lines.reduce((t, l) => t + mulQty(l.unitPrice, l.qty), 0) - discount;
        let paidNow = id ? 0 : optMoney(f, "paidNow", "Paid now") ?? 0;
        if (!id && !customerId) paidNow = total; // walk-in sales are paid in full
        s.db = L.saveSale(s.db, { id, date: val(f, "date"), customerId, lines, discount, fee, dueDate: val(f, "dueDate") || null,
          note: val(f, "note"), paidNow: paidNow > 0 ? paidNow : undefined, method: val(f, "method") || "Cash" });
        ui.modal = null; toast(id ? "Sale updated" : "Sale saved");
        break;
      }
      case "payment": {
        const amount = needMoney(f, "amount", "Amount");
        const date = val(f, "date"), method = val(f, "method") || "Cash";
        if (form.dataset.sale) s.db = L.recordPayment(s.db, { saleId: form.dataset.sale, amount, date, method, note: val(f, "note"), key: val(f, "key") || null });
        else s.db = L.recordCustomerPayment(s.db, form.dataset.customer , amount, date, method, V.today);
        ui.modal = null; toast("Payment saved");
        break;
      }
      case "adjust":
        s.db = L.recordAdjustment(s.db, form.dataset.sale , needMoney(f, "amount", "Amount"), val(f, "date"), val(f, "reason"));
        ui.modal = null; toast("Adjustment saved");
        break;
      case "expense": {
        const cat = val(f, "newCategory") || val(f, "category");
        const data = { description: val(f, "description"), amount: needMoney(f, "amount", "Amount"), date: val(f, "date"), category: cat,
          method: val(f, "method"), supplier: val(f, "supplier"), notes: val(f, "notes") };
        s.db = form.dataset.id ? L.updateExpense(s.db, form.dataset.id, data) : L.addExpense(s.db, data);
        ui.modal = null; toast("Expense saved");
        break;
      }
      case "customer": {
        const nm = val(f, "name");
        const phoneRaw = val(f, "phone");
        let phone = "";
        if (phoneRaw) {
          const n = M.normalizePhone(phoneRaw);
          if (!n) throw new L.LedgerError("That phone number is not valid. Use the country code, e.g. +855 12 345 678.");
          phone = n;
        }
        s.db = form.dataset.id ? L.updateCustomer(s.db, form.dataset.id, { name: nm, phone, email: val(f, "email") }) : L.addCustomer(s.db, { name: nm, phone, email: val(f, "email") });
        ui.modal = null; toast("Customer saved");
        break;
      }
      case "product": {
        const price = needMoney(f, "price", "Selling price");
        const cost = optMoney(f, "cost", "Unit cost");
        const low = Math.max(0, Math.floor(Number(val(f, "lowStockAt") || "0")) || 0);
        if (form.dataset.id) s.db = L.updateProduct(s.db, form.dataset.id, { name: val(f, "name"), sku: val(f, "sku"), price, cost, lowStockAt: low });
        else {
          const opening = Number(val(f, "opening").replace(/,/g, "") || "0");
          if (!Number.isFinite(opening) || opening < 0) throw new L.LedgerError("Opening stock must be zero or more.");
          s.db = L.addProduct(s.db, { name: val(f, "name"), sku: val(f, "sku"), kind: val(f, "kind") === "service" ? "service" : "product", price, cost, lowStockAt: low }, opening, V.today);
        }
        ui.modal = null; toast("Product saved");
        break;
      }
      case "stock": {
        const qty = Number(val(f, "qty").replace(/,/g, ""));
        if (!Number.isFinite(qty)) throw new L.LedgerError("Quantity must be a number.");
        const kind = val(f, "kind") === "adjustment" ? "adjustment" : "purchase";
        s.db = L.recordStock(s.db, form.dataset.product , qty, kind, val(f, "date") || V.today, kind === "purchase" ? optMoney(f, "unitCost", "Unit cost") : null, val(f, "note"));
        ui.modal = null; toast("Stock updated");
        break;
      }
      case "remsettings": {
        const ints = (k        , lo        , hi        )           => {
          const t = val(f, k);
          if (!t) return [];
          const arr = t.split(/[,\s]+/).filter(Boolean).map(Number);
          if (arr.some((n) => !Number.isInteger(n) || n < lo || n > hi)) throw new L.LedgerError(`Use whole numbers between ${lo} and ${hi}, separated by commas.`);
          return [...new Set(arr)].sort((a, b) => a - b);
        };
        const num = (k        , lo        , hi        , label        )         => {
          const n = Number(val(f, k));
          if (!Number.isInteger(n) || n < lo || n > hi) throw new L.LedgerError(`${label} must be a whole number from ${lo} to ${hi}.`);
          return n;
        };
        const tpl = val(f, "template");
        if (!tpl) throw new L.LedgerError("The message template cannot be empty.");
        s.reminderSettings = { ...s.reminderSettings, paused: f.has("paused"), beforeDays: ints("before", 1, 90), onDueDate: f.has("onDue"), afterDays: ints("after", 1, 365),
          quietStart: val(f, "quietStart") || "21:00", quietEnd: val(f, "quietEnd") || "08:00", minHoursBetween: num("minHours", 1, 720, "Minimum hours"),
          maxPerDebt: num("maxPer", 1, 50, "Maximum reminders"), maxRetries: num("retries", 0, 5, "Retries"), bothMode: val(f, "bothMode") === "sequence" ? "sequence" : "together", template: tpl };
        toast("Reminder settings saved");
        break;
      }
      case "calc": return;
    }
    commit();
    if (name === "business") void patchBusiness();
  } catch (e) { fail(e); }
}

// ---------- reminders ----------
async function runReminders()                {
  const V = buildV();
  if (!V.can("automatedReminders")) { toast("Automated reminders are part of FI Money Advanced.", "error"); return; }
  const created = M.planAutomatic({ db: s.db, reminders: s.reminders, settings: s.reminderSettings, businessName: s.business.name, currency: V.currency, now: V.now, tz: s.business.timezone });
  let list = [...s.reminders, ...created];
  list = M.cancelStale(list, { ...sendCtx(V), reminders: list });
  const prov = providers();
  let submitted = 0;
  if (prov) {
    for (let i = 0; i < list.length; i++) {
      const r = list[i];
      if (r.origin !== "automatic" || !["scheduled", "pending"].includes(r.status)) continue;
      const out = await M.dispatchReminder(r, prov[r.channel], { ...sendCtx(V), reminders: list });
      if (out.status === "submitted") submitted++;
      list[i] = out;
    }
  }
  s.reminders = list;
  commit();
  toast(prov ? `${created.length} prepared, ${submitted} submitted to the MOCK provider (nothing real was sent).`
    : created.length ? `${created.length} reminder${created.length > 1 ? "s" : ""} prepared. Nothing was sent: no SMS/Telegram provider is connected.` : "Nothing new is due.");
}
async function sendManual(saleId        , ch           )                {
  const V = buildV();
  if (!V.can("smsReminders")) { toast("Automated sending is part of FI Money Advanced.", "error"); return; }
  const prov = providers();
  const sale = s.db.sales.find((x) => x.id === saleId);
  const cust = sale && s.db.customers.find((c) => c.id === sale.customerId);
  if (!prov || !sale || !cust) { toast("No provider is connected, so nothing was sent.", "error"); return; }
  const debt = L.debtOf(s.db, sale, V.today);
  const r = M.makeReminder({ settings: s.reminderSettings, businessName: s.business.name, currency: V.currency, now: V.now }, debt, cust, ch,
    `${saleId}:${ch}:manual:${L.newId()}`, V.today, "manual", "pending");
  const out = await M.dispatchReminder(r, prov[ch], { ...sendCtx(V), reminders: s.reminders });
  s.reminders = [...s.reminders, out];
  ui.modal = null;
  commit();
  toast(out.status === "submitted" ? "Submitted to the MOCK provider (nothing real was sent)." : `Not sent: ${out.log.at(-1)?.note ?? "blocked"}`, out.status === "submitted" ? "ok" : "error");
}

// ---------- exports ----------
function csv(kind        )       {
  const V = buildV();
  if (!V.can("csvExport")) { toast("CSV export is part of FI Money Pro.", "error"); return; }
  const d = minorDigits(V.currency);
  const n = (x               )                => (x === null ? null : Number((x / 10 ** d).toFixed(d)));
  const { from, to } = V.range;
  let header          , rows                              ;
  if (kind === "sales") {
    header = ["Ref", "Date", "Customer", "Items", `Total (${V.currency})`, "Discount", "Fees", "Received", "Still owed", "Status"];
    rows = s.db.sales.filter((x) => x.date >= from && x.date <= to).map((x) => {
      const debt = L.debtOf(s.db, x, V.today);
      return [x.ref, x.date, s.db.customers.find((c) => c.id === x.customerId)?.name ?? "Walk-in", x.lines.map((l) => `${l.qty} x ${l.name}`).join("; "),
        n(L.saleTotal(x)), n(x.discount), n(x.fee), n(L.cashOnSale(s.db, x.id)), x.voided ? 0 : n(debt.balance), x.voided ? "voided" : debt.status];
    });
  } else if (kind === "expenses") {
    header = ["Date", "Description", "Category", `Amount (${V.currency})`, "Paid by", "Supplier", "Notes", "Status"];
    rows = s.db.expenses.filter((x) => x.date >= from && x.date <= to).map((x) => [x.date, x.description, x.category, n(x.amount), x.method, x.supplier, x.notes, x.voided ? "reversed" : "active"]);
  } else if (kind === "debts") {
    header = ["Customer", "Invoice", `Original (${V.currency})`, "Paid", "Balance", "Due date", "Days overdue", "Status"];
    rows = R.debtReport(s.db, V.today).map((r) => [r.customer, r.ref, n(r.original), n(r.paid), n(r.balance), r.dueDate ?? "", r.daysOverdue, r.status]);
  } else {
    header = ["Product", "Qty sold", `Revenue (${V.currency})`, "Cost of goods", "Gross profit", "Gross margin %", "Stock now"];
    rows = R.productProfitability(s.db, from, to).map((r) => [r.name, r.qty, n(r.revenue), n(r.cogs), n(r.grossProfit), r.grossMarginPct, r.stock]);
  }
  download(`fi-money-${kind}-${from}_to_${to}.csv`, "text/csv;charset=utf-8", "﻿" + R.toCsv(header, rows));
  toast("CSV downloaded");
}


// ======================= accounts, cloud sync, administrator =======================
let localRev = 0;
let pushTimer                    ;
let pushing = false;
const isNet = (e         )          => e instanceof CloudError && e.code === "network";
const isConflict = (e         )          => e instanceof CloudError && (e.code === "40001" || /version conflict/i.test(e.message));

function showAuth(screen                  , patch                  = {})       {
  inApp = false; auth = { ...auth, screen, error: "", info: "", busy: false, ...patch }; render();
}
function updateBanner()       { const el = document.getElementById("sync-banner"); if (el) el.innerHTML = syncBanner(buildV()); }

function uploadPayload()         {
  // The plan, payment requests and developer switches are never uploaded: the server owns billing.
  return { ...s, subscription: { ...FREE_SUBSCRIPTION }, paymentRequests: [], devMode: false, useMockProviders: false };
}
function normalizeRemote(data                   , row                                                                                               )           {
  const base = defaultState();
  const biz = { ...base.business, ...data.business }                        ;
  if (row) { biz.name = row.name; biz.type = row.business_type; biz.country = row.country; biz.currency = row.currency; biz.timezone = row.timezone; biz.setupDone = true; }
  return { ...base, ...data, business: biz, reminderSettings: { ...base.reminderSettings, ...data.reminderSettings }, db: { ...base.db, ...data.db },
    subscription: { ...FREE_SUBSCRIPTION }, devMode: false, useMockProviders: false, paymentRequests: [] };
}
                                                                                                                         

async function loadPaymentRequests()                {
  const rows = await cloud.select                                                                                                                                                                     ("payment_requests", "select=*&order=created_at.asc");
  s.paymentRequests = rows.map((r) => ({ reference: r.reference, tier: r.tier, amountMinor: r.amount_minor, currency: "USD"         , createdAt: r.created_at, status: r.status }));
}
async function loadServerPlan()                {
  const rows = await cloud.select                                                                                                          ("subscriptions", "select=tier,status,current_period_end");
  const r = rows[0];
  remoteSub = r ? { tier: r.tier, status: r.status, source: "verified_billing", currentPeriodEnd: r.current_period_end } : { ...FREE_SUBSCRIPTION };
}

/** After sign-in: load profile, business, data and plan from the server (or the device copy when offline). */
async function enterAccount()                {
  const sess = cloud.session();
  if (!sess) { showAuth(kv.get("fi-money:hasAccount") ? "signin" : "register"); return; }
  kv.set("fi-money:hasAccount", "1");
  setNamespace(sess.userId); mode = "real";
  cl = { ...cl, signedIn: true, email: sess.email, status: "syncing", note: "" };
  showAuth("loading");
  meta = loadSyncMeta();
  const cache = loadState("real");
  const haveCache = meta.businessId !== null;
  try {
    const profile = (await cloud.select                                                                                           ("profiles", "select=full_name,email,suspended,suspended_reason"))[0];
    cl.fullName = profile?.full_name ?? ""; if (profile?.email) cl.email = profile.email;
    cl.isAdmin = await cloud.rpc         ("is_admin").catch(() => false);
    if (profile?.suspended) { s = haveCache ? cache : defaultState(); showAuth("suspended", { info: profile.suspended_reason ?? "" }); return; }
    const biz = (await cloud.select        ("businesses", "select=id,name,business_type,country,currency,timezone"))[0];
    await loadServerPlan();
    if (!biz) {                                   // brand-new account: onboarding comes next
      s = { ...defaultState(), devMode: false }; meta = { version: 0, dirty: false, businessId: null, lastSyncedAt: null }; saveSyncMeta(meta);
      await loadPaymentRequests().catch(() => undefined);
      cl.status = "synced"; ui = freshUi(); inApp = true; render(); return;
    }
    const rows = await cloud.select                                              ("app_data", `select=data,version&business_id=eq.${biz.id}`);
    const remote = rows[0];
    if (!remote) {                                // business exists but first upload never finished: keep the device copy and upload it
      s = haveCache ? { ...cache, devMode: false, useMockProviders: false } : normalizeRemote({}, biz);
      s.business = { ...s.business, name: biz.name, type: biz.business_type, country: biz.country, currency: biz.currency, timezone: biz.timezone, setupDone: true };
      meta = { ...meta, businessId: biz.id, version: 0, dirty: true };
    } else if (meta.dirty && haveCache && meta.businessId === biz.id) {
      s = { ...cache, devMode: false, useMockProviders: false };
      if (remote.version === meta.version) { /* only this device changed: upload below */ }
      else { stashedRemote = { data: normalizeRemote(remote.data, biz), version: remote.version }; cl.status = "conflict"; }
    } else {
      s = normalizeRemote(remote.data, biz); meta = { version: remote.version, dirty: false, businessId: biz.id, lastSyncedAt: new Date().toISOString() };
    }
    meta.businessId = biz.id; saveSyncMeta(meta); await loadPaymentRequests().catch(() => undefined);
    saveState("real", s); ui = freshUi(); inApp = true;
    cl.lastSyncedAt = meta.lastSyncedAt;
    if (cl.status !== "conflict") { cl.status = meta.dirty ? "unsynced" : "synced"; }
    render();
    if (meta.dirty && cl.status !== "conflict") void pushNow();
  } catch (e) {
    if (e instanceof CloudError && e.code === "signed_out") { showAuth("signin", { info: "Please sign in again." }); return; }
    if (isNet(e) && haveCache) {
      s = { ...cache, devMode: false, useMockProviders: false }; remoteSub = null; ui = freshUi(); inApp = true;
      cl.status = "offline"; cl.lastSyncedAt = meta.lastSyncedAt; render(); return;
    }
    showAuth("loadfail", { error: isNet(e) ? "" : (e instanceof Error ? e.message : "Unknown error") });
  }
}

function schedulePush()       { window.clearTimeout(pushTimer); pushTimer = window.setTimeout(() => void pushNow(), 1200); }
async function pushNow()                {
  if (!cl.signedIn || !meta.businessId || !s.business.setupDone || cl.status === "conflict") return;
  if (pushing) return;
  pushing = true; const rev = localRev; cl.status = "syncing"; updateBanner();
  try {
    const nv = await cloud.rpc        ("save_app_data", { p_business: meta.businessId, p_expected: meta.version, p_data: uploadPayload() });
    meta.version = nv; meta.lastSyncedAt = new Date().toISOString(); meta.dirty = rev !== localRev; saveSyncMeta(meta);
    cl.lastSyncedAt = meta.lastSyncedAt; cl.status = meta.dirty ? "unsynced" : "synced"; cl.note = "";
  } catch (e) {
    if (isConflict(e)) { cl.status = "conflict"; await stashRemote(); }
    else if (isNet(e)) cl.status = "offline";
    else if (e instanceof CloudError && e.code === "signed_out") { pushing = false; showAuth("signin", { info: "Your session ended. Sign in again. Your unsynced changes are kept on this device." }); return; }
    else { cl.status = "error"; cl.note = e instanceof CloudError && e.status === 403 ? "This account cannot save right now (suspended?)." : "Could not reach the server."; }
  }
  pushing = false; updateBanner();
  if (meta.dirty && cl.status === "unsynced") schedulePush();
}
async function stashRemote()                {
  try {
    const rows = await cloud.select                                              ("app_data", `select=data,version&business_id=eq.${meta.businessId}`);
    if (rows[0]) stashedRemote = { data: normalizeRemote(rows[0].data), version: rows[0].version };
  } catch { /* keep going: user can retry */ }
}
window.addEventListener("online", () => { if (cl.signedIn && meta.dirty) void pushNow(); });

async function cloudSetup(f          )                {
  try {
    const bname = val(f, "name"), country = val(f, "country"), tz = val(f, "timezone"), cur = val(f, "currency");
    if (!bname) throw new L.LedgerError("Business name is required.");
    if (!country) throw new L.LedgerError("Please choose your country.");
    if (!validTz(tz)) throw new L.LedgerError("That time zone is not recognised. Example: Asia/Phnom_Penh");
    const sc = val(f, "startingCash") === "" ? null : parseMoney(val(f, "startingCash"), cur);
    if (val(f, "startingCash") !== "" && sc === null) throw new L.LedgerError("Starting cash must be a valid amount.");
    await cloud.insert("businesses", { name: bname, business_type: val(f, "type") || "Retail shop", country, currency: cur, timezone: tz });
    const biz = (await cloud.select        ("businesses", "select=id,name,business_type,country,currency,timezone"))[0];
    if (!biz) throw new L.LedgerError("Could not create your business. Please try again.");
    s.business = { ...s.business, name: bname, type: biz.business_type, country, currency: cur, timezone: tz, dateFormat: (val(f, "dateFormat")                                      ) || "DD/MM/YYYY",
      phone: val(f, "phone"), email: val(f, "email"), startingCash: sc, setupDone: true };
    meta = { version: 0, dirty: true, businessId: biz.id, lastSyncedAt: null }; saveSyncMeta(meta);
    saveState("real", s); ui = freshUi(); cl.status = "unsynced"; render();
    await pushNow(); toast("Welcome to FI Money!");
  } catch (e) { if (e instanceof CloudError) toast(e.message, "error"); else fail(e); }
}
async function patchBusiness()                {
  if (!cl.signedIn || !meta.businessId) return;
  try { await cloud.patch("businesses", `id=eq.${meta.businessId}`, { name: s.business.name, business_type: s.business.type, country: s.business.country, timezone: s.business.timezone }); }
  catch (e) { if (!isNet(e)) toast("Could not update your business profile online.", "error"); }
}

function pwMeterUpdate(form                 )       {
  const pw = (form.querySelector("[name=password]")                           )?.value ?? "";
  const em = (form.querySelector("[name=email]")                           )?.value ?? auth.email;
  const c = checkPassword(pw, em), m = form.querySelector("#pw-meter");
  if (!m) return;
  (m.querySelector("i")               ).style.width = `${(c.level + (pw ? 1 : 0)) * 25}%`;
  (m.querySelector("i")               ).dataset.level = String(pw ? c.level : -1);
  m.querySelector("span") .textContent = pw ? (c.ok ? `${c.label} password.` : `${c.label}. ${c.tips[0] ?? ""}`) : "Use 10+ characters with letters and numbers.";
}

async function authForm(name        , f          )                {
  const email = val(f, "email").toLowerCase(), password = String(f.get("password") ?? ""), confirm = String(f.get("confirm") ?? "");
  const bad = (m        )       => showAuth(auth.screen, { error: m, email: email || auth.email, name: val(f, "fullName") || auth.name });
  if (auth.busy) return;
  try {
    if (name === "register") {
      const fullName = val(f, "fullName");
      if (!fullName) return bad("Please enter your full name.");
      if (!checkEmail(email)) return bad("Please enter a valid email address.");
      const pc = checkPassword(password, email);
      if (!pc.ok) return bad(pc.tips.join(" "));
      if (password !== confirm) return bad("The two passwords do not match.");
      if (!f.has("terms")) return bad("Please accept the Terms and Privacy Policy to continue.");
      auth = { ...auth, busy: true, email, error: "" }; render();
      const r = await cloud.signUp(email, password, fullName, redirectUrl());
      if (r.session) { await enterAccount(); return; }
      showAuth("verify", { email });
    } else if (name === "signin") {
      if (!checkEmail(email) || !password) return bad("Enter your email and password.");
      auth = { ...auth, busy: true, email, error: "" }; render();
      await cloud.signIn(email, password);
      await enterAccount();
    } else if (name === "forgot") {
      if (!checkEmail(email)) return bad("Please enter a valid email address.");
      auth = { ...auth, busy: true, email, error: "" }; render();
      await cloud.recover(email, redirectUrl());
      showAuth("forgot", { email, info: "If an account exists for that email, a reset link is on its way. Check your inbox and spam folder." });
    } else if (name === "reset") {
      const pc = checkPassword(password, cloud.session()?.email ?? "");
      if (!pc.ok) return bad(pc.tips.join(" "));
      if (password !== confirm) return bad("The two passwords do not match.");
      auth = { ...auth, busy: true, error: "" }; render();
      await cloud.updatePassword(password);
      await enterAccount(); toast("Password changed");
    }
  } catch (e) {
    showAuth(auth.screen, { email: email || auth.email, error: e instanceof CloudError ? e.message : "Something went wrong. Please try again." });
    if (e instanceof CloudError && /verify your email/i.test(e.message)) showAuth("verify", { email, error: e.message });
  }
}

async function accountForm(name        , f          , form                 )                {
  try {
    if (name === "profile") {
      const n = val(f, "fullName"); if (!n) throw new L.LedgerError("Name cannot be empty.");
      await cloud.patch("profiles", `id=eq.${cloud.session() .userId}`, { full_name: n }); cl.fullName = n; toast("Saved"); render();
    } else if (name === "changepw") {
      const password = String(f.get("password") ?? ""), confirm = String(f.get("confirm") ?? "");
      const pc = checkPassword(password, cl.email);
      if (!pc.ok) throw new L.LedgerError(pc.tips.join(" "));
      if (password !== confirm) throw new L.LedgerError("The two passwords do not match.");
      await cloud.updatePassword(password); form.reset(); toast("Password changed");
    } else if (name === "support") {
      const m = val(f, "message"); if (!m) throw new L.LedgerError("Please write a message.");
      await cloud.insert("support_requests", { message: m }); form.reset(); toast("Sent. We will reply by email.");
    } else if (name === "deleteacct") {
      if (val(f, "confirmText") !== "DELETE") throw new L.LedgerError("Type DELETE (capital letters) to confirm.");
      const uid = cloud.session() .userId;
      await cloud.rpc("delete_my_account");
      clearUserCache(uid); await cloud.signOut(); resetToSignedOut();
      showAuth("register", { info: "Your account and data were deleted." });
    } else if (name === "adminplan") {
      const price = Number(val(f, "price"));
      if (!Number.isInteger(price) || price < 0) throw new L.LedgerError("Price must be a whole number of cents.");
      await cloud.rpc("admin_set_plan", { p_tier: form.dataset.tier, p_price_minor: price }); toast("Price saved"); await loadAdmin();
    }
  } catch (e) { if (e instanceof CloudError) toast(e.message, "error"); else fail(e); }
}

function resetToSignedOut()       {
  window.clearTimeout(pushTimer);
  cl = { signedIn: false, email: "", fullName: "", status: "off", lastSyncedAt: null, isAdmin: false, note: "" };
  remoteSub = null; stashedRemote = null; admin = emptyAdmin(); setNamespace(null);
  s = defaultState(); mode = "real"; ui = freshUi(); meta = { version: 0, dirty: false, businessId: null, lastSyncedAt: null };
}
async function signOutNow(force         )                {
  if (cl.signedIn && meta.dirty && !force) {
    await pushNow();
    if (meta.dirty) { ui.modal = { t: "confirm", message: "Some changes are NOT backed up yet. Signing out will remove them from this device. Download a backup first, or sign out anyway?", action: "sign-out-force", id: "", danger: true }         ; render(); return; }
  }
  const uid = cloud.session()?.userId;
  await cloud.signOut();
  if (uid) clearUserCache(uid);            // do not leave business records on a shared phone
  resetToSignedOut(); showAuth("signin", { info: "You are signed out." });
}

async function loadAdmin()                {
  try {
    const [usage, requests, users, audit, support, plans] = await Promise.all([
      cloud.rpc                    ("admin_usage"),
      cloud.select                               ("payment_requests", "select=*&order=created_at.desc&limit=100"),
      cloud.select                            ("profiles", "select=id,full_name,email,suspended,suspended_reason,created_at&order=created_at.desc&limit=200"),
      cloud.select                            ("audit_log", "select=*&order=id.desc&limit=50"),
      cloud.select                              ("support_requests", "select=*&order=created_at.desc&limit=50"),
      cloud.select                            ("plans", "select=*&order=price_minor.asc"),
    ]);
    admin = { loaded: true, error: "", usage, requests, users, audit, support, plans };
  } catch (e) { admin = { ...emptyAdmin(), error: e instanceof CloudError ? e.message : "Could not load." }; }
  render();
}
async function adminAction(a        , d              )                {
  try {
    if (a === "admin-confirm") { if (!window.confirm(`Confirm that you received the payment for ${d.ref}?`)) return; await cloud.rpc("admin_confirm_payment", { p_reference: d.ref }); }
    else if (a === "admin-reject") await cloud.rpc("admin_reject_payment", { p_reference: d.ref });
    else if (a === "admin-suspend") { const r = window.prompt("Reason for suspending this account (required):"); if (!r) return; await cloud.rpc("admin_set_suspended", { p_user: d.id, p_suspended: true, p_reason: r }); }
    else if (a === "admin-unsuspend") await cloud.rpc("admin_set_suspended", { p_user: d.id, p_suspended: false, p_reason: "" });
    toast("Done"); await loadAdmin();
  } catch (e) { toast(e instanceof CloudError ? e.message : "Failed", "error"); }
}

async function boot()                {
  const preview = CONFIG.devTools && kv.get("fi-money:localpreview") === "1" && !cloudEnabled();
  if (!cloudEnabled()) {
    if (preview) { inApp = true; render(); return; }
    showAuth("unconfigured"); return;
  }
  const h = cloud.consumeHash(location.hash);
  if (h.kind !== "none") history.replaceState(null, "", location.pathname + location.search);
  if (h.kind === "error") { showAuth("signin", { error: h.message }); return; }
  if (h.kind === "session" && h.type === "recovery") { showAuth("reset"); return; }
  const sess = await cloud.refreshIfNeeded();
  if (!sess) { showAuth(kv.get("fi-money:hasAccount") ? "signin" : "register"); return; }
  await enterAccount();
  if (h.kind === "session" && h.type === "signup") toast("Email verified. Welcome!");
}

// ---------- clicks ----------
function ds(el             )               { return el.dataset; }
function openModal(el             )       {
  const d = ds(el);
  const id = d.id ?? "";
  switch (d.m) {
    case "sale": ui.modal = { t: "sale", id: id || undefined }; break;
    case "saleView": ui.modal = { t: "saleView", id }; break;
    case "expense": ui.modal = { t: "expense", id: id || undefined }; break;
    case "expenseView": ui.modal = { t: "expenseView", id }; break;
    case "customer": ui.modal = { t: "customer", id: id || undefined }; break;
    case "customerView": ui.modal = { t: "customerView", id }; break;
    case "product": ui.modal = { t: "product", id: id || undefined }; break;
    case "productView": ui.modal = { t: "productView", id }; break;
    case "payment": ui.modal = { t: "payment", saleId: d.sale || undefined, customerId: d.customer || undefined }; break;
    case "adjust": ui.modal = { t: "adjust", saleId: d.sale  }; break;
    case "stock": ui.modal = { t: "stock", productId: id }; break;
    case "reminder": ui.modal = { t: "reminder", saleId: d.sale  }; break;
    case "pickCustomer": ui.modal = { t: "pickCustomer", then: "payment" }; break;
    case "planRequest": ui.modal = { t: "planRequest", tier: id                       }; break;
  }
  render();
}
function runConfirmed(action        , id        )       {
  try {
    switch (action) {
      case "void-sale": s.db = L.voidSale(s.db, id); ui.modal = null; toast("Sale voided"); break;
      case "void-payment": {
        const saleId = s.db.payments.find((p) => p.id === id)?.saleId;
        s.db = L.voidPayment(s.db, id); ui.modal = saleId ? { t: "saleView", id: saleId } : null; toast("Reversed"); break;
      }
      case "void-expense": s.db = L.voidExpense(s.db, id); ui.modal = null; toast("Expense reversed"); break;
      case "archive-product": s.db = L.updateProduct(s.db, id, { archived: true }); ui.modal = null; toast("Product archived"); break;
      case "sign-out-force": void signOutNow(true); return;
      case "erase": if (cl.signedIn) break; eraseState(mode); s = defaultState(); ui = freshUi(); toast("All data on this device was erased"); break;
      default: ui.modal = null;
    }
    commit();
  } catch (e) { fail(e); }
}

root.addEventListener("click", (ev) => {
  const target = ev.target               ;
  const el = target.closest             ("[data-a]");
  if (!el) return;
  const a = el.dataset.a ;
  const d = ds(el);
  switch (a) {
    case "auth-go": showAuth(d.v                    , { email: auth.email }); break;
    case "toggle-pw": {
      const row = el.closest(".pwrow"); const inp = row?.querySelector("input");
      if (inp) { inp.type = inp.type === "password" ? "text" : "password"; el.textContent = inp.type === "password" ? "Show" : "Hide"; }
      break;
    }
    case "resend": void (async () => { try { auth.busy = true; await cloud.resend(auth.email, redirectUrl()); showAuth("verify", { email: auth.email, info: "Sent again. Check your inbox and spam folder." }); } catch (e) { showAuth("verify", { email: auth.email, error: e instanceof CloudError ? e.message : "Could not send." }); } })(); break;
    case "local-preview": kv.set("fi-money:localpreview", "1"); setNamespace(null); s = loadState(mode); ui = freshUi(); inApp = true; render(); break;
    case "sign-out": void signOutNow(false); break;
    case "retry-load": void enterAccount(); break;
    case "sync-now": void pushNow(); break;
    case "conflict-cloud": if (stashedRemote) { s = stashedRemote.data; meta = { ...meta, version: stashedRemote.version, dirty: false, lastSyncedAt: new Date().toISOString() }; saveSyncMeta(meta); saveState("real", s); stashedRemote = null; cl.status = "synced"; ui.modal = null; render(); toast("Loaded the cloud version"); } break;
    case "conflict-mine": void (async () => { await stashRemote(); if (stashedRemote) { meta.version = stashedRemote.version; saveSyncMeta(meta); stashedRemote = null; cl.status = "unsynced"; await pushNow(); toast("Your version was saved to the cloud"); } })(); break;
    case "admin-load": void loadAdmin(); break;
    case "admin-confirm": case "admin-reject": case "admin-suspend": case "admin-unsuspend": void adminAction(a, d); break;
    case "tab": ui.tab = d.tab                  ; ui.morePage = null; ui.modal = null; if (d.filter) ui.debtFilter = d.filter; window.scrollTo(0, 0); render(); break;
    case "more": ui.tab = "more"; ui.morePage = (d.page || null)                       ; ui.modal = null; window.scrollTo(0, 0); render(); if (ui.morePage === "admin" && cl.isAdmin && !admin.loaded) void loadAdmin(); break;
    case "range": ui.range = d.v                    ; render(); break;
    case "open": openModal(el); break;
    case "close": ui.modal = null; render(); break;
    case "close-bg": if (target === el) { ui.modal = null; render(); } break;
    case "seg-money": ui.moneySeg = d.v                       ; render(); break;
    case "seg-debt": ui.debtSeg = d.v                      ; render(); break;
    case "sales-filter": ui.salesFilter = d.v ; render(); break;
    case "debt-filter": ui.debtFilter = d.v ; render(); break;
    case "debt-sort": ui.debtSort = d.v                       ; render(); break;
    case "rem-tab": ui.remTab = d.v                     ; render(); break;
    case "confirm": ui.modal = { t: "confirm", message: d.msg ?? "Are you sure?", action: d.do || d.id || "", id: d.id ?? "" }         ; render(); break;
    case "confirm-yes": runConfirmed(d.do ?? "", d.id ?? ""); break;
    case "enter-demo": if (cl.signedIn) break; mode = "demo"; setMode("demo"); s = demoState(); saveState("demo", s); ui = freshUi(); render(); toast("Demo data — separate from your real records"); break;
    case "exit-demo": mode = "real"; setMode("real"); s = loadState("real"); ui = freshUi(); render(); break;
    case "dev-plan": {
      if (!(CONFIG.devTools && s.devMode)) break;
      s.subscription = d.v === "free" ? { ...FREE_SUBSCRIPTION } : { tier: d.v                      , status: "active", source: "dev", currentPeriodEnd: null };
      commit(); toast("Development plan switch — not a payment");
      break;
    }
    case "export-json": download(`fi-money-backup-${buildV().today}.json`, "application/json", JSON.stringify({ app: "FI Money", exportedAt: new Date().toISOString(), mode, data: s }, null, 2)); toast("Backup downloaded"); break;
    case "csv": csv(d.v ); break;
    case "run-reminders": void runReminders(); break;
    case "cancel-rem": s.reminders = s.reminders.map((r) => r.id === d.id && ["draft", "scheduled", "pending"].includes(r.status) ? { ...r, status: "cancelled", log: [...r.log, { at: new Date().toISOString(), status: "cancelled", note: "Cancelled by the business owner" }] } : r); commit(); break;
    case "send-rem": void sendManual(d.sale , d.ch             ); break;
    case "copy-msg": {
      const V = buildV();
      const sale = s.db.sales.find((x) => x.id === d.sale);
      const cust = sale && s.db.customers.find((c) => c.id === sale.customerId);
      if (!sale || !cust) break;
      const text = M.buildMessage(s.reminderSettings.template, L.debtOf(s.db, sale, V.today), cust, s.business.name, V.currency).text;
      void copyText(text).then((ok) => toast(ok ? "Message copied — paste it into your chat app" : "Could not copy. Select the text and copy it manually.", ok ? "ok" : "error"));
      break;
    }
    case "mock-delivered": {
      const r = s.reminders.find((x) => x.id === d.id);
      if (!r?.providerMessageId) break;
      const res = M.applyProviderEvent(s.reminders, s.processedEvents, { eventId: L.newId(), providerMessageId: r.providerMessageId, type: "delivered", at: new Date().toISOString() });
      s.reminders = res.reminders; s.processedEvents = res.processed; commit();
      break;
    }
    case "reset-template": {
      const ta = root.querySelector                     ("#tpl");
      if (ta) { ta.value = M.DEFAULT_TEMPLATE; ta.dispatchEvent(new Event("input", { bubbles: true })); }
      break;
    }
    case "save-request": {
      if (!paymentConfigured()) { toast("No payment method is set up yet.", "error"); break; }
      const tier = d.tier                      ;
      if (cl.signedIn) {
        void (async () => {
          try {
            if (!s.paymentRequests.some((r) => r.tier === tier && r.status === "awaiting_confirmation")) {
              const req = newPaymentRequest(tier, new Date(), crypto.getRandomValues(new Uint8Array(6)));
              await cloud.rpc("create_payment_request", { p_reference: req.reference, p_tier: tier });
            }
            await loadPaymentRequests(); render(); toast("Reference created. Your plan is NOT active until payment is confirmed.");
          } catch (e) { toast(e instanceof CloudError ? e.message : "Could not create the request. Check your connection.", "error"); }
        })();
        break;
      }
      if (!s.paymentRequests.some((r) => r.tier === tier && r.status === "awaiting_confirmation"))
        s.paymentRequests = [...s.paymentRequests, newPaymentRequest(tier, new Date(), crypto.getRandomValues(new Uint8Array(6)))];
      commit(); toast("Reference created. Your plan is NOT active until payment is confirmed.");
      break;
    }
    case "cancel-request":
      if (cl.signedIn) { void (async () => { try { await cloud.rpc("cancel_payment_request", { p_reference: d.ref }); await loadPaymentRequests(); ui.modal = null; render(); } catch (e) { toast(e instanceof CloudError ? e.message : "Failed", "error"); } })(); break; }
      s.paymentRequests = s.paymentRequests.map((r) => r.reference === d.ref ? { ...r, status: "cancelled"          } : r); ui.modal = null; commit(); break;
    case "copy-ref": void copyText(d.ref ?? "").then((ok) => toast(ok ? "Reference copied" : "Could not copy", ok ? "ok" : "error")); break;
    case "tg-connect": ui.modal = { t: "telegram", customerId: d.id  }; render(); break;
    case "tg-disconnect": s.db = L.updateCustomer(s.db, d.id , { telegramChatId: null }); commit(); toast("Telegram disconnected"); break;
    case "tg-mock":
      if (CONFIG.devTools && s.devMode) { s.db = L.updateCustomer(s.db, d.id , { telegramChatId: "dev-mock-" + d.id }); ui.modal = { t: "customerView", id: d.id  }; commit(); toast("Mock connection created (no real Telegram link)"); }
      break;
    case "add-line": {
      const lines = root.querySelector("#lines") ;
      const clone = lines.querySelector             ("[data-line]") .cloneNode(true)               ;
      clone.querySelectorAll                  ("input").forEach((i) => { i.value = i.name === "qty" ? "1" : ""; });
      const sel = clone.querySelector                   ("select") ; sel.selectedIndex = 0;
      (clone.querySelector("[name=pname]")               ).style.display = "";
      lines.appendChild(clone); updateSaleTotal();
      break;
    }
    case "rm-line": {
      const lines = root.querySelector("#lines") ;
      const row = el.closest("[data-line]") ;
      if (lines.querySelectorAll("[data-line]").length > 1) row.remove(); else row.querySelectorAll                  ("input").forEach((i) => { i.value = i.name === "qty" ? "1" : ""; });
      updateSaleTotal();
      break;
    }
  }
});

root.addEventListener("submit", (ev) => {
  const form = (ev.target               ).closest                 ("form[data-form]");
  if (!form) return;
  ev.preventDefault();
  onSubmit(form);
});

root.addEventListener("input", (ev) => {
  const t = ev.target                    ;
  const key = t.getAttribute?.("data-a-input");
  if (key) { (ui                                     )[key] = t.value; render(); return; }
  const form = t.closest?.("form[data-form]")                          ;
  if (!form) return;
  if (["register", "reset", "changepw"].includes(form.dataset.form ?? "")) { pwMeterUpdate(form); return; }
  if (form.dataset.form === "sale") updateSaleTotal();
  else if (form.dataset.form === "calc" && t.name) {
    ui.calc[t.name] = t.value;
    const out = root.querySelector("#calc-result");
    if (out) out.innerHTML = views.calcResult(buildV());
  } else if (form.dataset.form === "remsettings" && t.id === "tpl") {
    const V = buildV();
    const r = M.renderTemplate(t.value, { customer_name: "Sophea", business_name: s.business.name || "Your Shop", currency: V.currency, outstanding_balance: formatAmount(2500, V.currency), due_date: V.fd(V.today), invoice_ref: "S-0001" });
    const box = root.querySelector("#tpl-preview");
    if (box) box.textContent = r.text;
  }
});

root.addEventListener("change", (ev) => {
  const t = ev.target                                        ;
  const g = (k        ) => t.getAttribute?.(k);
  if (g("data-a-change")) {
    const k = g("data-a-change") ;
    if (k === "expCat") { ui.expCat = t.value; render(); }
    else if (k === "cust-channel") {
      const id = g("data-id") ;
      s.db = L.updateCustomer(s.db, id, { channel: t.value                  }); commit();
    } else if (k === "botUsername") { s.botUsername = t.value.trim().replace(/[^\w@]/g, ""); saveState(mode, s); }
    return;
  }
  if (g("data-a-toggle")) {
    const k = g("data-a-toggle")                                  ;
    s[k] = t.checked;
    if (k === "devMode" && !t.checked && s.subscription.source === "dev") s.subscription = { ...FREE_SUBSCRIPTION };
    commit();
    return;
  }
  if (g("data-a-toggle-cust")) {
    s.db = L.updateCustomer(s.db, g("data-id") , { [g("data-a-toggle-cust") ]: t.checked }                       ); commit();
    return;
  }
  if (t.name === "pid" && t.closest("[data-line]")) {
    const row = t.closest("[data-line]")               ;
    const opt = t.selectedOptions[0];
    (row.querySelector("[name=pname]")               ).style.display = t.value ? "none" : "";
    if (t.value) (row.querySelector("[name=price]")                    ).value = opt.dataset.price ?? "";
    updateSaleTotal();
    return;
  }
  if (t.name === "customerId") updateSaleTotal();
  if (t.name === "fromProduct" && t.value) {
    const p = s.db.products.find((x) => x.id === t.value);
    if (p) { ui.calc.price = plain(p.price); ui.calc.cost = p.cost === null ? "" : plain(p.cost); render(); }
  }
});

document.addEventListener("keydown", (e) => { if (e.key === "Escape" && ui.modal) { ui.modal = null; render(); } });

// Offline support (app files only — never business data). Needs https or localhost.
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
  window.addEventListener("load", () => { navigator.serviceWorker.register("sw.js").catch(() => { /* offline mode is optional */ }); });
}
// Keep the screen fresh when the app returns to the foreground (dates, overdue status).
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && !ui.modal) render(); });
void esc; void COUNTRIES;
render();
void boot();
// An email link opened while the app is already open (hash change only) must still be processed.
window.addEventListener("hashchange", () => { if (location.hash.includes("access_token") || location.hash.includes("error_description")) void boot(); });
