// FI Money — screens. Pure functions: state in, HTML string out. No business logic lives here.
import { esc } from "./ui.js";
                                    
import * as L from "../engine/ledger.js";
import * as R from "../engine/reports.js";
import { PLANS, requiredTier } from "../engine/entitlements.js";
                                                         
import { formatMoney, minorDigits, parseMoney } from "../engine/money.js";
import { calculateProfit } from "../engine/profit.js";
import { CONFIG, CURRENCIES, BUSINESS_TYPES, COUNTRIES, storageOk, paymentConfigured } from "./state.js";
import { syncBanner, accountCard } from "./account.js";
import { modal } from "./modals.js";
import { lockCard, badge, stat, profitStat, chips, pageHead, rangeBar, empty } from "./components.js";

// ---------- primitives ----------
const icon = (p        ) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
const ICONS = {
  home: icon('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>'),
  money: icon('<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>'),
  debtors: icon('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M17 6v6M20 9h-6"/>'),
  stock: icon('<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/>'),
  more: icon('<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'),
};

// ---------- shell ----------
export function shell(V   , body        )         {
  const nav = (["home", "money", "debtors", "stock", "more"]         ).map((t) =>
    `<button data-a="tab" data-tab="${t}" ${V.ui.tab === t ? 'aria-current="page"' : ""}>${ICONS[t]}<span>${{ home: "Home", money: "Money", debtors: "Debtors", stock: "Stock", more: "More" }[t]}</span></button>`).join("");
  return `<header class="top"><div class="row"><div class="brand"><div class="logo">FI</div><div><b>${esc(V.s.business.name || "FI Money")}</b><small>FI Money · A Fondom Innovation product</small></div></div>
    <button class="tier" data-a="more" data-page="plans" aria-label="Current plan">${esc(PLANS[V.tier].name.replace("FI Money ", ""))}</button></div></header>
    ${V.mode === "demo" ? `<div class="banner demo">DEMO DATA — sample figures, not your business. <button class="chip" style="min-height:32px;padding:4px 10px" data-a="exit-demo">Exit demo</button></div>` : ""}
    <div id="sync-banner">${syncBanner(V)}</div>
    ${!storageOk ? `<div class="banner warn">This browser is blocking storage, so your changes will be lost when you close the app. Export your data from Settings often.</div>` : ""}
    <main>${body}</main><nav class="nav" aria-label="Main">${nav}</nav>${V.ui.modal ? `<div class="sheet-bg" data-a="close-bg"><div class="sheet" role="dialog" aria-modal="true">${modal(V)}</div></div>` : ""}`;
}

export function onboarding(V   )         {
  const b = V.s.business;
  return `<main style="padding-top:28px"><div class="brand" style="color:var(--ink)"><div class="logo" style="background:var(--navy);color:#fff">FI</div><div><b style="font-size:1.3rem">FI Money</b><small class="muted">A Fondom Innovation product</small></div></div>
  <h1 style="margin:18px 0 4px;font-size:1.5rem">Know your numbers.<br>Grow your business.</h1>
  <p class="muted">Set up your business. It takes one minute. ${V.cloud.signedIn ? "Your records are saved to your account." : "Everything is saved on this device."}</p>
  <form class="card" data-form="setup">
    <label>Business name</label><input name="name" required maxlength="80" value="${esc(b.name)}" placeholder="e.g. Sophea Mini Mart">
    <label>Business type</label><select name="type">${BUSINESS_TYPES.map((t) => `<option ${t === b.type ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>
    <label>Country</label><select name="country" required><option value="">Select…</option>${COUNTRIES.map((c) => `<option ${c === b.country ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
    <div class="two"><div><label>Currency</label><select name="currency">${CURRENCIES.map((c) => `<option ${c === b.currency ? "selected" : ""}>${c}</option>`).join("")}</select></div>
    <div><label>Date format</label><select name="dateFormat"><option ${b.dateFormat === "DD/MM/YYYY" ? "selected" : ""}>DD/MM/YYYY</option><option ${b.dateFormat === "YYYY-MM-DD" ? "selected" : ""}>YYYY-MM-DD</option></select></div></div>
    <p class="tiny muted" style="margin:4px 0 0">${V.cloud.signedIn ? "Your currency cannot be changed after setup, so amounts are never mixed up." : ""}</p>
    <label>Time zone</label><input name="timezone" value="${esc(b.timezone)}" required>
    <div class="two"><div><label>Business phone (optional)</label><input name="phone" inputmode="tel" value="${esc(b.phone)}"></div><div><label>Business email (optional)</label><input name="email" type="email" value="${esc(b.email)}"></div></div>
    <label>Starting cash (optional)</label><input name="startingCash" inputmode="decimal" placeholder="0">
    <button class="btn block" style="margin-top:16px">${V.cloud.signedIn ? "Finish setup" : "Start with my own data"}</button>
  </form>
  ${V.cloud.signedIn ? `<button class="btn ghost block" data-a="sign-out">Sign out</button>` : `<button class="btn ghost block" data-a="enter-demo">Look around with demo data first</button>
  <p class="muted tiny" style="margin-top:14px">Local preview: your records stay in this browser only. They are not synced or backed up.</p>`}</main>`;
}

// ---------- home ----------
export function home(V   )         {
  const { s, today } = V;
  const sm = L.summarize(s.db, V.range.from, V.range.to, today);
  const days = R.dailySales(s.db, V.range.from, V.range.to).slice(-31);
  const hasData = s.db.sales.length + s.db.expenses.length > 0;
  const attn           = [];
  const debts = L.openDebts(s.db, today);
  const overdue = debts.filter((d) => d.status === "overdue");
  if (overdue.length) attn.push(`<button class="attn red" data-a="tab" data-tab="debtors" data-filter="overdue"><span><b>${overdue.length} overdue debt${overdue.length > 1 ? "s" : ""}</b><br><span class="small muted">${esc(V.fm(overdue.reduce((t, d) => t + d.balance, 0)))} to collect</span></span>›</button>`);
  const dueToday = debts.filter((d) => d.dueDate === today);
  if (dueToday.length) attn.push(`<button class="attn" data-a="tab" data-tab="debtors"><span><b>${dueToday.length} due today</b></span>›</button>`);
  for (const p of sm.lowStock.slice(0, 3)) attn.push(`<button class="attn" data-a="tab" data-tab="stock"><span><b>Low stock: ${esc(p.name)}</b><br><span class="small muted">${p.stock} left</span></span>›</button>`);
  if (sm.missing.length) attn.push(`<button class="attn" data-a="tab" data-tab="stock"><span><b>Profit incomplete</b><br><span class="small muted">Add a unit cost to products you sell.</span></span>›</button>`);
  const failed = s.reminders.filter((r) => r.status === "failed").length;
  if (failed && V.can("reminderHistory")) attn.push(`<button class="attn red" data-a="more" data-page="reminders"><span><b>${failed} reminder${failed > 1 ? "s" : ""} failed</b></span>›</button>`);

                                                                                                               
  const tx       = [];
  for (const x of s.db.sales) if (!x.voided) tx.push({ date: x.date, label: `Sale ${x.ref}`, sub: s.db.customers.find((c) => c.id === x.customerId)?.name ?? "Walk-in", amount: L.saleTotal(x), kind: "sale" });
  for (const p of s.db.payments) if (!p.voided && p.kind === "payment") tx.push({ date: p.date, label: "Payment received", sub: s.db.customers.find((c) => c.id === p.customerId)?.name ?? "Walk-in", amount: p.amount, kind: "payment" });
  for (const e of s.db.expenses) if (!e.voided) tx.push({ date: e.date, label: e.description, sub: e.category, amount: e.amount, kind: "expense" });
  tx.sort((a, b) => b.date.localeCompare(a.date));
  const recent = tx.slice(0, 8);

  return `${rangeBar(V)}
  ${!hasData ? `<div class="card"><h3>Welcome! Start here</h3><p class="muted small">Add a product, then record your first sale. Your dashboard fills in by itself.</p></div>` : ""}
  <div class="grid2" style="margin-bottom:12px">
    ${stat("Sales revenue", esc(V.fm(sm.salesRevenue)), "What you sold (paid or not)")}
    ${stat("Cash received", esc(V.fm(sm.cashReceived)), "Money actually collected")}
    ${stat("Expenses", esc(V.fm(sm.expenses)), "Operating costs recorded")}
    ${profitStat(V, "Gross profit", sm.grossProfit, "Sales − cost of goods sold")}
    ${profitStat(V, "Est. net profit", sm.estimatedNetProfit, "After fees and expenses")}
    ${stat("Owed to you", esc(V.fm(sm.outstanding)), `${sm.debtorCount} customer${sm.debtorCount === 1 ? "" : "s"}`, sm.outstanding > 0 ? "warnc" : "")}
    ${stat("Overdue", esc(V.fm(sm.overdue)), `${sm.overdueCount} debt${sm.overdueCount === 1 ? "" : "s"}`, sm.overdue > 0 ? "neg" : "")}
    ${stat("Partially paid", String(sm.partialCount), "debts with part-payments")}
  </div>
  ${sm.missing.length ? `<div class="notice warn">${esc(sm.missing[0])} Profit figures are hidden until every sold item has a cost.</div>` : ""}
  <div class="card"><h3>Quick actions</h3><div class="actions" style="margin-top:10px">
    <button class="btn" data-a="open" data-m="sale">＋ Record a sale</button><button class="btn" data-a="open" data-m="expense">− Record an expense</button>
    <button class="btn secondary" data-a="open" data-m="customer">＋ Add a customer</button><button class="btn secondary" data-a="open" data-m="pickCustomer">Record a payment</button>
    <button class="btn secondary" data-a="open" data-m="product">＋ Add a product</button><button class="btn secondary" data-a="tab" data-tab="debtors">View debtors</button>
    <button class="btn secondary" data-a="more" data-page="reminders" style="grid-column:1/-1">Send or review reminders</button></div></div>
  ${attn.length ? `<div class="card"><h3 style="margin-bottom:10px">Needs attention</h3>${attn.join("")}</div>` : ""}
  <div class="card"><h3>Sales trend</h3>${trendChart(V, days)}</div>
  <div class="card"><h3>Recent transactions</h3>${recent.length ? `<div class="list">${recent.map((t) => `<div class="item"><div class="l"><b>${esc(t.label)}</b><span class="small muted">${esc(t.sub)} · ${esc(V.fd(t.date))}</span></div><div class="r"><b class="${t.kind === "expense" ? "neg" : ""}">${t.kind === "expense" ? "−" : ""}${esc(V.fm(t.amount))}</b><span class="tiny muted">${{ sale: "Sold", payment: "Cash in", expense: "Expense" }[t.kind]}</span></div></div>`).join("")}</div>` : `<p class="muted small">Nothing recorded yet.</p>`}</div>`;
}
function trendChart(V   , days            )         {
  const max = Math.max(1, ...days.map((d) => Math.max(d.revenue, d.cash)));
  if (!days.some((d) => d.revenue > 0 || d.cash > 0)) return `<p class="muted small">No sales in this period yet.</p>`;
  const w = 300, h = 100, bw = w / days.length;
  const bars = days.map((d, i) => {
    const rh = (d.revenue / max) * h, ch = (d.cash / max) * h;
    return `<rect x="${(i * bw + bw * 0.1).toFixed(1)}" y="${(h - rh).toFixed(1)}" width="${(bw * 0.8).toFixed(1)}" height="${rh.toFixed(1)}" rx="2" fill="var(--navy-2)"><title>${esc(V.fd(d.date))}: sold ${esc(V.fm(d.revenue))}</title></rect>
    <rect x="${(i * bw + bw * 0.1).toFixed(1)}" y="${(h - ch).toFixed(1)}" width="${(bw * 0.8).toFixed(1)}" height="${ch.toFixed(1)}" rx="2" fill="var(--teal)" opacity=".85"><title>${esc(V.fd(d.date))}: cash ${esc(V.fm(d.cash))}</title></rect>`;
  }).join("");
  return `<svg class="chart" viewBox="0 0 ${w} ${h + 14}" role="img" aria-label="Daily sales and cash received">${bars}<text x="0" y="${h + 11}" font-size="8" fill="var(--muted)">${esc(V.fd(days[0].date))}</text><text x="${w}" y="${h + 11}" font-size="8" text-anchor="end" fill="var(--muted)">${esc(V.fd(days[days.length - 1].date))}</text></svg>
  <p class="tiny muted"><span style="color:var(--navy-2)">■</span> Sold &nbsp; <span style="color:var(--teal)">■</span> Cash received</p>`;
}

// ---------- money: sales & expenses ----------
export function money(V   )         {
  const seg = `<div class="seg"><button aria-pressed="${V.ui.moneySeg === "sales"}" data-a="seg-money" data-v="sales">Sales</button><button aria-pressed="${V.ui.moneySeg === "expenses"}" data-a="seg-money" data-v="expenses">Expenses</button></div>`;
  return seg + (V.ui.moneySeg === "sales" ? salesList(V) : expensesList(V));
}
function saleStatus(V   , s        )         {
  if (s.voided) return "voided";
  return L.debtOf(V.s.db, s, V.today).status;
}
function salesList(V   )         {
  const { s, ui } = V;
  const q = ui.salesQ.toLowerCase();
  const rows = s.db.sales.map((x) => ({ x, st: saleStatus(V, x), cust: s.db.customers.find((c) => c.id === x.customerId)?.name ?? "Walk-in" }))
    .filter((r) => (ui.salesFilter === "all" || r.st === ui.salesFilter) && (!q || r.x.ref.toLowerCase().includes(q) || r.cust.toLowerCase().includes(q) || r.x.lines.some((l) => l.name.toLowerCase().includes(q))))
    .reverse();
  return `<button class="btn block" data-a="open" data-m="sale" style="margin-bottom:10px">＋ Record a sale</button>
  <input type="search" placeholder="Search sales, customers, items" value="${esc(ui.salesQ)}" data-a-input="salesQ" style="margin-bottom:8px">
  ${chips([["all", "All"], ["paid", "Paid"], ["partial", "Partial"], ["unpaid", "Unpaid"], ["overdue", "Overdue"], ["voided", "Voided"]], ui.salesFilter, "sales-filter")}
  ${rows.length ? `<div class="card"><div class="list">${rows.map(({ x, st, cust }) => `<button class="item" data-a="open" data-m="saleView" data-id="${esc(x.id)}"><div class="l"><b>${esc(x.ref)} · ${esc(cust)}</b><span class="small muted">${esc(V.fd(x.date))} · ${esc(x.lines.map((l) => l.name).join(", ").slice(0, 40))}</span></div><div class="r"><b ${x.voided ? 'style="text-decoration:line-through"' : ""}>${esc(V.fm(L.saleTotal(x)))}</b>${badge(st)}</div></button>`).join("")}</div></div>` : empty(s.db.sales.length ? "No sales match your search." : "No sales yet.")}`;
}
function expensesList(V   )         {
  const { s, ui } = V;
  const q = ui.expQ.toLowerCase();
  const rows = s.db.expenses.filter((e) => (ui.expCat === "all" || e.category === ui.expCat) && (!q || e.description.toLowerCase().includes(q) || e.supplier.toLowerCase().includes(q))).reverse();
  return `<button class="btn block" data-a="open" data-m="expense" style="margin-bottom:10px">− Record an expense</button>
  <input type="search" placeholder="Search expenses" value="${esc(ui.expQ)}" data-a-input="expQ" style="margin-bottom:8px">
  <select data-a-change="expCat" style="margin-bottom:10px"><option value="all">All categories</option>${s.db.expenseCategories.map((c) => `<option ${c === ui.expCat ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
  <p class="tiny muted">Stock you buy to resell is recorded in Stock, not here, so costs are never counted twice.</p>
  ${rows.length ? `<div class="card"><div class="list">${rows.map((e) => `<button class="item" data-a="open" data-m="expenseView" data-id="${esc(e.id)}"><div class="l"><b ${e.voided ? 'style="text-decoration:line-through"' : ""}>${esc(e.description)}</b><span class="small muted">${esc(e.category)} · ${esc(V.fd(e.date))}${e.voided ? " · reversed" : ""}</span></div><div class="r"><b class="neg">${esc(V.fm(e.amount))}</b></div></button>`).join("")}</div></div>` : empty("No expenses found.")}`;
}

// ---------- debtors & customers ----------
export function debtors(V   )         {
  const { s, ui, today } = V;
  const seg = `<div class="seg"><button aria-pressed="${ui.debtSeg === "debtors"}" data-a="seg-debt" data-v="debtors">Debtors</button><button aria-pressed="${ui.debtSeg === "customers"}" data-a="seg-debt" data-v="customers">All customers</button></div>`;
  const q = ui.debtQ.toLowerCase();
  const all = L.openDebts(s.db, today);
  const byCust = new Map                  ();
  for (const d of all) byCust.set(d.customerId , [...(byCust.get(d.customerId ) ?? []), d]);
  if (ui.debtSeg === "customers") {
    const cs = s.db.customers.filter((c) => !q || c.name.toLowerCase().includes(q) || c.phone.includes(q));
    return `${seg}<button class="btn block" data-a="open" data-m="customer" style="margin-bottom:10px">＋ Add a customer</button><input type="search" placeholder="Search customers" value="${esc(ui.debtQ)}" data-a-input="debtQ" style="margin-bottom:8px">
    ${cs.length ? `<div class="card"><div class="list">${cs.map((c) => { const owed = (byCust.get(c.id) ?? []).reduce((t, d) => t + d.balance, 0); return `<button class="item" data-a="open" data-m="customerView" data-id="${esc(c.id)}"><div class="l"><b>${esc(c.name)}</b><span class="small muted">${esc(c.phone || "No phone")}</span></div><div class="r"><b>${owed ? esc(V.fm(owed)) : "—"}</b>${owed ? `<span class="tiny muted">owes</span>` : ""}</div></button>`; }).join("")}</div></div>` : empty("No customers yet.")}`;
  }
  let rows = [...byCust.entries()].map(([id, ds]) => {
    const c = s.db.customers.find((x) => x.id === id) ;
    const status = ds.some((d) => d.status === "overdue") ? "overdue" : ds.some((d) => d.partiallyPaid) ? "partial" : "unpaid";
    const due = ds.map((d) => d.dueDate).filter((x)              => !!x).sort()[0] ?? null;
    return { c, total: ds.reduce((t, d) => t + d.balance, 0), status, due, n: ds.length };
  }).filter((r) => (ui.debtFilter === "all" || r.status === ui.debtFilter || (ui.debtFilter === "partial" && r.status === "partial")) && (!q || r.c.name.toLowerCase().includes(q)));
  rows = rows.sort((a, b) => ui.debtSort === "amount" ? b.total - a.total : (a.due ?? "9999").localeCompare(b.due ?? "9999"));
  const sm = L.summarize(s.db, today, today, today);
  return `${seg}<div class="grid2" style="margin-bottom:12px">${stat("Total owed", esc(V.fm(sm.outstanding)), `${sm.debtorCount} debtors`)}${stat("Overdue", esc(V.fm(sm.overdue)), `${sm.overdueCount} debts`, sm.overdue ? "neg" : "")}</div>
  <input type="search" placeholder="Search debtors" value="${esc(ui.debtQ)}" data-a-input="debtQ" style="margin-bottom:8px">
  ${chips([["all", "All"], ["overdue", "Overdue"], ["partial", "Partially paid"], ["unpaid", "Unpaid"]], ui.debtFilter, "debt-filter")}
  <div class="chips" style="padding-top:0">${chips([["amount", "Sort: amount owed"], ["due", "Sort: due date"]], ui.debtSort, "debt-sort").replace('<div class="chips" role="group">', "").replace(/<\/div>$/, "")}</div>
  ${rows.length ? `<div class="card"><div class="list">${rows.map((r) => `<button class="item" data-a="open" data-m="customerView" data-id="${esc(r.c.id)}"><div class="l"><b>${esc(r.c.name)}</b><span class="small muted">${r.n} debt${r.n > 1 ? "s" : ""} · due ${esc(V.fd(r.due))}</span></div><div class="r"><b>${esc(V.fm(r.total))}</b>${badge(r.status)}</div></button>`).join("")}</div></div>` : empty(all.length ? "No debtors match." : "Nobody owes you money right now. 🎉")}`;
}

// ---------- stock ----------
export function stock(V   )         {
  const { s, ui } = V;
  const q = ui.stockQ.toLowerCase();
  const ps = s.db.products.filter((p) => !p.archived && (!q || p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)));
  const low = ps.filter((p) => p.kind === "product" && p.lowStockAt > 0 && L.stockOf(s.db, p.id) <= p.lowStockAt).length;
  return `<button class="btn block" data-a="open" data-m="product" style="margin-bottom:10px">＋ Add a product or service</button>
  <input type="search" placeholder="Search products or SKU" value="${esc(ui.stockQ)}" data-a-input="stockQ" style="margin-bottom:8px">
  ${low ? `<div class="notice warn">${low} product${low > 1 ? "s are" : " is"} low on stock.</div>` : ""}
  <p class="tiny muted">Cost method: each sale remembers the unit cost at the time it was made. Buying stock is an inventory purchase, not an expense.</p>
  ${ps.length ? `<div class="card"><div class="list">${ps.map((p) => { const st = L.stockOf(s.db, p.id); const isLow = p.kind === "product" && p.lowStockAt > 0 && st <= p.lowStockAt;
    return `<button class="item" data-a="open" data-m="productView" data-id="${esc(p.id)}"><div class="l"><b>${esc(p.name)}</b><span class="small muted">${esc(p.sku || (p.kind === "service" ? "Service" : "No SKU"))} · price ${esc(V.fm(p.price))}${p.cost === null ? " · <span class='warnc'>no cost</span>" : ""}</span></div><div class="r"><b class="${isLow ? "neg" : ""}">${p.kind === "service" ? "—" : st}</b><span class="tiny muted">${p.kind === "service" ? "service" : isLow ? "low stock" : "in stock"}</span></div></button>`; }).join("")}</div></div>` : empty("No products yet. Add the things you sell.")}`;
}

// ---------- more ----------
export function more(V   )         {
  const link = (page        , title        , sub        , tag = "") => `<button class="item" data-a="more" data-page="${page}"><div class="l"><b>${esc(title)} ${tag}</b><span class="small muted">${esc(sub)}</span></div><div class="r">›</div></button>`;
  const lock = (f         ) => V.can(f) ? "" : `<span class="badge lock">${esc(PLANS[requiredTier(f)].name.replace("FI Money ", ""))}</span>`;
  return `<div class="card"><div class="list">
    ${link("reminders", "Reminders & follow-up", "Prepare, copy and track debtor reminders")}
    ${link("reports", "Reports", "Sales, expenses, profit, debts, inventory")}
    ${link("calculator", "Profit calculator", "Gross, contribution and net profit per product", lock("profitCalculator"))}
    ${link("plans", "Plans & billing", `You are on ${PLANS[V.tier].name}`)}
    ${link("status", "What works today", "Local features vs. features that need a server")}
    ${link("settings", "Settings & account", "Business profile, account, export, delete")}
    ${V.cloud.isAdmin ? link("admin", "Administrator", "Payments, accounts, plans, audit log") : ""}
  </div></div><p class="muted tiny" style="text-align:center">FI Money · A Fondom Innovation product<br>Version ${esc(CONFIG.version)} ${V.s.devMode ? "· development mode" : ""}</p>`;
}

export function plans(V   )         {
  const feats                                                = {
    free: ["Sales, expenses, customers, stock", "Debt tracking with full & partial payments", "Dashboard, daily & monthly summaries", "Copy-ready reminder messages", "Export all your data (JSON)"],
    pro: ["Everything in Free", "Product profitability & margins", "Profit calculator with break-even price", "Advanced reports & period comparison", "CSV exports, inventory insights"],
    advanced: ["Everything in Pro", "SMS and Telegram reminders", "Schedules, quiet hours, frequency limits", "Custom templates, follow-up queue, history", "Future premium features"],
  };
  const dev = V.s.devMode && !V.cloud.signedIn;
  const card = (t                             ) => {
    const p = PLANS[t];
    const price = p.priceMonthlyMinor === 0 ? "$0" : `${formatMoney(p.priceMonthlyMinor, p.currency).replace("USD ", "$")}`;
    const current = V.tier === t;
    return `<div class="card" ${current ? 'style="border:2px solid var(--navy-2)"' : ""}><div style="display:flex;justify-content:space-between;align-items:baseline"><h3>${esc(p.name)}</h3><b style="font-size:1.2rem">${esc(price)}<span class="muted small">/month</span></b></div>
    <ul class="small" style="padding-left:18px;margin:10px 0">${feats[t].map((f) => `<li>${esc(f)}</li>`).join("")}</ul>
    ${current ? `<span class="badge paid">Your current plan</span>` : t === "free" ? "" : dev ? `<button class="btn secondary block" data-a="dev-plan" data-v="${t}">Switch to ${esc(p.name.replace("FI Money ", ""))} — DEVELOPMENT ONLY, not a payment</button>` : ""}
    ${t !== "free" && !current ? (paymentConfigured() ? `<button class="btn block" style="margin-top:8px" data-a="open" data-m="planRequest" data-id="${t}">Pay by ${esc(CONFIG.payment.methodName ?? "bank transfer / KHQR")}</button>` : `<button class="btn block" style="margin-top:8px" disabled>Payment method not set up yet</button>`) : ""}
    ${dev && current && t !== "free" ? `<button class="btn ghost small block" style="margin-top:8px" data-a="dev-plan" data-v="free">Return to Free (development)</button>` : ""}</div>`;
  };
  const sub = V.s.subscription;
  return `${pageHead("Plans & billing")}
  <div class="notice warn"><b>No real billing is connected.</b> Paid access can only be activated by a verified payment from a billing provider or an administrator action on a server. Pressing a button here never charges anyone${dev ? ", and the development switch below is for testing the app only" : ""}.</div>
  ${card("free")}${card("pro")}${card("advanced")}
  <div class="card"><h3>How customers pay</h3>${paymentConfigured()
    ? `<p class="small">Manual payment by ${esc(CONFIG.payment.methodName ?? "bank transfer / KHQR")}. The customer pays, then you confirm it in your bank and switch the plan on from your server. <b>The app never switches a plan on by itself.</b></p>`
    : `<p class="small"><b>Left empty.</b> No payment method has been set up yet, so paid plans cannot be bought in the app. To add one, fill in <code>payment.config.json</code> (see docs/LAUNCH_CHECKLIST.md, section D) and rebuild.</p>`}
    ${V.s.paymentRequests.length ? `<h3 style="margin-top:12px">Your payment requests</h3><div class="list">${V.s.paymentRequests.slice().reverse().map((r) => `<div class="item"><div class="l"><b>${esc(r.reference)}</b><span class="small muted">${esc(PLANS[r.tier].name)} · ${esc(formatMoney(r.amountMinor, r.currency))}</span></div><div class="r small">${r.status === "cancelled" ? "Cancelled" : "Awaiting confirmation<br><span class='tiny muted'>plan NOT active yet</span>"}</div></div>`).join("")}</div>` : ""}</div>
  <div class="card small"><div class="kv"><span>Subscription source</span><b>${esc(sub.source === "none" ? "None" : sub.source === "dev" ? "Development switch (not a payment)" : sub.source)}</b><span>Status</span><b>${esc(sub.status)}</b></div>
  <p class="muted tiny">If a plan ends or is cancelled you keep full access to your own records and exports; only the paid features switch off. Prices and plan features are set in one place in the code (entitlements.ts).</p></div>`;
}

export function status(V   )         {
  const row = (name        , ok                      , note        ) => `<div class="status-row"><div><b>${esc(name)}</b><br><span class="small muted">${esc(note)}</span></div><span class="small"><span class="dot ${ok === "ok" ? "ok" : ok === "warn" ? "warn" : ""}"></span>${ok === "ok" ? "Works" : ok === "warn" ? "Partly" : "Not live"}</span></div>`;
  return `${pageHead("What works today")}<div class="card"><h3>Works on this device</h3>
  ${row("Sales, expenses, customers, stock", "ok", "Saved in this browser. Calculations are tested.")}
  ${row("Debts & partial payments", "ok", "Balances are calculated from recorded payments.")}
  ${row("Dashboard, reports, profit calculator, CSV", "ok", "Pro features unlock by plan.")}
  ${row("Copy a reminder message", "ok", "Paste it into SMS, Telegram or any chat app.")}
  ${row("Install on iPhone (Add to Home Screen)", "ok", "Works offline after the first load. Needs https hosting.")}</div>
  <div class="card"><h3>Needs a provider account or more setup</h3>
  ${row("Sign-in, accounts, password recovery", V.cloud.signedIn ? "ok" : "warn", "Built on Supabase Auth. Works once your Supabase project is connected (docs/SUPABASE_SETUP.md).")}
  ${row("Cloud sync & backup", V.cloud.signedIn ? (V.cloud.status === "synced" ? "ok" : "warn") : "no", V.cloud.signedIn ? "Records are copied to your account. A banner shows whenever something is NOT backed up." : "Only available when signed in to a connected project.")}
  ${row("Subscription payments", "no", "Needs a payment provider you are eligible for, plus server webhooks.")}
  ${row("SMS reminders", "no", "Needs an SMS provider account, credentials on a server, and a sender registration where required.")}
  ${row("Telegram reminders", "no", "Needs a Telegram bot token on a server and a webhook so customers can press Start.")}
  ${row("Automatic background reminders", "no", "Needs a scheduled server job. Nothing runs when the app is closed.")}</div>
  ${V.s.devMode ? `<div class="card"><h3>Development tools</h3>${row("Mock providers", "warn", "Fake SMS/Telegram that never contact anyone. Always labelled MOCK.")}${row("Plan switcher", "warn", "Test paid features without paying. Removed in production builds.")}</div>` : ""}
  <p class="muted tiny">Full details: docs/ARCHITECTURE.md and docs/LAUNCH_CHECKLIST.md</p>`;
}

// ---------- settings ----------
export function settings(V   )         {
  const b = V.s.business;
  const locked = V.s.db.sales.length + V.s.db.expenses.length > 0;
  return `${pageHead("Settings & data")}
  <form class="card" data-form="business"><h3>Business profile</h3>
    <label>Business name</label><input name="name" required value="${esc(b.name)}">
    <label>Business type</label><select name="type">${BUSINESS_TYPES.map((t) => `<option ${t === b.type ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>
    <div class="two"><div><label>Currency</label><select name="currency" ${locked || V.cloud.signedIn ? "disabled" : ""}>${CURRENCIES.map((c) => `<option ${c === b.currency ? "selected" : ""}>${c}</option>`).join("")}</select></div>
    <div><label>Date format</label><select name="dateFormat"><option ${b.dateFormat === "DD/MM/YYYY" ? "selected" : ""}>DD/MM/YYYY</option><option ${b.dateFormat === "YYYY-MM-DD" ? "selected" : ""}>YYYY-MM-DD</option></select></div></div>
    ${locked || V.cloud.signedIn ? `<p class="tiny muted">Currency is locked once you have records or an account, so amounts are never silently mixed or converted. One currency per business in this version.</p>` : ""}
    <label>Time zone</label><input name="timezone" value="${esc(b.timezone)}" required>
    <div class="two"><div><label>Phone (optional)</label><input name="phone" value="${esc(b.phone)}"></div><div><label>Email (optional)</label><input name="email" type="email" value="${esc(b.email)}"></div></div>
    <label>Starting cash (optional)</label><input name="startingCash" inputmode="decimal" value="${b.startingCash === null ? "" : (b.startingCash / 10 ** minorDigits(b.currency)).toFixed(minorDigits(b.currency))}">
    <button class="btn block" style="margin-top:14px">Save</button></form>
  ${accountCard(V)}
  <div class="card"><h3>Your data</h3><p class="muted small">Your records are yours. Export them any time.</p>
    <button class="btn secondary block" data-a="export-json">Download all my data (JSON)</button>
    ${V.cloud.signedIn ? "" : `<button class="btn danger block" style="margin-top:8px" data-a="confirm" data-id="erase" data-msg="Erase ALL FI Money data on this device? This cannot be undone. Download a backup first.">Erase all data on this device</button>
    <p class="tiny muted">Local preview only.</p>`}</div>
  ${V.cloud.signedIn ? "" : `<div class="card"><h3>Demo data</h3><p class="muted small">Try FI Money with sample figures. Demo data is kept completely separate from your real records.</p><button class="btn ghost block" data-a="enter-demo">Open demo</button></div>`}
  ${CONFIG.devTools && !V.cloud.signedIn ? `<div class="card"><h3>Developer options</h3>
    <label class="check"><input type="checkbox" data-a-toggle="devMode" ${V.s.devMode ? "checked" : ""}> Development mode (shows the plan switcher; not a payment)</label>
    <label class="check"><input type="checkbox" data-a-toggle="useMockProviders" ${V.s.useMockProviders ? "checked" : ""}> Use MOCK SMS/Telegram providers (nothing is actually sent)</label></div>` : ""}`;
}

// ---------- calculator ----------
export function calculator(V   )         {
  if (!V.can("profitCalculator")) return `${pageHead("Profit calculator")}${lockCard(V, "profitCalculator", "Advanced profit calculator")}`;
  const c = V.ui.calc;
  const f = (k        , label        , ph = "", hint = "") => `<div><label>${esc(label)}</label><input name="${k}" inputmode="decimal" placeholder="${esc(ph)}" value="${esc(c[k] ?? "")}">${hint ? `<span class="tiny muted">${esc(hint)}</span>` : ""}</div>`;
  const products = V.s.db.products.filter((p) => !p.archived && p.kind === "product");
  return `${pageHead("Profit calculator")}
  <form class="card" data-form="calc" autocomplete="off">
    <label>Start from a product (optional)</label><select name="fromProduct"><option value="">—</option>${products.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("")}</select>
    <div class="two">${f("cost", `Cost per unit (${V.currency})`, "", "Leave blank if unknown")}${f("price", `Selling price (${V.currency})`)}</div>
    <div class="two">${f("qty", "Quantity sold", "1")}${f("discount", "Discounts (total)", "0")}</div>
    <div class="two">${f("refunds", "Refunds (total)", "0")}${f("delivery", "Delivery cost (total)", "0")}</div>
    <div class="two">${f("packaging", "Packaging (total)", "0")}${f("other", "Other variable costs", "0")}</div>
    <div class="two">${f("mkt", "Marketplace fee %", "0")}${f("pay", "Payment fee %", "0")}</div>
    ${f("overhead", "Allocated overhead (optional)", "", "Needed for estimated net profit")}
  </form><div id="calc-result">${calcResult(V)}</div>`;
}
export function calcResult(V   )         {
  const c = V.ui.calc;
  const num = (k        )                => { const t = (c[k] ?? "").trim(); return t === "" ? null : Number(t.replace(/,/g, "")); };
  const money = (k        )                => { const t = (c[k] ?? "").trim(); if (t === "") return null; return parsePlain(t, V.currency); };
  if (!c.price && !c.cost) return `<p class="muted small">Enter a selling price to see results.</p>`;
  const r = calcCompute(V, money, num);
  if (!r.ok) return `<div class="notice warn">${r.errors.map(esc).join("<br>")}</div>`;
  const m = (v               ) => v === null ? `<span class="muted">—</span>` : `<span class="${v < 0 ? "neg" : ""}">${esc(V.fm(v))}</span>`;
  const p = (v               ) => v === null ? "—" : `${v}%`;
  return `${r.missing.length ? `<div class="notice warn"><b>Missing:</b> ${r.missing.map(esc).join("; ")}. Results that depend on it are hidden rather than guessed.</div>` : ""}
  <div class="card"><div class="kv"><span>Gross revenue</span><b>${esc(V.fm(r.grossRevenue))}</b><span>Net sales revenue <span class="tiny muted">(after discounts & refunds)</span></span><b>${esc(V.fm(r.netSalesRevenue))}</b>
  <span>Cost of goods sold</span><b>${m(r.cogs)}</b></div></div>
  <div class="grid2">${stat("Gross profit", m(r.grossProfit), "Net sales − cost of goods")}${stat("Gross margin", p(r.grossMarginPct), "Gross profit ÷ net sales")}
  ${stat("Contribution profit", m(r.contributionProfit), "Gross profit − fees, delivery, packaging, other")}${stat("Contribution margin", p(r.contributionMarginPct))}
  ${stat("Estimated net profit", m(r.estimatedNetProfit), "Contribution − overhead")}${stat("Est. net margin", p(r.estimatedNetMarginPct))}
  ${stat("Profit per unit", m(r.profitPerUnit), "Contribution profit ÷ quantity")}${stat("Break-even price / unit", m(r.breakEvenUnitPrice), "Lowest price with no loss")}</div>
  <p class="tiny muted">Variable costs included: ${esc(V.fm(r.variableCosts))}. Gross and contribution profit are not net profit. These are estimates, not certified accounting results.</p>`;
}
const parsePlain = (t        , cur        ) => parseMoney(t, cur);
function calcCompute(V   , money                              , num                              ) {
  const qty = num("qty") ?? 1;
  const price = money("price");
  const bad = (["cost", "price", "discount", "refunds", "delivery", "packaging", "other", "overhead"]         ).filter((k) => (V.ui.calc[k] ?? "").trim() !== "" && money(k) === null);
  if (bad.length || price === null) return { ...calculateProfit({ unitCost: null, unitPrice: 0, quantity: -1 }), errors: [price === null ? "Enter a valid selling price." : "Some amounts are not valid numbers."] };
  return calculateProfit({ unitCost: money("cost"), unitPrice: price, quantity: qty, discountTotal: money("discount") ?? 0, refundsTotal: money("refunds") ?? 0,
    deliveryCost: money("delivery") ?? 0, packagingCost: money("packaging") ?? 0, otherVariableCost: money("other") ?? 0,
    marketplaceFeePercent: num("mkt") ?? 0, paymentFeePercent: num("pay") ?? 0, overheadAllocation: money("overhead") });
}


export { modal };
