// FI Money — reminders and reports screens.
import { esc, fmtDateTime } from "./ui.js";
                                    
import * as L from "../engine/ledger.js";
import * as R from "../engine/reports.js";
import { PLACEHOLDERS, renderTemplate, blockersFor, statusLabel, buildMessage } from "../engine/reminders.js";
                                                       
import { formatAmount } from "../engine/money.js";
import { badge, stat, profitStat, chips, pageHead, rangeBar, empty, lockCard } from "./components.js";

// ---------- reminders ----------
function channelStatus(V   )         {
  const mock = V.s.useMockProviders;
  const row = (name        , requirements          ) => `<div class="status-row"><div><b>${name}</b><br><span class="small muted">${mock ? "MOCK provider active — nothing real is sent" : "Not connected"}</span></div>
    <span class="small"><span class="dot ${mock ? "warn" : ""}"></span>${mock ? "Mock" : "Not connected"}</span></div>
    <details><summary class="small">What is needed to connect ${name}</summary><ul class="small muted" style="margin:0 0 8px;padding-left:18px">${requirements.map((r) => `<li>${esc(r)}</li>`).join("")}</ul></details>`;
  return `<div class="card"><h3>Channels</h3>
  ${row("SMS", ["An SMS provider account that can reach your customers' countries (you arrange this).", "API credentials stored as secrets on a server — never in this app.", "A sender ID / number, and registration where the destination country requires it.", "A server endpoint to send, and a webhook to receive delivery reports."])}
  ${row("Telegram", ["A bot created with @BotFather; its token stays on a server.", "A webhook so customers can press Start and be linked to their record.", "Customers must start the bot before it can message them."])}
  <p class="tiny muted">Reminders are only processed while this app is open. Automatic background sending needs a scheduled server job.</p></div>`;
}
function remRow(V   , r          , withActions         )         {
  const c = V.s.db.customers.find((x) => x.id === r.customerId);
  const b = blockersFor(r, { db: V.s.db, settings: V.s.reminderSettings, config: V.channels, reminders: V.s.reminders, now: V.now, tz: V.s.business.timezone, automationAllowed: true, businessName: V.s.business.name, currency: V.currency });
  const waiting = ["draft", "scheduled", "pending"].includes(r.status);
  return `<div class="card" style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;gap:8px"><div><b>${esc(c?.name ?? "Customer")}</b><br><span class="small muted">${r.channel === "sms" ? "SMS" : "Telegram"} · step ${esc(V.fd(r.triggerDate))} · ${r.origin === "automatic" ? "automatic" : "manual"}</span></div>
  <div class="r small" style="text-align:right;max-width:48%">${r.providerIsMock ? `<span class="badge mock">MOCK</span><br>` : ""}${esc(statusLabel(r))}</div></div>
  ${waiting && [...b.permanent, ...b.transient].length ? `<p class="tiny muted" style="margin:6px 0 0">Waiting: ${esc([...b.permanent, ...b.transient][0])}</p>` : ""}
  ${r.error ? `<p class="tiny neg" style="margin:6px 0 0">${esc(r.error)}</p>` : ""}
  <details><summary class="small">Message & history</summary><div class="msgbox small">${esc(r.body)}</div>${r.log.map((l) => `<p class="tiny muted" style="margin:4px 0">${esc(fmtDateTime(l.at, V.s.business.timezone))} — ${esc(l.status)}: ${esc(l.note)}</p>`).join("")}</details>
  ${withActions && waiting ? `<button class="btn ghost small" data-a="cancel-rem" data-id="${esc(r.id)}">Cancel this reminder</button>` : ""}
  ${V.s.devMode && r.status === "submitted" && r.providerIsMock ? `<button class="btn ghost small" data-a="mock-delivered" data-id="${esc(r.id)}">Simulate delivery report (mock)</button>` : ""}</div>`;
}
export function reminders(V   )         {
  const { s, ui, today } = V;
  const adv = V.can("automatedReminders");
  const tabs = chips([["follow", "Follow-up"], ["queue", "Queue"], ["history", "History"], ["settings", "Settings"]], ui.remTab, "rem-tab");
  let body = "";
  if (ui.remTab === "follow") {
    const rows = L.openDebts(s.db, today).map((d) => ({ d, c: s.db.customers.find((x) => x.id === d.customerId)  }))
      .sort((a, b) => (a.d.dueDate ?? "9999").localeCompare(b.d.dueDate ?? "9999"));
    body = `<p class="muted small">Who to follow up with today. Copy a polite message and send it yourself — available on every plan.</p>
    ${rows.length ? rows.map(({ d, c }) => `<div class="card" style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;gap:8px"><div><b>${esc(c.name)}</b><br><span class="small muted">${esc(d.ref)} · due ${esc(V.fd(d.dueDate))}${d.status === "overdue" && d.dueDate ? ` · ${L.daysBetween(d.dueDate, today)} days overdue` : ""}</span></div><div style="text-align:right"><b>${esc(V.fm(d.balance))}</b><br>${badge(d.status)}</div></div>
      <button class="btn secondary small block" style="margin-top:8px" data-a="open" data-m="reminder" data-sale="${esc(d.saleId)}">${c.optOut ? "Opted out — view only" : "Prepare reminder"}</button></div>`).join("") : empty("Nobody owes you money right now.")}`;
  } else if (!adv) {
    body = lockCard(V, "automatedReminders", "Automated reminders, schedules, queue and history");
  } else if (ui.remTab === "queue") {
    const q = s.reminders.filter((r) => ["draft", "scheduled", "pending"].includes(r.status)).slice().reverse();
    body = `${channelStatus(V)}<button class="btn block" data-a="run-reminders" style="margin-bottom:6px">Run reminder check now</button><p class="tiny muted">Creates due reminders from your schedule, cancels any that are no longer needed, and sends what is allowed. Runs only while the app is open.</p>
    ${s.reminderSettings.paused ? `<div class="notice warn">All reminders are paused for the business.</div>` : ""}
    ${q.length ? q.map((r) => remRow(V, r, true)).join("") : empty("No reminders are waiting.")}`;
  } else if (ui.remTab === "history") {
    const h = s.reminders.slice().reverse();
    body = h.length ? h.map((r) => remRow(V, r, false)).join("") : empty("No reminders yet.");
  } else {
    const st = s.reminderSettings;
    const sample = renderTemplate(st.template, { customer_name: "Sophea", business_name: s.business.name || "Your Shop", currency: V.currency, outstanding_balance: formatAmount(250000 > 0 ? 2500 : 0, V.currency), due_date: V.fd(today), invoice_ref: "S-0001" });
    body = `${channelStatus(V)}<form class="card" data-form="remsettings" autocomplete="off"><h3>Automation rules</h3>
    <label class="check"><input type="checkbox" name="paused" ${st.paused ? "checked" : ""}> Pause all reminders for the business</label>
    <label>Days BEFORE the due date (comma separated)</label><input name="before" value="${esc(st.beforeDays.join(", "))}" placeholder="3">
    <label class="check"><input type="checkbox" name="onDue" ${st.onDueDate ? "checked" : ""}> Remind on the due date</label>
    <label>Days AFTER the due date (comma separated)</label><input name="after" value="${esc(st.afterDays.join(", "))}" placeholder="1, 3, 7, 14">
    <div class="two"><div><label>Quiet hours from</label><input type="time" name="quietStart" value="${esc(st.quietStart)}"></div><div><label>until</label><input type="time" name="quietEnd" value="${esc(st.quietEnd)}"></div></div>
    <div class="two"><div><label>Min. hours between reminders</label><input name="minHours" inputmode="numeric" value="${st.minHoursBetween}"></div><div><label>Max reminders per debt</label><input name="maxPer" inputmode="numeric" value="${st.maxPerDebt}"></div></div>
    <div class="two"><div><label>Retries after a failure</label><input name="retries" inputmode="numeric" value="${st.maxRetries}"></div><div><label>Both channels</label><select name="bothMode"><option value="together" ${st.bothMode === "together" ? "selected" : ""}>Send together</option><option value="sequence" ${st.bothMode === "sequence" ? "selected" : ""}>SMS first, Telegram only if SMS fails</option></select></div></div>
    <label>Message template</label><textarea name="template" id="tpl">${esc(st.template)}</textarea>
    <p class="tiny muted">Placeholders: ${PLACEHOLDERS.map((p) => `<code>{${p}}</code>`).join(" ")}. If a debt has no due date, that wording is left out.</p>
    <div class="msgbox small" id="tpl-preview">${esc(sample.text)}</div>
    <div class="two" style="margin-top:10px"><button class="btn">Save settings</button><button type="button" class="btn ghost" data-a="reset-template">Reset template</button></div></form>
    <div class="card"><h3>Telegram bot</h3><label>Bot username (public, e.g. @FIMoneyBot)</label><input data-a-change="botUsername" value="${esc(s.botUsername)}" placeholder="@YourBot"><p class="tiny muted">Only the public username goes here. The bot token must live on your server.</p></div>`;
  }
  return `${pageHead("Reminders & follow-up")}${tabs}${body}`;
}
void buildMessage;

// ---------- reports ----------
export function reports(V   )         {
  const { s, today } = V;
  const { from, to } = V.range;
  const sm = L.summarize(s.db, from, to, today);
  const days = R.dailySales(s.db, from, to).filter((d) => d.count > 0 || d.cash > 0).slice(-31).reverse();
  const months = R.monthlySales(s.db, L.addDays(from, 0), to);
  const cats = R.expensesByCategory(s.db, from, to);
  const pro = V.can("advancedReports");
  const csv = (k        , label        ) => pro ? `<button class="btn ghost small" data-a="csv" data-v="${k}">⬇ ${esc(label)} (CSV)</button>` : "";
  let out = `${pageHead("Reports")}${rangeBar(V)}
  <div class="grid2" style="margin-bottom:12px">${stat("Sales revenue", esc(V.fm(sm.salesRevenue)))}${stat("Cash received", esc(V.fm(sm.cashReceived)))}${stat("Expenses", esc(V.fm(sm.expenses)))}${profitStat(V, "Gross profit", sm.grossProfit, "Sales − cost of goods")}${profitStat(V, "Est. net profit", sm.estimatedNetProfit, "After fees & expenses")}${stat("Owed to you", esc(V.fm(sm.outstanding)))}</div>
  <p class="tiny muted">Estimates from your own records — not certified accounting results.</p>
  <div class="card"><h3>Daily sales</h3>${days.length ? `<div class="scroll-x"><table><tr><th>Date</th><th>Sales</th><th>Sold</th><th>Cash in</th></tr>${days.map((d) => `<tr><td>${esc(V.fd(d.date))}</td><td>${d.count}</td><td>${esc(V.fm(d.revenue))}</td><td>${esc(V.fm(d.cash))}</td></tr>`).join("")}</table></div>` : `<p class="muted small">No sales in this period.</p>`}</div>
  <div class="card"><h3>Monthly sales</h3>${months.length ? `<table><tr><th>Month</th><th>Sales</th><th>Revenue</th></tr>${months.map((m) => `<tr><td>${esc(m.month)}</td><td>${m.count}</td><td>${esc(V.fm(m.revenue))}</td></tr>`).join("")}</table>` : `<p class="muted small">No sales in this period.</p>`}</div>
  <div class="card"><h3>Expenses by category</h3>${cats.length ? `<table><tr><th>Category</th><th>Total</th>${pro ? "<th>Share</th>" : ""}</tr>${cats.map((c) => `<tr><td>${esc(c.category)}</td><td>${esc(V.fm(c.total))}</td>${pro ? `<td>${c.share === null ? "—" : c.share + "%"}</td>` : ""}</tr>`).join("")}</table>` : `<p class="muted small">No expenses in this period.</p>`}
    <p style="margin:8px 0 0">${csv("expenses", "Expenses")}</p></div>`;

  // customer debts
  const dr = R.debtReport(s.db, today);
  out += `<div class="card"><h3>Customer debts</h3>${dr.length ? `<div class="scroll-x"><table><tr><th>Customer</th><th>Owed</th><th>Due</th>${pro ? "<th>Days late</th>" : ""}</tr>${dr.map((r) => `<tr><td>${esc(r.customer)}<br><span class="tiny muted">${esc(r.ref)}${r.paid ? ` · paid ${esc(V.fm(r.paid))} of ${esc(V.fm(r.original))}` : ""}</span></td><td>${esc(V.fm(r.balance))}</td><td>${esc(V.fd(r.dueDate))}</td>${pro ? `<td>${r.daysOverdue ?? "—"}</td>` : ""}</tr>`).join("")}</table></div>` : `<p class="muted small">Nobody owes you money.</p>`}
    <p style="margin:8px 0 0">${csv("debts", "Debts")}</p></div>`;

  if (!pro) {
    out += lockCard(V, "advancedReports", "Product profitability, period comparison, inventory insights and CSV exports");
    return out;
  }
  const pp = R.productProfitability(s.db, from, to);
  out += `<div class="card"><h3>Product profitability</h3>${pp.length ? `<div class="scroll-x"><table><tr><th>Product</th><th>Qty</th><th>Revenue</th><th>Gross profit</th><th>Margin</th></tr>${pp.map((p) => `<tr><td>${esc(p.name)}</td><td>${p.qty}</td><td>${esc(V.fm(p.revenue))}</td><td>${p.grossProfit === null ? "needs cost" : esc(V.fm(p.grossProfit))}</td><td>${p.grossMarginPct === null ? "—" : p.grossMarginPct + "%"}</td></tr>`).join("")}</table></div>` : `<p class="muted small">No sales in this period.</p>`}
    <p style="margin:8px 0 0">${csv("products", "Product profit")}</p></div>`;

  const cmp = R.comparePeriods(s.db, from, to, today);
  const crow = (label        , a               , b               ) => { const ch = R.change(a, b); return `<tr><td>${esc(label)}</td><td>${a === null ? "—" : esc(V.fm(a))}</td><td>${b === null ? "—" : esc(V.fm(b))}</td><td class="${ch === null ? "" : ch < 0 ? "neg" : "pos"}">${ch === null ? "—" : (ch > 0 ? "+" : "") + ch + "%"}</td></tr>`; };
  out += `<div class="card"><h3>Compared with the previous period</h3><p class="tiny muted">${esc(V.fd(cmp.previousFrom))} – ${esc(V.fd(cmp.previousTo))}</p><table><tr><th></th><th>Now</th><th>Before</th><th>Change</th></tr>
    ${crow("Revenue", cmp.current.salesRevenue, cmp.previous.salesRevenue)}${crow("Cash received", cmp.current.cashReceived, cmp.previous.cashReceived)}${crow("Expenses", cmp.current.expenses, cmp.previous.expenses)}${crow("Gross profit", cmp.current.grossProfit, cmp.previous.grossProfit)}${crow("Est. net profit", cmp.current.estimatedNetProfit, cmp.previous.estimatedNetProfit)}</table>
    <p class="tiny muted">“—” means there is no earlier figure to compare with.</p></div>`;

  const sales = s.db.sales.filter((x) => !x.voided && x.date >= from && x.date <= to);
  const overdueDebts = L.openDebts(s.db, today).filter((d) => d.status === "overdue");
  out += `<div class="card"><h3>Performance indicators</h3><div class="kv" style="margin-top:6px"><span>Number of sales</span><b>${sales.length}</b>
    <span>Average sale</span><b>${sales.length ? esc(V.fm(Math.round(sm.salesRevenue / sales.length))) : "—"}</b>
    <span>Collected vs sold</span><b>${sm.salesRevenue > 0 ? Math.round((sm.cashReceived / sm.salesRevenue) * 1000) / 10 + "%" : "—"}</b>
    <span>Overdue debts</span><b>${overdueDebts.length} (${esc(V.fm(overdueDebts.reduce((t, d) => t + d.balance, 0)))})</b></div></div>`;

  const withCost = s.db.products.filter((p) => p.kind === "product" && !p.archived && p.cost !== null);
  const stockValue = withCost.reduce((t, p) => t + Math.max(0, L.stockOf(s.db, p.id)) * (p.cost          ), 0);
  const noCost = s.db.products.filter((p) => p.kind === "product" && !p.archived && p.cost === null).length;
  const sold = new Set(sales.flatMap((x) => x.lines.map((l) => l.productId)));
  const slow = s.db.products.filter((p) => p.kind === "product" && !p.archived && L.stockOf(s.db, p.id) > 0 && !sold.has(p.id));
  out += `<div class="card"><h3>Inventory insights</h3><div class="kv" style="margin-top:6px"><span>Stock value at cost</span><b>${esc(V.fm(stockValue))}</b></div>${noCost ? `<p class="tiny muted">${noCost} product${noCost > 1 ? "s have" : " has"} no cost and ${noCost > 1 ? "are" : "is"} left out.</p>` : ""}
    <p class="small"><b>Low stock:</b> ${sm.lowStock.length ? sm.lowStock.map((p) => `${esc(p.name)} (${p.stock})`).join(", ") : "none"}</p>
    <p class="small"><b>In stock but not sold in this period:</b> ${slow.length ? slow.map((p) => `${esc(p.name)} (${L.stockOf(s.db, p.id)})`).join(", ") : "none"}</p></div>
    <div class="card"><h3>Export</h3><p style="display:flex;gap:8px;flex-wrap:wrap;margin:0">${csv("sales", "Sales")}${csv("expenses", "Expenses")}${csv("debts", "Debts")}${csv("products", "Product profit")}</p></div>`;

  if (V.can("reminderHistory")) {
    const rr = s.reminders.filter((r) => r.createdAt.slice(0, 10) >= from && r.createdAt.slice(0, 10) <= to);
    const count = (st        ) => rr.filter((r) => r.status === st).length;
    out += `<div class="card"><h3>Reminder activity</h3>${rr.length ? `<div class="kv" style="margin-top:6px"><span>SMS</span><b>${rr.filter((r) => r.channel === "sms").length}</b><span>Telegram</span><b>${rr.filter((r) => r.channel === "telegram").length}</b><span>Submitted (not confirmed)</span><b>${count("submitted")}</b><span>Delivered (confirmed)</span><b>${count("delivered")}</b><span>Delivery unknown</span><b>${count("unknown")}</b><span>Failed</span><b>${count("failed")}</b><span>Cancelled</span><b>${count("cancelled")}</b></div>` : `<p class="muted small">No reminders in this period.</p>`}</div>`;
  } else out += lockCard(V, "reminderHistory", "Reminder activity report");
  return out;
}
