// FI Money — account screens (register, sign in, reset), account settings and the administrator area. HTML-string views.
import { esc, fmtDateTime } from "./ui.js";
import { CONFIG } from "./state.js";
import { MIN_PASSWORD } from "../engine/auth.js";
import { PLANS } from "../engine/entitlements.js";
import { formatMoney } from "../engine/money.js";
                                    

                                                                                                                                       
                                                                                                                        

const brand = `<div class="brand" style="color:var(--ink)"><div class="logo" style="background:var(--navy);color:#fff">FI</div><div><b style="font-size:1.3rem">FI Money</b><small class="muted">A Fondom Innovation product</small></div></div>`;
const err = (a        ) => (a.error ? `<div class="banner warn" role="alert" style="margin:10px 0">${esc(a.error)}</div>` : "") + (a.info ? `<div class="banner ok" role="status" style="margin:10px 0">${esc(a.info)}</div>` : "");
const pwField = (name        , label        , auto        ) =>
  `<label for="${name}">${label}</label><div class="pwrow"><input id="${name}" name="${name}" type="password" required autocomplete="${auto}" minlength="${MIN_PASSWORD}" autocapitalize="off" spellcheck="false"><button type="button" class="chip" data-a="toggle-pw" aria-label="Show or hide password">Show</button></div>`;
const meter = `<div id="pw-meter" class="pwmeter" aria-live="polite"><div class="bar"><i></i></div><span class="tiny muted">Use ${MIN_PASSWORD}+ characters with letters and numbers.</span></div>`;
const busy = (a        , label        ) => `<button class="btn block" style="margin-top:14px" ${a.busy ? "disabled" : ""}>${a.busy ? "Please wait…" : label}</button>`;

export function authView(a        , devPreview         )         {
  const wrap = (inner        ) => `<main style="padding-top:28px">${brand}${inner}</main>`;
  switch (a.screen) {
    case "loading": return wrap(`<p class="muted" style="margin-top:24px">Loading your account…</p>`);
    case "unconfigured": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.4rem">FI Money is not set up yet</h1>
      <div class="card"><p>This copy of the app is not connected to its account service, so nobody can register or sign in yet.</p>
      <p class="small muted">Owner: follow docs/SUPABASE_SETUP.md to connect your project, then rebuild and upload again.</p></div>
      ${devPreview ? `<div class="card"><h3>Developer preview</h3><p class="small muted">Local preview works without an account. Data stays in this browser only and is NOT backed up.</p><button class="btn secondary block" data-a="local-preview">Continue in local preview</button></div>` : ""}`);
    case "register": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.5rem">Create your account</h1>
      <p class="muted">Know your numbers. Grow your business. Free to start.</p>${err(a)}
      <form class="card" data-form="register" novalidate>
        <label for="fullName">Full name</label><input id="fullName" name="fullName" required maxlength="80" autocomplete="name" value="${esc(a.name ?? "")}">
        <label for="email">Email address</label><input id="email" name="email" type="email" required autocomplete="email" inputmode="email" autocapitalize="off" value="${esc(a.email)}">
        ${pwField("password", "Password", "new-password")}${meter}
        ${pwField("confirm", "Confirm password", "new-password")}
        <label class="check" style="margin-top:12px"><input type="checkbox" name="terms" required> <span>I accept the <a href="terms.html" target="_blank" rel="noopener">Terms</a> and <a href="privacy.html" target="_blank" rel="noopener">Privacy Policy</a>.</span></label>
        ${busy(a, "Create account")}
      </form>
      <p style="text-align:center">Already have an account? <button class="linkbtn" data-a="auth-go" data-v="signin">Sign in</button></p>`);
    case "signin": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.5rem">Welcome back</h1>${err(a)}
      <form class="card" data-form="signin" novalidate>
        <label for="email">Email address</label><input id="email" name="email" type="email" required autocomplete="email" inputmode="email" autocapitalize="off" value="${esc(a.email)}">
        ${pwField("password", "Password", "current-password")}
        ${busy(a, "Sign in")}
        <p style="text-align:center;margin:10px 0 0"><button type="button" class="linkbtn" data-a="auth-go" data-v="forgot">Forgot password?</button></p>
      </form>
      <p style="text-align:center">New to FI Money? <button class="linkbtn" data-a="auth-go" data-v="register">Create an account</button></p>`);
    case "verify": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.4rem">Check your email</h1>${err(a)}
      <div class="card"><p>We sent a verification link to <b>${esc(a.email)}</b>.</p><p class="small muted">Open the link to confirm your email, then sign in. Check your spam folder too. The link works once and expires after a while.</p>
      <button class="btn secondary block" data-a="resend" ${a.busy ? "disabled" : ""}>Send the email again</button>
      <button class="btn ghost block" style="margin-top:8px" data-a="auth-go" data-v="signin">I verified my email — sign in</button></div>`);
    case "forgot": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.4rem">Reset your password</h1>${err(a)}
      <form class="card" data-form="forgot" novalidate><p class="small muted">Enter your email. If an account exists, we will send a reset link.</p>
        <label for="email">Email address</label><input id="email" name="email" type="email" required autocomplete="email" inputmode="email" autocapitalize="off" value="${esc(a.email)}">
        ${busy(a, "Send reset link")}</form>
      <p style="text-align:center"><button class="linkbtn" data-a="auth-go" data-v="signin">Back to sign in</button></p>`);
    case "reset": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.4rem">Choose a new password</h1>${err(a)}
      <form class="card" data-form="reset" novalidate>${pwField("password", "New password", "new-password")}${meter}${pwField("confirm", "Confirm new password", "new-password")}${busy(a, "Save new password")}</form>`);
    case "suspended": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.4rem">Account suspended</h1>
      <div class="card"><p>This account has been suspended${a.info ? `: ${esc(a.info)}` : "."}</p><p class="small muted">Contact support${CONFIG.cloud.supportContact ? ` at ${esc(CONFIG.cloud.supportContact)}` : ""}. Your data has not been deleted.</p>
      <button class="btn secondary block" data-a="export-json">Download my data</button><button class="btn ghost block" style="margin-top:8px" data-a="sign-out">Sign out</button></div>`);
    case "loadfail": return wrap(`<h1 style="margin:18px 0 4px;font-size:1.4rem">Can't load your data</h1>${err(a)}
      <div class="card"><p>We could not reach your account data and there is no saved copy on this device. Connect to the internet and try again. Nothing was lost.</p>
      <button class="btn block" data-a="retry-load">Try again</button><button class="btn ghost block" style="margin-top:8px" data-a="sign-out">Sign out</button></div>`);
  }
}

// ---------- sync status ----------
export function syncBanner(V   )         {
  const c = V.cloud;
  if (!c.signedIn) return "";
  const t = c.lastSyncedAt ? fmtDateTime(c.lastSyncedAt, V.s.business.timezone) : "";
  switch (c.status) {
    case "synced": return "";
    case "syncing": return `<div class="banner">Saving to your account…</div>`;
    case "unsynced": return `<div class="banner warn"><b>Not backed up yet.</b> Changes are saved on this device only and will upload when you are online. <button class="chip" style="min-height:32px;padding:4px 10px" data-a="sync-now">Try now</button></div>`;
    case "offline": return `<div class="banner warn"><b>Offline.</b> Showing the copy on this device${t ? ` (last synced ${esc(t)})` : ""}. New changes are NOT backed up until you reconnect. <button class="chip" style="min-height:32px;padding:4px 10px" data-a="sync-now">Retry</button></div>`;
    case "conflict": return `<div class="banner warn" role="alert"><b>Two versions of your data exist</b> (another device saved newer changes).<br>
      <button class="chip" style="min-height:36px;margin-top:6px" data-a="conflict-cloud">Use the cloud version</button>
      <button class="chip" style="min-height:36px;margin-top:6px" data-a="conflict-mine">Keep this device's version</button><br><span class="tiny">Choosing one replaces the other. Download a backup first if unsure.</span></div>`;
    case "error": return `<div class="banner warn" role="alert"><b>Backup problem.</b> ${esc(c.note || "Your latest changes are not backed up.")} <button class="chip" style="min-height:32px;padding:4px 10px" data-a="sync-now">Retry</button></div>`;
    default: return "";
  }
}

// ---------- account section in Settings ----------
export function accountCard(V   )         {
  const c = V.cloud;
  if (!c.signedIn) return "";
  const synced = c.status === "synced" ? `<span class="dot ok"></span>Backed up${c.lastSyncedAt ? ` · ${esc(fmtDateTime(c.lastSyncedAt, V.s.business.timezone))}` : ""}` : `<span class="dot warn"></span>Not backed up yet`;
  return `<div class="card"><h3>Your account</h3><p class="small muted">Signed in as <b>${esc(c.email)}</b><br>${synced}</p>
    <form data-form="profile"><label>Full name</label><input name="fullName" value="${esc(c.fullName)}" maxlength="80" required><button class="btn secondary block" style="margin-top:10px">Save name</button></form>
    <button class="btn ghost block" style="margin-top:8px" data-a="sync-now">Back up now</button>
    <button class="btn secondary block" style="margin-top:8px" data-a="sign-out">Sign out</button></div>
  <form class="card" data-form="changepw" novalidate><h3>Change password</h3>${pwField("password", "New password", "new-password")}${meter}${pwField("confirm", "Confirm new password", "new-password")}<button class="btn secondary block" style="margin-top:12px">Change password</button></form>
  <form class="card" data-form="support" novalidate><h3>Help & support</h3><p class="small muted">Tell us what went wrong or what you need. We reply by email.${CONFIG.cloud.supportContact ? ` You can also contact ${esc(CONFIG.cloud.supportContact)}.` : ""}</p>
    <textarea name="message" rows="3" maxlength="4000" required placeholder="Your message"></textarea><button class="btn secondary block" style="margin-top:10px">Send to support</button>
    <p class="tiny muted"><a href="terms.html" target="_blank" rel="noopener">Terms</a> · <a href="privacy.html" target="_blank" rel="noopener">Privacy Policy</a></p></form>
  <form class="card" data-form="deleteacct" novalidate><h3>Delete my account</h3><p class="small">This permanently deletes your account and <b>all</b> business records in the cloud and on this device. It cannot be undone. Download your data first.</p>
    <label>Type DELETE to confirm</label><input name="confirmText" autocomplete="off" autocapitalize="characters"><button class="btn danger block" style="margin-top:10px">Delete account and data</button></form>`;
}

// ---------- administrator area ----------
                            
                                 
                                                                                                 
                                                                                                                                 
                                                                                                                                     
                                                                                                   
                                                                                                  
                                                                   
 
export const emptyAdmin = ()            => ({ loaded: false, error: "", usage: null, requests: [], users: [], audit: [], support: [], plans: [] });

export function adminPage(V   , d           )         {
  const tz = V.s.business.timezone;
  const head = `<div class="pagehead"><button class="chip" data-a="more" data-page="">‹ Back</button><h2>Administrator</h2></div>`;
  if (!V.cloud.isAdmin) return `${head}<div class="card"><p>You do not have access to this area.</p></div>`;
  if (!d.loaded) return `${head}<div class="card"><p>${d.error ? esc(d.error) : "Loading…"}</p><button class="btn secondary block" data-a="admin-load">Reload</button></div>`;
  const pending = d.requests.filter((r) => r.status === "awaiting_confirmation");
  return `${head}${d.error ? `<div class="banner warn">${esc(d.error)}</div>` : ""}
  <div class="card"><h3>Usage</h3><p class="small">Accounts: <b>${d.usage?.accounts ?? 0}</b> · ${Object.entries(d.usage?.by_tier ?? {}).map(([k, v]) => `${esc(k)}: ${v}`).join(" · ")}<br>Payments waiting: <b>${d.usage?.awaiting_payments ?? 0}</b></p></div>
  <div class="card"><h3>Payments to verify</h3><p class="tiny muted">Confirm ONLY after you see the money in your bank and the reference and amount match. Confirming switches the customer's plan on for 31 days.</p>
    ${pending.length ? pending.map((r) => `<div class="item"><div class="l"><b>${esc(r.reference)}</b><span class="small muted">${esc(r.tier)} · ${esc(formatMoney(r.amount_minor, "USD"))} · ${esc(fmtDateTime(r.created_at, tz))}</span></div>
      <div class="r"><button class="chip" data-a="admin-confirm" data-ref="${esc(r.reference)}">Confirm paid</button> <button class="chip" data-a="admin-reject" data-ref="${esc(r.reference)}">Reject</button></div></div>`).join("") : `<p class="small muted">Nothing waiting.</p>`}</div>
  <div class="card"><h3>Plan prices (USD)</h3>${d.plans.filter((p) => p.tier !== "free").map((p) => `<form data-form="adminplan" data-tier="${esc(p.tier)}" class="two"><div><label>${esc(PLANS[p.tier                      ]?.name ?? p.tier)} (cents)</label><input name="price" inputmode="numeric" value="${p.price_minor}"></div><div style="align-self:end"><button class="btn secondary block">Save</button></div></form>`).join("")}
    <p class="tiny muted">Prices are stored in the database. The app's plan cards still show the built-in defaults until the app reads this table.</p></div>
  <div class="card"><h3>Accounts</h3>${d.users.map((u) => `<div class="item"><div class="l"><b>${esc(u.full_name || "(no name)")}</b><span class="small muted">${esc(u.email)}${u.suspended ? ` · SUSPENDED: ${esc(u.suspended_reason ?? "")}` : ""}</span></div>
    <div class="r">${u.suspended ? `<button class="chip" data-a="admin-unsuspend" data-id="${esc(u.id)}">Restore</button>` : `<button class="chip" data-a="admin-suspend" data-id="${esc(u.id)}">Suspend</button>`}</div></div>`).join("") || `<p class="small muted">None.</p>`}</div>
  <div class="card"><h3>Support requests</h3>${d.support.map((x) => `<div class="item"><div class="l"><span class="small">${esc(x.message)}</span><span class="tiny muted">${esc(fmtDateTime(x.created_at, tz))} · ${esc(x.user_id.slice(0, 8))} · ${esc(x.status)}</span></div></div>`).join("") || `<p class="small muted">None.</p>`}</div>
  <div class="card"><h3>Audit log</h3>${d.audit.map((x) => `<div class="small"><b>${esc(x.action)}</b> ${esc(x.target ?? "")} <span class="muted tiny">${esc(fmtDateTime(x.at, tz))}</span></div>`).join("") || `<p class="small muted">Empty.</p>`}</div>`;
}
