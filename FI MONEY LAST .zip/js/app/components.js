// Shared UI building blocks (no business logic).
import { esc } from "./ui.js";
                                    
import { PLANS, requiredTier } from "../engine/entitlements.js";
                                                         

export const badge = (status        ) => `<span class="badge ${esc(status)}">${esc({ paid: "Paid", partial: "Partially paid", unpaid: "Unpaid", overdue: "Overdue", voided: "Voided" }[status] ?? status)}</span>`;
export const stat = (label        , num        , hint = "", cls = "") => `<div class="stat"><div class="label">${esc(label)}</div><div class="num ${cls}">${num}</div>${hint ? `<div class="hint">${esc(hint)}</div>` : ""}</div>`;
export const profitStat = (V   , label        , v               , hint        ) =>
  v === null ? stat(label, `<span class="muted" style="font-size:.95rem">Needs cost data</span>`, hint) : stat(label, esc(V.fm(v)), hint, v < 0 ? "neg" : "");
export const chips = (items                    , current        , action        ) =>
  `<div class="chips" role="group">${items.map(([v, l]) => `<button class="chip" aria-pressed="${v === current}" data-a="${action}" data-v="${esc(v)}">${esc(l)}</button>`).join("")}</div>`;
export function lockCard(V   , f         , what        )         {
  const plan = PLANS[requiredTier(f)].name;
  return `<div class="card"><span class="badge lock">${esc(plan)}</span><h3 style="margin-top:6px">${esc(what)}</h3><p class="muted small">This feature is included in ${esc(plan)}. Your own records stay fully available on every plan.</p><button class="btn secondary small" data-a="more" data-page="plans">See plans</button></div>`;
}
export const pageHead = (title        , back = true) => `<div class="sheet-head" style="margin:0 0 10px">${back ? `<button data-a="more" data-page="" aria-label="Back">‹</button>` : ""}<h2 style="flex:1">${esc(title)}</h2></div>`;
export const rangeBar = (V   ) => `${chips([["today", "Today"], ["7d", "Last 7 days"], ["month", "This month"], ["custom", "Custom"]], V.ui.range, "range")}
  ${V.ui.range === "custom" ? `<form data-form="range" class="two" style="margin-bottom:10px"><div><label>From</label><input type="date" name="from" value="${esc(V.ui.from)}"></div><div><label>To</label><input type="date" name="to" value="${esc(V.ui.to)}"></div><button class="btn secondary small" style="grid-column:1/-1">Apply dates</button></form>` : ""}
  <p class="muted small" style="margin:0 0 10px">Showing ${esc(V.fd(V.range.from))} – ${esc(V.fd(V.range.to))}</p>`;
export const empty = (msg        , cta = "") => `<div class="card" style="text-align:center"><p class="muted">${esc(msg)}</p>${cta}</div>`;

