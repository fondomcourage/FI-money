// FI Money — tiny Supabase client (no packages). Talks to Supabase Auth (GoTrue) and PostgREST over fetch.
// Only the PUBLIC project URL and anon key are used here. The anon key is safe to ship: every table is protected by Row-Level Security.
// NEVER put the service-role key in this app.
                                                                           
                                                                                                                        
export class CloudError extends Error {
  status        ; code        ;
  constructor(message        , status = 0, code = "error") { super(message); this.status = status; this.code = code; }
}
                                                                                                               
                                                                           

const SESSION_KEY = "fi-money:session";
const b64 = (s        )         => { const t = s.replace(/-/g, "+").replace(/_/g, "/"); return atob(t + "=".repeat((4 - (t.length % 4)) % 4)); };
export function jwtPayload(token        )                          {
  try { return JSON.parse(b64(token.split(".")[1] ?? ""))                           ; } catch { return {}; }
}
export function friendlyAuthError(code        , status        , fallback        )         {
  const c = code.toLowerCase();
  if (c.includes("email_not_confirmed")) return "Please verify your email first. Check your inbox (and spam) for the link we sent.";
  if (c.includes("invalid_credentials") || c.includes("invalid_grant")) return "Email or password is not correct.";
  if (c.includes("over_email_send_rate_limit") || c.includes("over_request_rate_limit") || status === 429) return "Too many attempts. Please wait a few minutes and try again.";
  if (c.includes("weak_password")) return "That password is too weak. Use at least 10 characters with letters and numbers.";
  if (c.includes("same_password")) return "Choose a password that is different from your current one.";
  if (c.includes("signup_disabled")) return "New registrations are currently closed.";
  if (c.includes("user_banned")) return "This account is suspended. Contact support.";
  if (status === 0) return "No internet connection. Please try again when you are online.";
  return fallback;
}

                        
                      
                            
                                                                                                                      
                                                            
                           
                                                            
                                                           
                                                     
                                                                                                                                         
                                             
                                                         
                                                    
                                                                  
                                                
 

export function createCloud(cfg             , deps      )        {
  const configured = !!(cfg.url && cfg.anonKey);
  const base = (cfg.url ?? "").replace(/\/+$/, "");
  let cur                 = null;
  try { const raw = deps.store.get(SESSION_KEY); if (raw) cur = JSON.parse(raw)           ; } catch { cur = null; }

  const keep = (s                )       => { cur = s; try { if (s) deps.store.set(SESSION_KEY, JSON.stringify(s)); else deps.store.remove(SESSION_KEY); } catch { /* storage blocked: session lives in memory only */ } };
  const toSession = (j                         )          => {
    const at = String(j.access_token ?? ""), p = jwtPayload(at);
    const exp = typeof j.expires_at === "number" ? j.expires_at : Math.floor(deps.now() / 1000) + Number(j.expires_in ?? 3600);
    return { accessToken: at, refreshToken: String(j.refresh_token ?? ""), expiresAt: exp, userId: String(p.sub ?? (j.user                               )?.id ?? ""), email: String(p.email ?? (j.user                                  )?.email ?? "") };
  };
  async function raw(path        , init                                         )                    {
    if (!configured) throw new CloudError("FI Money cloud is not set up.", 0, "not_configured");
    const headers                         = { apikey: cfg.anonKey , "Content-Type": "application/json", ...(init.headers                                      ) };
    // New-style publishable keys (sb_publishable_...) are not JWTs, so they go only in the apikey header.
    // Old-style anon keys (JWT) are also sent as the bearer token. A signed-in user always sends their own token.
    const bearer = init.token ?? (cfg.anonKey .startsWith("eyJ") ? cfg.anonKey : null);
    if (bearer) headers.Authorization = `Bearer ${bearer}`;
    try { return await deps.fetch(base + path, { ...init, headers }); } catch { throw new CloudError("No internet connection.", 0, "network"); }
  }
  async function fail(r          )                 {
    let j                          = {};
    try { j = (await r.json())                           ; } catch { /* no body */ }
    const code = String(j.error_code ?? j.code ?? j.error ?? "error");
    const msg = String(j.msg ?? j.message ?? j.error_description ?? j.error ?? `Request failed (${r.status})`);
    throw new CloudError(friendlyAuthError(code + " " + msg, r.status, msg), r.status, code);
  }
  async function refreshIfNeeded()                          {
    if (!cur) return null;
    if (cur.expiresAt - deps.now() / 1000 > 60) return cur;
    try {
      const r = await raw("/auth/v1/token?grant_type=refresh_token", { method: "POST", body: JSON.stringify({ refresh_token: cur.refreshToken }) });
      if (!r.ok) { if (r.status >= 400 && r.status < 500) { keep(null); return null; } return cur; }
      keep(toSession((await r.json())                           ));
    } catch (e) { if (!(e instanceof CloudError && e.code === "network")) throw e; /* offline: keep the session, retry later */ }
    return cur;
  }
  async function authed(path        , init             , retry = true)                    {
    const s = await refreshIfNeeded();
    if (!s) throw new CloudError("Please sign in again.", 401, "signed_out");
    const r = await raw(path, { ...init, token: s.accessToken });
    if (r.status === 401 && retry) { if (cur) cur = { ...cur, expiresAt: 0 }; return authed(path, init, false); }
    return r;
  }
  const json = async    (r          )             => { if (!r.ok) return fail(r); const t = await r.text(); return (t ? JSON.parse(t) : undefined)     ; };

  return {
    configured,
    session: () => cur,
    refreshIfNeeded,
    async signUp(email, password, fullName, redirectTo) {
      const r = await raw(`/auth/v1/signup?redirect_to=${encodeURIComponent(redirectTo)}`, { method: "POST", body: JSON.stringify({ email, password, data: { full_name: fullName, accepted_terms: "true" } }) });
      const j = await json                         (r);
      if (j && typeof j.access_token === "string") { const s = toSession(j); keep(s); return { session: s }; }
      return { session: null };   // email verification required
    },
    async signIn(email, password) {
      const r = await raw("/auth/v1/token?grant_type=password", { method: "POST", body: JSON.stringify({ email, password }) });
      const s = toSession(await json                         (r)); keep(s); return s;
    },
    async signOut() {
      const s = cur; keep(null);
      if (s) { try { await raw("/auth/v1/logout", { method: "POST", token: s.accessToken }); } catch { /* local sign-out already done */ } }
    },
    async resend(email, redirectTo) { await json(await raw(`/auth/v1/resend?redirect_to=${encodeURIComponent(redirectTo)}`, { method: "POST", body: JSON.stringify({ type: "signup", email }) })); },
    async recover(email, redirectTo) { await json(await raw(`/auth/v1/recover?redirect_to=${encodeURIComponent(redirectTo)}`, { method: "POST", body: JSON.stringify({ email }) })); },
    async updatePassword(pw) { await json(await authed("/auth/v1/user", { method: "PUT", body: JSON.stringify({ password: pw }) })); },
    consumeHash(hash) {
      const h = hash.replace(/^#/, "");
      if (!h) return { kind: "none" };
      const p = new URLSearchParams(h);
      if (p.get("error_description") || p.get("error")) return { kind: "error", message: friendlyLink(p.get("error_code") ?? "", p.get("error_description") ?? "") };
      const at = p.get("access_token");
      if (!at) return { kind: "none" };
      const s = toSession({ access_token: at, refresh_token: p.get("refresh_token"), expires_in: p.get("expires_in"), expires_at: p.get("expires_at") ? Number(p.get("expires_at")) : undefined });
      keep(s);
      return { kind: "session", type: p.get("type") ?? "", session: s };
    },
    async select   (table        , query = "") { return json     (await authed(`/rest/v1/${table}${query ? "?" + query : ""}`, { method: "GET" })); },
    async insert(table, row) { await json(await authed(`/rest/v1/${table}`, { method: "POST", headers: { Prefer: "return=minimal" }, body: JSON.stringify(row) })); },
    async patch(table, query, row) { await json(await authed(`/rest/v1/${table}?${query}`, { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify(row) })); },
    async rpc   (fn        , args         = {}) { return json   (await authed(`/rest/v1/rpc/${fn}`, { method: "POST", body: JSON.stringify(args) })); },
  };
}
function friendlyLink(code        , desc        )         {
  if (/expired|otp_expired/i.test(code + desc)) return "That link has expired or was already used. Request a new one.";
  return "That link is not valid. Request a new one.";
}
